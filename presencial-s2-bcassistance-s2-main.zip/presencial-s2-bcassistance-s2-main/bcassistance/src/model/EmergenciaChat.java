package model;

import java.util.Vector;

import control.ControladorBBDD;
import control.ControladorCifrado;


public class EmergenciaChat {

	private Location localizacion;
	private String dniPaciente;
	private int ID;

	//Constructores
	public EmergenciaChat(Location location, String dniPaciente) {
		this.localizacion=location;
		this.dniPaciente=dniPaciente;
	}
	
	//Otros
	public Paciente devolverPaciente() {
		
		//Buscamos al paciente en la BBDD

		ControladorBBDD cBBDD = new ControladorBBDD();
		Paciente paciente =cBBDD.BuscarPaciente(dniPaciente);
		
		return paciente;
	}
	
	//Buscamos en el vector de Pacientes la posicion
	public int buscarEnPacientes(Vector<Paciente> listaPacientes, String DNI) {
		int position = -1;

		for(int nVectorPacientes=0;nVectorPacientes<=listaPacientes.size()-1;nVectorPacientes++){
			if(listaPacientes.elementAt(nVectorPacientes).getCredencial().getUsuario_dni().equals(DNI)) {
				position=nVectorPacientes;
			}   		
		}
		if(position!=-1)System.out.println("El paciente tiene DNI: "+ listaPacientes.elementAt(position).getCredencial().getUsuario_dni());

		//Si no se ecuentra la posicion devuelve -1
		return position;
	}

	
	
	//Getters y setters
	public String getDniPaciente() {
		return dniPaciente;
	}
	public void setDniPaciente(String dniPaciente) {
		this.dniPaciente = dniPaciente;
	}

	public Location getLocalizacion() {
		return localizacion;
	}
	public void setLocalizacion(Location localizacion) {
		this.localizacion = localizacion;
	}
	
	public int getID() {
		return this.ID;
	}
	
	public void setId(int ID) {
		this.ID=ID;
	}


}
