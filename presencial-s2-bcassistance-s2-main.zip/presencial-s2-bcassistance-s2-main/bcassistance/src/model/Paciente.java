package model;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import control.ControladorBBDD;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Paciente extends Usuario {

	private double peso;
	private int altura;
	//Estado: false es que no hay emergencia y true es que hay emergencia
	private boolean estado=false;
	private Emergencia emergencia;
	private String historial_clinico;
	private Vector<Receta> medicamentos;
	private Vector<String> cuidadores=new Vector<String>();
	private String clinico;
	private Vector<AgendaMedicamento> agendaTodosMedicamentos= new Vector<>();
	//0:verde, 1:naranja, 2:rojo
	private int estadoCorazon=0;
	private int estadoMedicacion=0;
	private int estadoActividad=0;
	private Vector<Location> registroLocalizaciones= new Vector<>();



	//Constructor 1
	public Paciente(String nombre, String apellido1, String apellido2, CredencialUsuario credencial, Date fecha_nacimiento,
			int telefono, boolean sexo, double peso, int altura) {
		super(nombre, apellido1, apellido2, credencial, fecha_nacimiento, telefono, sexo);
		this.peso=peso;
		this.altura=altura;	
		this.historial_clinico=null;
		this.medicamentos= new Vector<Receta>();
		//this.cuidadores= new Vector<String>();
		this.estado=false;
		//this.emergencia=null;

	}
	//CONSTRUCTOR PARA EL REGISTRO
	public Paciente(String nombre, String apellido1, String apellido2, CredencialUsuario credencial, Date fecha_nacimiento,
			int telefono, boolean sexo) {
		super(nombre, apellido1, apellido2, credencial, fecha_nacimiento, telefono, sexo);

		this.peso=0.0;
		this.altura=0;	
		//por eso null y se lo setea después
		this.historial_clinico=null;
		this.medicamentos= new Vector<Receta>();
		//this.cuidadores= new Vector<String>();
		this.estado=false;
		//this.emergencia=null;;

	}

	public ObservableList<Receta> devolverListadoMedicamentosCuidador(){
		ObservableList<Receta> recetas = FXCollections.observableArrayList();
		ControladorBBDD controlador= new ControladorBBDD();

		//Recorremos nuestro listado de medicamentos
		for(int i=0; i<medicamentos.size(); i++) {
			System.out.println(medicamentos.get(i));
			Receta receta = medicamentos.get(i);
			Timestamp dia= new Timestamp(new Date().getTime());
			if(dia.equals(sumarDiasAFecha(receta.getFecha(),receta.getFrecuencia()))|| dia.after(sumarDiasAFecha(receta.getFecha(),receta.getFrecuencia()))) {
				System.out.println("El medicamento a borrar es: " + medicamentos.get(i));
				controlador.BorrarReceta(this.getCredencial().getUsuario_dni(), receta);
			}
			else {			
				//Guardamos cada elemento en nuestro observable list
				recetas.add(medicamentos.get(i));
			}
		}
		return recetas;
	}

	public ObservableList<AgendaMedicamento> devolverAgendaMedicamentos(){
		ObservableList<AgendaMedicamento> agenda = FXCollections.observableArrayList();
		//Si el vector est� vac�a controlamos los null pointer exception
		if(!agendaTodosMedicamentos.isEmpty()) {
			//Metemos las tres filas 
			agenda.add(agendaTodosMedicamentos.get(0));
			agenda.add(agendaTodosMedicamentos.get(1));
			agenda.add(agendaTodosMedicamentos.get(2));
		}

		return agenda;
	}

	public void addLocation(Location l) {
		registroLocalizaciones.add(l);
	}

	//ESTE METODO SE USA CUANDO SE AniADE UNA RECETA A UN PACIENTE
	public void anadirMedicamentoAAgenda(Receta receta) {
		//Guardamos los datos de la agenda de la receta que pasamos como parametro a la agenda con todos los medicamentos
		//Comprobamos si tiene alg�n medicamentos a�adido, si no es as�, inicializamos su agendaCompleta
		if(agendaTodosMedicamentos.size()==0) {
			inicializarAgendaCompleta();
		}
		//Primero recorremos nuestra agendaCompleta
		for (int i=0; i<agendaTodosMedicamentos.size(); i++) {
			//maniana: 0 mediodia: 1 noche: 2
			//Para cada fila de la agenda completa, a�adimos la agenda de la receta
			//IMP hay que tener en cuenta que si hay 2 medicamentos en la misma celda debemos incluir un salto de linea
			//Si no esta el hueco vacio, le aniado la info del medicamento
			if(!receta.getAgendaMedicamento().get(i).getL().equals("")) {
				agendaTodosMedicamentos.get(i).setL(receta.getAgendaMedicamento().get(i).getL()+"\n");
			}
			if(!receta.getAgendaMedicamento().get(i).getM().equals("")) {
				agendaTodosMedicamentos.get(i).setM(receta.getAgendaMedicamento().get(i).getM()+"\n");
			}
			if(!receta.getAgendaMedicamento().get(i).getX().equals("")) {
				agendaTodosMedicamentos.get(i).setX(receta.getAgendaMedicamento().get(i).getX()+"\n");
			}
			if(!receta.getAgendaMedicamento().get(i).getJ().equals("")) {
				agendaTodosMedicamentos.get(i).setJ(receta.getAgendaMedicamento().get(i).getJ()+"\n");
			}
			if(!receta.getAgendaMedicamento().get(i).getV().equals("")) {
				agendaTodosMedicamentos.get(i).setV(receta.getAgendaMedicamento().get(i).getV()+"\n");
			}
			if(!receta.getAgendaMedicamento().get(i).getS().equals("")) {
				agendaTodosMedicamentos.get(i).setS(receta.getAgendaMedicamento().get(i).getS()+"\n");
			}
			if(!receta.getAgendaMedicamento().get(i).getD().equals("")) {
				agendaTodosMedicamentos.get(i).setD(receta.getAgendaMedicamento().get(i).getD()+"\n");
			}
		}
	}
	public static Date sumarDiasAFecha(Timestamp fecha, int dias){
		if (dias==0) return fecha;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fecha); 
		calendar.add(Calendar.DAY_OF_YEAR, dias);  
		return calendar.getTime(); 
	}

	public void refrescarMedicamentoAAgenda() {
		//Guardamos los datos de la agenda de todas las recetas a la agenda con todos los medicamentos
		//Limpiamos la agenda y la inicializamos
		agendaTodosMedicamentos.clear();
		inicializarAgendaCompleta();
		//Primero recorremos todos los medicamentos
		for (int j=0; j<medicamentos.size(); j++) {
			Receta receta = medicamentos.get(j);
			//luego los vamos a�adiendo a la agenda de todos los medicmanetos
			for (int i=0; i<agendaTodosMedicamentos.size(); i++) {
				//maniana: 0 mediodia: 1 noche: 2
				//Para cada fila de la agenda completa, a�adimos la agenda de la receta
				//IMP hay que tener en cuenta que si hay 2 medicamentos en la misma celda debemos incluir un salto de linea
				//Si no esta el hueco vacio, le aniado la info del medicamento
				if(!receta.getAgendaMedicamento().get(i).getL().equals("")) {
					agendaTodosMedicamentos.get(i).setL(receta.getAgendaMedicamento().get(i).getL()+"\n");
				}
				if(!receta.getAgendaMedicamento().get(i).getM().equals("")) {
					agendaTodosMedicamentos.get(i).setM(receta.getAgendaMedicamento().get(i).getM()+"\n");
				}
				if(!receta.getAgendaMedicamento().get(i).getX().equals("")) {
					agendaTodosMedicamentos.get(i).setX(receta.getAgendaMedicamento().get(i).getX()+"\n");
				}
				if(!receta.getAgendaMedicamento().get(i).getJ().equals("")) {
					agendaTodosMedicamentos.get(i).setJ(receta.getAgendaMedicamento().get(i).getJ()+"\n");
				}
				if(!receta.getAgendaMedicamento().get(i).getV().equals("")) {
					agendaTodosMedicamentos.get(i).setV(receta.getAgendaMedicamento().get(i).getV()+"\n");
				}
				if(!receta.getAgendaMedicamento().get(i).getS().equals("")) {
					agendaTodosMedicamentos.get(i).setS(receta.getAgendaMedicamento().get(i).getS()+"\n");
				}
				if(!receta.getAgendaMedicamento().get(i).getD().equals("")) {
					agendaTodosMedicamentos.get(i).setD(receta.getAgendaMedicamento().get(i).getD()+"\n");
				}
			}
		}
	}



	public void inicializarAgendaCompleta() {
		AgendaMedicamento maniana = new AgendaMedicamento("Manana", "", "", "", "", "", "", "");
		AgendaMedicamento mediodia = new AgendaMedicamento("Mediodia", "", "", "", "", "", "", "");
		AgendaMedicamento noche = new AgendaMedicamento("Noche", "", "", "", "", "", "", "");
		agendaTodosMedicamentos.add(maniana);
		agendaTodosMedicamentos.add(mediodia);
		agendaTodosMedicamentos.add(noche);
	}

	public Paciente() {
		this.medicamentos= new Vector<Receta>();
	}

	// Getters y setters
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}

	public int getEstadoCorazon() {
		return estadoCorazon;
	}
	public void setEstadoCorazon(int estadoCorazon) {
		this.estadoCorazon = estadoCorazon;
	}
	public int getEstadoMedicacion() {
		return estadoMedicacion;
	}
	public void setEstadoMedicacion(int estadoMedicacion) {
		this.estadoMedicacion = estadoMedicacion;
	}
	public int getEstadoActividad() {
		return estadoActividad;
	}
	public void setEstadoActividad(int estadoActividad) {
		this.estadoActividad = estadoActividad;
	}

	public int getEdad() {
		int edad=0;
		//A partir de la fecha de Nacimiento calculamos la edad, de esta forma podemos ir actualizando.
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate fechaNac = LocalDate.parse(getFecha_nacimiento_str(), fmt);
		LocalDate ahora = LocalDate.now();
		//Comparamos la fecha de nacimiento con la fecha actual
		Period periodo = Period.between(fechaNac, ahora);
		edad=periodo.getYears();
		return edad;
	}

	public Vector<Location> getRegistroLocalizaciones() {
		return registroLocalizaciones;
	}
	public void setRegistroLocalizaciones(Vector<Location> registroLocalizaciones) {
		this.registroLocalizaciones = registroLocalizaciones;
	}

	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}

	public boolean isEstado() {
		return estado;
	}

	public Vector<AgendaMedicamento> getAgendaTodosMedicamentos() {
		return agendaTodosMedicamentos;
	}
	public void setAgendaTodosMedicamentos(Vector<AgendaMedicamento> agendaTodosMedicamentos) {
		this.agendaTodosMedicamentos = agendaTodosMedicamentos;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public String getHistorial_clinico() {
		return historial_clinico;
	}
	public void setHistorial_clinico(String historial_clinico) {
		this.historial_clinico = historial_clinico;
	}

	public Vector<Receta> getMedicamentos() {
		return medicamentos;
	}
	public void setMedicamentos(Vector<Receta> medicamentos) {
		this.medicamentos = medicamentos;
	}

	public Vector<String> getCuidadores() {
		return cuidadores;
	}
	public ObservableList <Cuidador> NombreCuidadores() {

		ObservableList<Cuidador> nombresCuidadores= FXCollections.observableArrayList();
		if (cuidadores==null) {
			cuidadores = new Vector<String>();
		}
		else {
			//En primer lugar creo el controlador de ficheros y los vectores de cl�nico, cuidador y pacientes
			ControladorBBDD cBBDD = new ControladorBBDD();
			Vector <Cuidador> thisCuidadores = cBBDD.listadoNombresCuidadoresdePaciente(this.getCredencial().getUsuario_dni());
			for (int i =0; i<thisCuidadores.size(); i++) {
				nombresCuidadores.add(thisCuidadores.get(i));
			}
		
		}
		return nombresCuidadores;
	}

	public void setCuidadores(Vector<String> cuidadores) {
		this.cuidadores = cuidadores;
	}

	public String getClinico() {
		if (clinico==null) {
			clinico = new String();
		}
		return clinico;
	}

	public Clinico NombreClinico() {
		//En primer lugar creo el controlador de ficheros y los vectores de cl�nico, cuidador y pacientes
		Clinico clinico = null;
		ControladorBBDD cBBDD = new ControladorBBDD();
		clinico=cBBDD.listadoNombresClinicosdePaciente(this.getCredencial().getUsuario_dni());		
			
		return clinico;
	}

	public void setClinico(String clinico) {
		this.clinico = clinico;
	}

	//Otros metodos
	public void addMedicina(Receta medicamento) {
		this.medicamentos.add(medicamento);
		//Aniadimos la agenda del medicamento a la agenda completa
		anadirMedicamentoAAgenda(medicamento);
	}

	public void ModificarMedicina(int index, Receta medicamento) {
		this.medicamentos.remove(index);
		this.medicamentos.add(index, medicamento);
		//reseteamos la agenda para reflejar los cambios
		refrescarMedicamentoAAgenda();
	}

	public void DeleteMedicina(int index) {
		this.medicamentos.remove(index);
		//reseteamos la agenda para reflejar los cambios
		refrescarMedicamentoAAgenda();
	}

	public void addCuidador(String cuidador) {
		this.cuidadores.add(cuidador);
	}

	public void setEmergencia(Emergencia emergencia) {
		this.estado=true;
		this.emergencia= emergencia;

	}

	public Emergencia getEmergencia() {
		return this.emergencia;
	}


	@Override
	public String toString() {

		return "Apellido: " + this.getApellido1() + " " + this.getApellido2()+ "\nNombre" + this.getNombre() 
		+ "\nFecha de nacimiento: " + this.getFecha_nacimiento_str() + "\nDNI: " + this.getCredencial().getUsuario_dni() 
		+ "\nTelefono: " + this.getTelefono() + "\nEmail: " + this.getCredencial().getEmail();

	}
	public ObservableList<Location> devolverRegistroLocalizaciones() {
		ObservableList<Location> registro = FXCollections.observableArrayList();
		//Si el vector est� vac�a controlamos los null pointer exception
		if(!registroLocalizaciones.isEmpty()) {
			for(int i =0; i<registroLocalizaciones.size(); i++) {
				registro.add(registroLocalizaciones.get(i));
			}
		}
		return registro;

	}


}
