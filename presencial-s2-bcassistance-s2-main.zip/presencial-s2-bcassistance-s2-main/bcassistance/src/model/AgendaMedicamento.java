package model;

import com.jfoenix.controls.JFXCheckBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AgendaMedicamento {
	
	//Se corresponde a la agenda de medicamentos que vemos en la seccion de control de medicamentos
	private String hora;//Maniana, tarde, noche
	private String L;//En los otros strings guardamos Unidades-Medicamentos
	private String M;
	private String X;
	private String J;
	private String V;
	private String S;
	private String D;
	

	//Anades 7 checkbox, uno por cada d�a de la semana, y creas sus respectivos getters y setters
	private transient JFXCheckBox Lunes;
	private transient JFXCheckBox Martes;
	private transient JFXCheckBox Miercoles;
	private transient JFXCheckBox Jueves;
	private transient JFXCheckBox Viernes;
	private transient JFXCheckBox Sabado;
	private transient JFXCheckBox Domingo;
	
	public JFXCheckBox getLunes() {
		return Lunes;
	}
	public void setLunes(JFXCheckBox lunes) {
		Lunes = lunes;
	}
	public JFXCheckBox getMartes() {
		return Martes;
	}
	public void setMartes(JFXCheckBox martes) {
		Martes = martes;
	}
	public JFXCheckBox getMiercoles() {
		return Miercoles;
	}
	public void setMiercoles(JFXCheckBox miercoles) {
		Miercoles = miercoles;
	}
	public JFXCheckBox getJueves() {
		return Jueves;
	}
	public void setJueves(JFXCheckBox jueves) {
		Jueves = jueves;
	}
	public JFXCheckBox getViernes() {
		return Viernes;
	}
	public void setViernes(JFXCheckBox viernes) {
		Viernes = viernes;
	}
	public JFXCheckBox getSabado() {
		return Sabado;
	}
	public void setSabado(JFXCheckBox sabado) {
		Sabado = sabado;
	}
	public JFXCheckBox getDomingo() {
		return Domingo;
	}
	public void setDomingo(JFXCheckBox domingo) {
		Domingo = domingo;
	}

	
	public AgendaMedicamento(String hora, String L, String M, String X, String J, String V, String S, String D) {
		this.hora=hora;
		this.L=L;
		this.M=M;
		this.X=X;
		this.J=J;
		this.V=V;
		this.S=S;
		this.D=D;
	}
	
	//Hacemos un constructor de Agenda Medicamentos en el que s�lo d�ndole la hora del d�a se hace una columna entera
	public AgendaMedicamento(String hora) {
		this.hora=hora;
		this.Lunes= new JFXCheckBox();
		this.Martes=new JFXCheckBox();
		this.Miercoles=new JFXCheckBox();
		this.Jueves=new JFXCheckBox();
		this.Viernes=new JFXCheckBox();
		this.Sabado=new JFXCheckBox();
		this.Domingo=new JFXCheckBox();
	}
	
	//Creamos una funci�n de tipo observable list que nos va a crear todos los checkbox de la agenda
	public static ObservableList<AgendaMedicamento> devolverListaCheckBox(){
		
		ObservableList<AgendaMedicamento> listaCheckBox = FXCollections.observableArrayList();
		
		//Hago los constructores de manana, tarde y noche, y en cada uno se guarda una fila de checkbox por cada d�a de la semana
		AgendaMedicamento maniana= new AgendaMedicamento("Manana");
		AgendaMedicamento mediodia= new AgendaMedicamento("Mediodia");
		AgendaMedicamento noche= new AgendaMedicamento("Noche");

		//Guardo estos constructores en la listaCheckBox:		
		listaCheckBox.add(maniana);
		listaCheckBox.add(mediodia);
		listaCheckBox.add(noche);
		
		//Devuelvo toda la lista de checkbox
		return listaCheckBox;
	}
	
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	public String getL() {
		return L;
	}
	public void setL(String l) {
		L = L+l;
	}
	public String getM() {
		return M;
	}
	public void setM(String m) {
		M = M+m;
	}
	public String getX() {
		return X;
	}
	public void setX(String x) {
		X = X+x;
	}
	public String getJ() {
		return J;
	}
	public void setJ(String j) {
		J = J+j;
	}
	public String getV() {
		return V;
	}
	public void setV(String v) {
		V = V+v;
	}
	public String getS() {
		return S;
	}
	public void setS(String s) {
		S = S+s;
	}
	public String getD() {
		return D;
	}
	public void setD(String d) {
		D = D+d;
	}
	
	
}
