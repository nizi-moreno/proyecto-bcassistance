package model;

import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;


import control.ControladorVentanaVisualizarECG;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;

public class ECGFile {
	String fecha;
	int id;
	Button boton=new Button("Abrir");
	
	//recursos
	private BorderPane panelInsertarApartado;
	static String language;
	private Paciente paciente;

	//Constructor
	public ECGFile(String fecha,int id, BorderPane panelInsertarApartado, String Nlanguage, Paciente paciente) {
		super();
		this.fecha=fecha;
		this.panelInsertarApartado=panelInsertarApartado;
		ECGFile.language=Nlanguage;
		this.setPaciente(paciente);
		
		//El bot�n abre este ECG
		boton.setOnAction(e ->{
			//Cargamos la pantalla de pacientes cuando se presiona el boton "Pacientes"
			System.out.println("Corazon was clicked!");
			//idioma
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Creamos un objeto FXMLLoader para cargar la pantalla
			FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaVisualizarECG.fxml"), bundle);
			//FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaVisualizarECG.fxml"));
			ControladorVentanaVisualizarECG c = new ControladorVentanaVisualizarECG();
			c.setPaciente(paciente);
			c.setFecha(fecha);
			c.setId(id);
			c.setPanelInsertarApartado(panelInsertarApartado);
			ControladorVentanaVisualizarECG.language=language;
			loader.setController(c);
			Parent root;
			try {
				root = loader.load();
				panelInsertarApartado.setCenter(root);
				//panelactual = "Corazon";
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		});
	}

	//GETTERS Y SETTERS
	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}
	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public static String getLanguage() {
		return language;
	}

	public static void setLanguage(String language) {
		ECGFile.language = language;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}

	public Button getBoton() {
		return boton;
	}


	public void setBoton(Button boton) {
		this.boton = boton;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}
	

	
	
	
}
