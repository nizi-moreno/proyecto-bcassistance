package model;

import java.util.Date;
import java.util.Iterator;
import java.util.Vector;

import control.ControladorCifrado;


public class Clinico extends Usuario{

	private Vector<Paciente> pacientes = new Vector<>();
	//Ya no va a guardar al paciente entero, solo su DNI
	private Vector<String> pacientes_id = new Vector<>();
	
	//Constructor
	public Clinico(String nombre, String apellido1, String apellido2, CredencialUsuario credencial, Date fecha_nacimiento,
			int telefono, boolean sexo, String hospital) {
		super(nombre, apellido1, apellido2, credencial, fecha_nacimiento, telefono, sexo);
		//pacientes=new Vector<Paciente>();
	}
	//Constructor para ael registro
	public Clinico(String nombre, String apellido1, String apellido2, CredencialUsuario credencial, Date fecha_nacimiento,
			int telefono, boolean sexo) {
		super(nombre, apellido1, apellido2, credencial, fecha_nacimiento, telefono, sexo);
		//pacientes=new Vector<Paciente>();
		pacientes_id = new Vector<String>();
	}
	
	public Vector<Paciente> getPacientes() {
		return pacientes;
	}
	
	public Vector<String> getPacientes_id() {
		if (pacientes_id==null) {
			pacientes_id = new Vector<String>();
			}
		return pacientes_id;
	}
	
	//Otros metodos
	public void addPaciente(String paciente) {
		this.pacientes_id.add(paciente);
	}
	
	public void addPacienteID(String ID) {
		this.pacientes_id.add(ID);
	}
	
	public void remove(int paciente) {
		this.pacientes_id.removeElementAt(paciente);
	}
	

	public void mostrar_pac(){	
		Iterator<Paciente> itr = pacientes.iterator();
		while (itr.hasNext()) {				
			Paciente actual = itr.next();
			System.out.println(actual);
			System.out.println("-------------------------------");
		}
	}


		
	
	
}
