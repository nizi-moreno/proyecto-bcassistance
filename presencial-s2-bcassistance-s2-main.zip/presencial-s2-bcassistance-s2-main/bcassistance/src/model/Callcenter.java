package model;

import java.util.Date;

public class Callcenter extends Usuario {

	
	public Callcenter(String nombre, String apellido1, String apellido2, CredencialUsuario credencial, Date fecha_nacimiento,
			int telefono, boolean sexo) {			
		super(nombre, apellido1, apellido2, credencial, fecha_nacimiento, telefono, sexo);
	}
	
	public Callcenter(String nombre, String apellido1, String apellido2, CredencialUsuario credencial) {
		super(nombre, apellido1, apellido2, credencial);
	}
	
	//Otros metodos
	
}
