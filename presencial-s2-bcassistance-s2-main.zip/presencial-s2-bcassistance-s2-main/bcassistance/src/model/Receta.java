package model;

import java.util.Vector;
import java.sql.Timestamp;
import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.paint.Color;

public class Receta {

	private int ID;
	private String nombre;
	private String descripcion;
	private String tipoDosis;
	private int unidadesPorToma;
	private int stock_disponible=0;
	private char toma;
	private int frecuencia;                                         //semanas
	private String frecuencia_sem;
	private Vector<AgendaMedicamento> agendaMedicamento;
	private transient JFXButton miBoton;
	private Timestamp fecha;
	//final public transient ImageView imgModificar= (new ImageView(new Image("/Imagenes/modificar.png")));

	public Timestamp getFecha() {
		return fecha;
	}

	public void setCalendar(Timestamp fecha) {
		this.fecha = fecha;
	}

	void handlemiBoton(ActionEvent event) {
		 System.out.println("Holi");
    }

	public Vector<AgendaMedicamento> getAgendaMedicamento() {
		return agendaMedicamento;
	}

	public void setAgendaMedicamento(Vector<AgendaMedicamento> agendaMedicamento) {
		this.agendaMedicamento = agendaMedicamento;
	}

	//Constructor
	public Receta(String nombre, String descripcion, String tipoDosis, int tamanioDosis, int stock_disponible, 
			int frecuencia, Timestamp fecha) {
		super();
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.tipoDosis = tipoDosis;
		this.unidadesPorToma = tamanioDosis;
		this.stock_disponible = stock_disponible;
		this.frecuencia = frecuencia;
		this.fecha=fecha;
		this.setFrecuencia_sem();
		inicializarBotonAnadir();
	}
	
	//Constructor con ID
		public Receta(String nombre, String descripcion, String tipoDosis, int tamanioDosis, int stock_disponible, 
				int frecuencia, Timestamp fecha, int ID) {
			super();
			this.ID=ID;
			this.nombre = nombre;
			this.descripcion = descripcion;
			this.tipoDosis = tipoDosis;
			this.unidadesPorToma = tamanioDosis;
			this.stock_disponible = stock_disponible;
			this.frecuencia = frecuencia;
			this.fecha=fecha;
			this.setFrecuencia_sem();
			inicializarBotonAnadir();
		}

	//Constructor vacio
	public Receta() {
		inicializarBotonAnadir();
	}
	
	//ALEJANDRO, TU TIENES QUE MODIFICAR ESTE HANDLE PARA QUE ABRA LA VENTANITA QUE TIENES QUE DISE�AR :3
	private void inicializarBotonAnadir() {
		//Configuramos los colores del bot�n
		miBoton=new JFXButton("A�adir");
		miBoton.setStyle("-fx-background-color: #ac5050; ");
		miBoton.setTextFill(Color.WHITE);

		//Creamos el ActionEvent
		EventHandler<ActionEvent> buttonHandler = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				//Aqu� va lo que tiene que hacer el bot�n
				System.out.println(":3");
			}
		};
		//Se lo asignamos
		miBoton.setOnAction(buttonHandler);
	}

	public void crearAgendaReceta(String L1, String M1, String X1, String J1, String V1, String S1, String D1, 
			String L2, String M2, String X2, String J2, String V2, String S2, String D2,
			String L3, String M3, String X3, String J3, String V3, String S3, String D3) {//Maniana:1 Mediodia:2 Noche:3
		agendaMedicamento= new Vector<>();

		AgendaMedicamento maniana = new AgendaMedicamento("Manana", L1, M1, X1, J1, V1, S1, D1);
		AgendaMedicamento mediodia = new AgendaMedicamento("Mediodia", L2, M2, X2, J2, V2, S2, D2);
		AgendaMedicamento noche = new AgendaMedicamento("Noche", L3, M3, X3, J3, V3, S3, D3);

		agendaMedicamento.add(maniana);
		agendaMedicamento.add(mediodia);
		agendaMedicamento.add(noche);
	}

	//boton
	public JFXButton getMiBoton() {
		return miBoton;
	}

	public void setMiBoton(JFXButton miBoton) {
		this.miBoton = miBoton;
	}

	//Otros metodos
	public void tomar() {
		int resultado=stock_disponible-unidadesPorToma;
		if (resultado>=0) {
			this.stock_disponible=resultado;
		} else {
			this.stock_disponible=0;
		}
	}

	//Getters y setters
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getTipoDosis() {
		return tipoDosis;
	}
	public void setTipoDosis(String tipoDosis) {
		this.tipoDosis = tipoDosis;
	}

	public int getTamanioDosis() {
		return unidadesPorToma;
	}
	public void setTamanioDosis(int tamanioDosis) {
		this.unidadesPorToma = tamanioDosis;
	}

	public int getStock_disponible() {
		return stock_disponible;
	}
	public void setStock_disponible(int stock_disponible) {
		this.stock_disponible = stock_disponible;
	}

	public int getUnidadesPorToma() {
		return unidadesPorToma;
	}

	public void setUnidadesPorToma(int unidadesPorToma) {
		this.unidadesPorToma = unidadesPorToma;
	}

	public char getToma() {
		return toma;
	}
	public void setToma(char toma) {
		this.toma = toma;
	}

	public int getFrecuencia() {
		return frecuencia*7;
	}
	public void setFrecuencia(int frecuencia) {
		this.frecuencia = frecuencia*7;
	}

	public String getFrecuencia_sem() {
		return frecuencia_sem;
	}

	public void setFrecuencia_sem() {
		if (frecuencia==1) this.frecuencia_sem = frecuencia + " semana";
		else this.frecuencia_sem = frecuencia + " semanas";
	}

	public int getID() {
		return this.ID;
	}
	
	public void setID(int ID) {
		this.ID=ID;
	}
	/*public ImageView getImgModificar() {
	 imgModificar.setOnMouseClicked((MouseEvent e) -> {
	        System.out.println("Se ha hecho click en el medicamento " + nombre);
	    });
		imgModificar.setFitHeight(30);
		imgModificar.setFitWidth(30);
		return imgModificar;
		hola
	}*/
	
	

	

}
