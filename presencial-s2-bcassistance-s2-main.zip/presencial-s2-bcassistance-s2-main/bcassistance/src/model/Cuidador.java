package model;

import java.util.Date;
import java.util.Iterator;
import java.util.Vector;

import control.ControladorCifrado;


public class Cuidador extends Usuario {

	private Vector<Paciente> pacientes;
	//Ya no va a guardar al paciente entero, solo su DNI
	private Vector<String> pacientes_id = new Vector<>();
	private String contacto;


	//Constructor
	public Cuidador(String nombre,String apellido1, String apellido2, CredencialUsuario credencial, Date fecha_nacimiento,
			int telefono, boolean sexo) {
		super(nombre, apellido1, apellido2, credencial, fecha_nacimiento, telefono, sexo);
		pacientes=new Vector<Paciente>();
	}

	public Cuidador() {

	}

	//Getters y setters
	public Vector<Paciente> getPacientes() {
		return pacientes;
	}

	public void setContacto(String contacto) {
		this.contacto = contacto;
	}


	
	public Vector<String> getPacientes_id() {
		return pacientes_id;
	}



	//Otros metodos
	public void addPaciente(String paciente) {
		/*poner que hay que revisar antes si ya esta agregado el paciente*/
		this.pacientes_id.add(paciente);
	}

	public void remove(int posicionPaciente) {
		this.pacientes_id.removeElementAt(posicionPaciente);
	}



	public void mostrar_pac(){	
		Iterator<Paciente> itr = pacientes.iterator();
		while (itr.hasNext()) {				
			Paciente actual = itr.next();
			System.out.println(actual);
			System.out.println("-------------------------------");
		}
	}

	public String getContacto() {
		contacto=getNombre()+" "+getApellido1()+" - "+getTelefono();
		return contacto;
	}




}
