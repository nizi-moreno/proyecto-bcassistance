package model;

import java.util.Date;

public class Emergencia {

	private int ID;
	private boolean reporte_clinico;
	private boolean reporte_callcenter;
	private boolean reporte_cuidador;
	private String ubicacion;
	private Double latitud;
	private Double longitud;
	private Date fecha;
	
	public Emergencia() {
		this.ID = 0;
		this.reporte_clinico = true;
		this.reporte_callcenter = true;
		this.reporte_cuidador = true;
		this.ubicacion="" + latitud + " , " +longitud;
		this.latitud = 0.0;
		this.longitud = 0.0;
		this.fecha = new Date();
		
	}
	
	public Emergencia(String ubicacion) {
		this.reporte_clinico = true;
		this.reporte_callcenter = true;
		this.reporte_cuidador = true;
		this.ubicacion=ubicacion;
	}

	public boolean isReportado() {
		boolean reportado =false;
		if (reporte_callcenter && reporte_clinico && reporte_cuidador) {reportado=true;}
		else {reportado=false;}	
		return reportado;
	}
	
	//Getters and setters

	public boolean isReporte_clinico() {
		return reporte_clinico;
	}

	public void setReporte_clinico(boolean reporte_clinico) {
		this.reporte_clinico = reporte_clinico;
	}

	public boolean isReporte_callcenter() {
		return reporte_callcenter;
	}

	public void setReporte_callcenter(boolean reporte_callcenter) {
		this.reporte_callcenter = reporte_callcenter;
	}

	public boolean isReporte_cuidador() {
		return reporte_cuidador;
	}

	public void setReporte_cuidador(boolean reporte_cuidador) {
		this.reporte_cuidador = reporte_cuidador;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}
	
	public Double getLongitud() {
		return longitud;
	}
	
	public Double getLatitud() {
		return latitud;
	}

	public void setCoordenadas(Double longitud, Double latitud) {
		this.longitud = longitud;
		this.latitud = latitud;
	}
	
	public int getID_Lectura() {
		return ID;
	}

	public void setID(int ID_lectura) {
		this.ID = ID_lectura;
	}
	
	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	
}
