package model;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Mensaje implements Comparable<Mensaje> {

	private String contenido; //No puede sobrepasar los 129 caracteres (incluidos los espacios)
	private Date fecha;
	private String autor;//Guardamos el dni del usuario que ha escrito el mensaje
	private boolean lectura = false;
	private int id_mensaje;
	
	public int getId_mensaje() {
		return id_mensaje;
	}

	public void setId_mensaje(int id_mensaje) {
		this.id_mensaje = id_mensaje;
	}

	public Mensaje(String contenido, Date fecha, String autor) {
		this.contenido=contenido;
		this.fecha=fecha;
		this.autor=autor;
	}
	
	public Mensaje(String contenido, Date fecha, String autor, boolean lectura, int id_mensaje) {
		this.contenido=contenido;
		this.fecha=fecha;
		this.autor=autor;
		this.lectura=lectura;
		this.id_mensaje=id_mensaje;
	}
	
	public String getContenido() {
		return contenido;
	}
	public void setContenido(String contenido) {
		this.contenido = contenido;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	@Override
	public int compareTo(Mensaje o) {
	       if (getFecha() == null || o.getFecha() == null)
	         return 0;
	       return getFecha().compareTo(o.getFecha());
	     }
	
	public String convertirFechaAString() {
		//Metodo para convertir la fecha en un formato String dd/mm/yyyy - hh:mm
		String fechaString="";
		if(fecha!=null) {
			//Creamos un simpleDateFormat
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy - HH:mm");
			fechaString= sdf.format(fecha);
		}
		return fechaString;
	}

	public boolean isLectura() {
		return lectura;
	}

	public void setLectura(boolean lectura) {
		this.lectura = lectura;
	}
}
