package model;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.model.LatLng;

import control.ControladorVentanaLocalizacionGPS;
import control.Main;
import javafx.scene.Parent;
import javafx.scene.layout.BorderPane;

import com.google.maps.model.GeocodingResult;

public class Location {

	private double latitud;
	private double longitud;
	private Date fecha;
	private String fechaEscrita;
	private String direccion;

	//Otros metodos
	public Location(double latitud, double longitud, Date fecha){
		this.latitud=latitud;
		this.longitud=longitud;
		this.fecha= fecha;		
	}

	public String convertirFechaAString() {
		//Metodo para convertir la fecha en un formato String dd/mm/yyyy - hh:mm
		String fechaString="";
		//Creamos un simpleDateFormat
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy - HH:mm");
		fechaString= sdf.format(fecha);
		return fechaString;
	}

	//Getters y setters
	public double getLatitud() {
		return latitud;
	}
	public void setLatitud(double latitud) {
		this.latitud = latitud;
	}
	public double getLongitud() {
		return longitud;
	}
	public void setLongitud(double longitud) {
		this.longitud = longitud;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getFechaEscrita() {
		if(this.fechaEscrita==null) {
			this.fechaEscrita=convertirFechaAString();
		}
		return fechaEscrita;
	}

	public void setFechaEscrita(String fechaEscrita) {
		this.fechaEscrita = fechaEscrita;
	}

	public String getDireccion() {

		//Vamos a utilizar reverse geocoding para obtener la direccion a partir de las coordenadas
		if(this.direccion==null){
			try {
				this.direccion=getFormatedAdress(latitud, longitud, Main.GOOGLE_API_KEY);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getFormatedAdress(double latitude, double longitude, String googleApiKey) throws Exception {
		GeoApiContext context = new GeoApiContext.Builder().apiKey(googleApiKey).build();
		String name = "(Unknown)";
		try {
			GeocodingResult[] results = GeocodingApi.reverseGeocode(context, new LatLng(latitude, longitude)).await();
			for (GeocodingResult result : results) {
				return result.formattedAddress;
			}
		} catch (Exception e) {
			throw new Exception("Error on Reverse Geocoding");
		}
		return name;
	} 




}
