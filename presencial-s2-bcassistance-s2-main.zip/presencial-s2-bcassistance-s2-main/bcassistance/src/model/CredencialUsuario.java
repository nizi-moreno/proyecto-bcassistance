package model;

import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;
import control.ControladorCifrado;

public class CredencialUsuario {
	private int rol;//0: paciente, 1:cuidador, 2:clinico, 3:callcenter
	private String usuario_dni;
	private String contrasena;
	private String email;
	private boolean alta;

	//Constructor
	public CredencialUsuario(int rol, String usuario_dni,String email, String contrasena, boolean alta) {
		this.rol = rol;
		this.usuario_dni = usuario_dni;
		this.contrasena = contrasena;
		this.email=email;
		this.alta=alta;
	}

	public CredencialUsuario() {
		// Para generar la credencial y encriptar la contrasena
	}

	//Getters y setters
	public int getRol() {
		return rol;
	}
	public void setRol(int rol) {
		this.rol = rol;
	}

	public String getUsuario_dni() {
		return usuario_dni;
	}
	public void setUsuario_dni(String usuario_dni) {
		this.usuario_dni = usuario_dni;
	}

	public String getContrasena() {
		return decodePassword(contrasena);
	}
	public void setContrasena(String contrasena) {
		this.contrasena = encodePassword(contrasena);
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isAlta() {
		return alta;
	}

	public void setAlta(boolean alta) {
		this.alta = alta;
	}

	//Encriptaci�n contrase�as con MD5

	static public String encodePassword (String cadena) {
		String encriptacion="";
		ControladorCifrado c = new ControladorCifrado();
		String key = c.leerClaveEncriptacionFichero();
		try{
			//Definimos los objetos necesarios para realizar la encriptaci�n
			//Creamos un objeto de tipo MessageDigest con el tipo de encriptaci�n (MD5)
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			//Transformamos en un array de bytes la llave de encriptaci�n
			byte[] llavePassword = md5.digest(key.getBytes("utf-8"));
			//Creamos otro array de bytes para hacer una copia del array anterior
			byte[] BytesKey = Arrays.copyOf(llavePassword, 24);
			//Creamos una instancia de SecretKey, que utilizaremos para hacer la encriptaci�n
			SecretKey llave = new SecretKeySpec(BytesKey, "DESede");
			//Creamos una instancia de Cipher, que utilizaremos para hacer la encriptaci�n
			Cipher cifrado = Cipher.getInstance("DESede");
			//Definimos el tipo de encriptaci�n y la llave que deseamos usar
			cifrado.init(Cipher.ENCRYPT_MODE, llave);

			//Hacemos la encripaci�n
			//Transformamos la cadena que queremos encriptar en un array de bytes
			byte[] plainTextBytes = cadena.getBytes("utf-8");
			//Creamos un array (ser� nuestro buffer) y colocamos nuestra cadena de bytes anterior
			byte[] buf = cifrado.doFinal(plainTextBytes);//contiene nuestro cifrado
			//Realizamos la encriptaci�n en un array de bytes
			byte[] base64bytes = Base64.encodeBase64(buf);
			encriptacion = new String(base64bytes);

		}catch(Exception ex) {
			System.out.println("Algo ha salido mal durante la encriptaci�n de la contrase�a.");
		}
		return encriptacion;
	}

	static public String decodePassword (String cadena) {

		String desencriptacion="";
		ControladorCifrado c = new ControladorCifrado();
		String key = c.leerClaveEncriptacionFichero();
		try {
			//Seguimos los mismos pasos que en la encriptaci�n, pero en sentido contrario
			byte[] message = Base64.decodeBase64(cadena.getBytes("utf-8"));
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			byte[] digestOfPassword = md5.digest(key.getBytes("utf-8"));
			byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
			SecretKey llave = new SecretKeySpec(keyBytes, "DESede");
			Cipher decipher = Cipher.getInstance("DESede");
			decipher.init(Cipher.DECRYPT_MODE, llave);
			byte[] plainText = decipher.doFinal(message);
			//Obtenemos la cadena desencriptada
			desencriptacion = new String(plainText, "UTF-8");

		} catch (Exception ex) {
			System.out.println("Algo ha salido mal durante la desencriptaci�n de la contrase�a.");
			ex.printStackTrace();
		}
		return desencriptacion;
	}

}
