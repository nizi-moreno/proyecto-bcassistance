package model;

import java.util.Collections;
import java.util.Date;
import java.util.Vector;

public class Ticket implements Comparable<Ticket>{

	private String asunto; //No puede contener m�s de 40 CARACTERES
	private Date fecha;
	private boolean indicadorLectura=false;//Por defecto se han le�do los mensajes
	private Vector<Mensaje> listaMensajes;
	//Guardamos el dni de los dos usuarios que participan en este ticket
	private String credencialA;//callcenter
	private String credencialB;//cuidador
	private EmergenciaChat emergenciaChat;
	private String tituloSinLeer;
	private int id_ticket;
	

	public String getTituloSinLeer() {
		return "Ticket: "+asunto;
	}

	public void setTituloSinLeer(String tituloSinLeer) {
		this.tituloSinLeer = tituloSinLeer;
	}

	public Ticket(String asunto, Mensaje mensajeInicial, Date date, String A, String B) {
		this.asunto=asunto;
		aniadirMensaje(mensajeInicial);
		this.fecha=date;
		this.credencialA=A;
		this.credencialB=B;
	}
	
	public Ticket() {
	}
	
	public Ticket(String asunto, EmergenciaChat emergenciaChat, Date date, String callCenter, String cuidador) {
		this.asunto=asunto;
		this.emergenciaChat=emergenciaChat;
		this.fecha=date;
		this.credencialA=callCenter;
		this.credencialB=cuidador;
	}
	
	public void aniadirMensaje(Mensaje mensaje) {
		//Aniadimos el mensaje a la lista de mensajes
		if(listaMensajes==null) {
			listaMensajes= new Vector<>();
		}
		listaMensajes.add(mensaje);
		//Ordenamos la lista para que los m�s recientes est�n primero
		Collections.sort(listaMensajes);
		//Cambiamos el indicador de lectura
		setIndicadorLectura(true);
	}
	
	public int compareTo(Ticket o) {
	       if (getFecha() == null || o.getFecha() == null)
	         return 0;
	       return getFecha().compareTo(o.getFecha());
	     }
	
	public String getAsunto() {
		return asunto;
	}
	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public boolean isIndicadorLectura() {
		return indicadorLectura;
	}
	public void setIndicadorLectura(boolean indicadorLectura) {
		this.indicadorLectura = indicadorLectura;
	}
	public Vector<Mensaje> getListaMensajes() {
		return listaMensajes;
	}
	public void setListaMensajes(Vector<Mensaje> listaMensajes) {
		this.listaMensajes = listaMensajes;
	}
	public String getCredencialA() {
		return credencialA;
	}
	public void setCredencialA(String credencialA) {
		this.credencialA = credencialA;
	}
	public String getCredencialB() {
		return credencialB;
	}
	public void setCredencialB(String credencialB) {
		this.credencialB = credencialB;
	}

	public EmergenciaChat getEmergenciaChat() {
		return emergenciaChat;
	}

	public void setEmergenciaChat(EmergenciaChat emergenciaChat) {
		this.emergenciaChat = emergenciaChat;
	}
	
	public int getId_ticket() {
		return id_ticket;
	}

	public void setId_ticket(int id_ticket) {
		this.id_ticket = id_ticket;
	}
}
