package model;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Vector;

import javafx.scene.image.Image;

public class Usuario {

	private String nombre;
	private String apellido1;
	private String apellido2;
	//private String email;
	//private String dni;
	//private String contrasena;
	private CredencialUsuario credencial;
	private Date fecha_nacimiento=null;
	private int telefono;
	private boolean sexo;
	private Image imagenPerfil;
	private Vector<Ticket> listaTickets;
	private String nombreYApellidos=null;
	private String nombreYApellido=new String();


	//Constructor
	/*public Usuario(String nombre, String apellido1,String apellido2, String email, String dni, String contrasena, 
			Date fecha_nacimiento, int telefono, boolean sexo) {
		this.nombre=nombre;
		this.apellido1=apellido1;
		this.apellido2=apellido2;
		this.email=email;
		this.dni=dni;
		this.contrasena=contrasena;
		this.fecha_nacimiento=fecha_nacimiento;
		this.telefono=telefono;
		this.sexo=sexo;
	}*/

	public String getNombreYApellido1() {
		setNombreYApellidos(nombre+" "+apellido1);
		return nombreYApellido;
	}


	public void setNombreYApellido(String nombreYApellido) {
		this.nombreYApellido = nombreYApellido;
	}


	public String getNombreYApellidos() {
		if(nombreYApellidos==null) {
			nombreYApellidos= new String();
			setNombreYApellidos(nombre+" "+apellido1+" "+apellido2);
		}
		return nombreYApellidos;
	}

	public void setNombreYApellidos(String nombreYApellidos) {
		this.nombreYApellidos = nombreYApellidos;
	}

	public static Ticket devolverTicketAPartirAsunto(String asunto, Vector<Ticket> listaTickets) {
		Ticket ticket = new Ticket();
		//Recorremos la lista de tickets
		for(int i=0; i<listaTickets.size();i++) {
			if(listaTickets.get(i).getAsunto().equals(asunto)) {
				ticket=listaTickets.get(i);
			}
		}
		return ticket;
	}

	public Usuario(String nombre, String apellido1,String apellido2, CredencialUsuario credencial, Date fecha_nacimiento, int telefono, boolean sexo) {
		this.nombre=nombre;
		this.apellido1=apellido1;
		this.apellido2=apellido2;		
		this.credencial=credencial;
		this.fecha_nacimiento=fecha_nacimiento;
		this.telefono=telefono;
		this.sexo=sexo;

	}

	//Constructor simplificado para el call center
	public Usuario(String nombre, String apellido1,String apellido2, CredencialUsuario credencial) {
		this.nombre=nombre;
		this.apellido1=apellido1;
		this.apellido2=apellido2;		
		this.credencial=credencial;
	}

	public Usuario() {

	}



	//Getters y setters

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido1() {
		return apellido1;
	}
	public void setApellido1(String apellido) {
		this.apellido1 = apellido;
	}

	public Vector<Ticket> getListaTickets() {
		if(listaTickets==null) {
			this.listaTickets=new Vector<>();
		}
		return listaTickets;
	}

	public void aniadirTicket(Ticket ticket) {
		if(listaTickets==null) {
			listaTickets=new Vector<>();
		}
		listaTickets.add(ticket);
		//Ordenamos la lista para que los m�s recientes est�n primero
		Comparator<Ticket> comparador = Collections.reverseOrder();
		Collections.sort(listaTickets, comparador);
	}

	public void setListaTickets(Vector<Ticket> listaTickets) {
		this.listaTickets = listaTickets;
	}
	public String getApellido2() {
		return apellido2;
	}
	public void setApellido2(String apellido) {
		this.apellido2 = apellido;
	}

	/*public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		//Para que se actualice tambien la credencial
		this.credencial.setUsuario(dni);
		this.dni = dni;
	}*/

	public CredencialUsuario getCredencial() {
		return credencial;
	}
	public void setCredencial(CredencialUsuario credencial) {
		this.credencial = credencial;
	}

	public Date getFecha_nacimiento() {
		return fecha_nacimiento;
	}
	//Observacion: este get lo hice para que devolviera la fecha en String y no en Date
	public String getFecha_nacimiento_str() {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		return format.format(fecha_nacimiento);
	}
	public void setFecha_nacimiento(Date fecha_nacimiento) {
		this.fecha_nacimiento = fecha_nacimiento;
	}

	public int getTelefono() {
		return telefono;
	}
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public boolean getSexo() {
		return sexo;
	}
	public void setSexo(boolean sexo) {
		this.sexo = sexo;
	}

	public Image getImagenPerfil() {
		return imagenPerfil;
	}

	public void setImagenPerfil(Image imagenPerfil) {
		this.imagenPerfil = imagenPerfil;
	}
}
