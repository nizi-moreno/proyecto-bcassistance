package control;

import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import model.CredencialUsuario;
import model.EmergenciaChat;
import model.Location;
import model.Paciente;
import model.Receta;
import model.Usuario;

public class ControladorBLPaciente {
	static CredencialUsuario UsuarioLogueado;
	static Paciente paciente;

	@FXML
	private ImageView imagenUsuario;

	@FXML
	private Label nombreUsuario;

	@FXML
	private Label pacient;

	@FXML
	private JFXButton botonInicio;

	@FXML
	private JFXButton botonLocalizacionGPS;

	@FXML
	private JFXButton botonMedicamentos;

	@FXML
	private JFXButton botonTickets;

	@FXML
	private JFXButton botonCorazon;

	@FXML
	private JFXButton botonPerfil;

	@FXML
	private JFXButton botonCerrarSesion;

	@FXML
	private JFXButton botonEmergencia;

	@FXML
	private BorderPane panelInsertarApartado;

	static String language;

	private String panelactual = "Inicio";

	//Esta es la ventana donde va TODO
	private Stage window;

	private CheckTMService checkMedicamentos;

	//Getters y setters de la window
	public Stage getWindow() {
		return window;
	}

	public void setWindow(Stage window) {
		this.window = window;
	}

	private void setLabelNombre() {
		nombreUsuario.setText(paciente.getNombre() + " " + paciente.getApellido1());
	}

	@FXML
	void handleBotonEmergencia(ActionEvent event) {

		//Cuando se pulsa este boton se crea un nuevo ticket que se mandara en un chat entre un call center (aleatoriamente se dividen las alertas)
		//y a todos los cuidadores del paciente

		Date fecha = new Date();
		//De momento, creo este vector con  distintas coordenadas y con un numero aleatorio, sacamos una de ellas
		Vector<Location> localizaciones = new Vector<>();

		localizaciones.add(new Location(40.4165, -3.70256, fecha));
		localizaciones.add(new Location(40.38897, -3.74569, fecha));
		localizaciones.add(new Location(40.39354, -3.662, fecha));
		localizaciones.add(new Location(40.3571, -3.90059, fecha));
		localizaciones.add(new Location(40.5474600, -3.6419700, fecha));

		int numRandom =(int) (Math.random() * 4) + 0;

		double latitud=localizaciones.get(numRandom).getLatitud();
		double longitud=localizaciones.get(numRandom).getLongitud();

		//Creamos el objeto EmergenciaChat
		Location localizacion = new Location(latitud, longitud, fecha);
		EmergenciaChat emergencia = new EmergenciaChat(localizacion, paciente.getCredencial().getUsuario_dni());
	
		
		//Escogemos uno de los call centers al azar para que se encargue de dar el aviso
		
		//HAY QUE HACER ESTA PARTE CON LA BBDD
		
		/*ControladorFicherosJson c = new ControladorFicherosJson();
		Vector<Callcenter> listaCallcenters = c.deserializarJsonCallcentersAArray();
		int positionCallcenter =(int) (Math.random() *(listaCallcenters.size()-1)) + 0;

		//Creamos un nuevo ticket para cada cuidador, que lo ver� su call center asignado
		//Para ello, recorremos la lista de cuidadores del paciente
		Vector<Cuidador> listaCuidadores = c.deserializarJsonCuidadoresAArray();
		Vector<String> dniCuidadores = paciente.getCuidadores();

		for(int i=0; i<dniCuidadores.size();i++) {
			for(int j=0; j<listaCuidadores.size(); j++) {
				if(dniCuidadores.get(i).equals(listaCuidadores.get(j).getCredencial().getUsuario_dni())) {
					//Si se trata de un cuidador asociado al paciente...
					//Creamos el ticket
					Ticket ticket = new Ticket("Emergencia - "+paciente.getCredencial().getUsuario_dni(), emergencia, fecha, 
							listaCallcenters.get(positionCallcenter).getCredencial().getUsuario_dni(), dniCuidadores.get(i));
					//Lo aniadimos al cuidador
					listaCuidadores.get(j).aniadirTicket(ticket);
					//Lo aniadimos al callcenter
					listaCallcenters.get(positionCallcenter).aniadirTicket(ticket);
				}
			}
		}

		//Actualizamos los ficheros
		c.serializarArrayCallcentersAJson(listaCallcenters);
		c.serializarArrayCuidadoresAJson(listaCuidadores);

		//Por ultimo, se abrira una ventana emergente para confirmar el aviso
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/VentanaEmergenteVerificarEmergencia.fxml"),bundle);
			ControladorVentanaEmergenteVerificarEmergencia control = new ControladorVentanaEmergenteVerificarEmergencia();
			ControladorVentanaEmergenteVerificarEmergencia.language=language;
			loader.setController(control);
			Parent root = loader.load();
			Stage miStage = new Stage();
			miStage.setTitle("Verificacion de Emergencia");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(((Node) event.getSource()).getScene().getWindow());
			miStage.setScene(new Scene(root));
			miStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}

		//Despues, deshabilitamos el boton de emergencia (para que no se den 1000 avisos a la vez)
		botonEmergencia.setVisible(false);
		
		//Crear emergencia
		paciente.setEmergencia(localizacion.getDireccion());
		
		//Como se le crean tickets a call center y cuidador, ya estan avisados y se pone el reporte a true
		paciente.getEmergencia().setReporte_callcenter(true);
		paciente.getEmergencia().setReporte_cuidador(true);
		
		c.buscarYactualizarPaciente(paciente);*/
	}

	@FXML
	void handleButtonCerrarSesion(ActionEvent event) {
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);

			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/GUI_Login.fxml"), bundle);
			ControladorLogin controlador1= new ControladorLogin();
			controlador1.indicarCierreSesion();
			controlador1.setWindow(window);
			loader.setController(controlador1);
			Parent root= loader.load();
			//Le asignamos al window su scene
			window.setScene(new Scene(root));
			window.show();
			checkMedicamentos.cancel();


		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonInicio(ActionEvent event) {		
		//Cargamos la pantalla de inicio del paciente
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);

		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/ResumenUsuarioPaciente.fxml"), bundle);
		ControladorResumenPaciente c = new ControladorResumenPaciente();
		ControladorResumenPaciente.language=language;
		ControladorResumenPaciente.UsuarioLogueado=UsuarioLogueado;
		c.setPacienteRepresentado(paciente);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "Inicio";
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonLocalizacionGPS(ActionEvent event) {
		//Aqui va a cargarse el panel de la localizaci�n gps del paciente
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Medicamentos"
		System.out.println("LocalizacionGPS was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaLocalizacionGPS.fxml"), bundle);
		ControladorVentanaLocalizacionGPS c = new ControladorVentanaLocalizacionGPS();
		ControladorVentanaLocalizacionGPS.language=language;
		ControladorVentanaLocalizacionGPS.paciente=paciente;
		ControladorVentanaLocalizacionGPS.usuarioLogueado=UsuarioLogueado;
		//c.setPaciente(paciente);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "LocalizacionGPS";
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonMedicamentos(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Medicamentos"
		System.out.println("Medicamentos was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaControlMedicamentosPaciente.fxml"), bundle);
		ControladorVentanaControlMedicamentosPaciente c = new ControladorVentanaControlMedicamentosPaciente();
		ControladorVentanaControlMedicamentosPaciente.language=language;
		c.setPanelInsertarApartado(panelInsertarApartado);
		c.setPaciente(paciente);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "Medicamentos";
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonTickets(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Pacientes"
		System.out.println("Comunicacion was clicked!");
		//Convierto el clinico en usuario generico para la venta de comunicacion
		Usuario usuario = new Usuario(paciente.getNombre(), paciente.getApellido1(), paciente.getApellido2(), UsuarioLogueado, 
				paciente.getFecha_nacimiento(), paciente.getTelefono(), paciente.getSexo());
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaPrincipalComunicacion.fxml"), bundle);
		ControladorVentanaPrincipalComunicacion c = new ControladorVentanaPrincipalComunicacion();
		ControladorVentanaPrincipalComunicacion.usuarioLogueado=UsuarioLogueado;
		ControladorVentanaPrincipalComunicacion.user=usuario;
		ControladorVentanaPrincipalComunicacion.language=language;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonPerfil(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Medicamentos"
		System.out.println("Perfil was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/PerfilPaciente.fxml"), bundle);
		ControladorPerfilPaciente c = new ControladorPerfilPaciente();
		c.setControladorBL(this);
		ControladorPerfilPaciente.language=language;
		ControladorPerfilPaciente.paciente=paciente;
		ControladorPerfilPaciente.UsuarioLogueado=UsuarioLogueado;
		//c.setPaciente(paciente);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "Perfil";
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	@FXML
	void CorazonPulsado(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Pacientes"
		System.out.println("Corazon was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaCorazonPaciente.fxml"), bundle);	///view/VentanaCorazonECGPaciente.fxml
		ControladorVentanaCorazonPaciente c = new ControladorVentanaCorazonPaciente();	//ControladorVentanaCorazonECGPaciente
		ControladorVentanaCorazonPaciente.language=language;
		c.setUsuarioLogueado(UsuarioLogueado);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			//panelactual = "Perfil";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//Revisamos la hora para avisar la toma de medicamentos
	void revisarHora() {
		//REVISAR SI HAY MEDICAMENTOS
		checkMedicamentos = new CheckTMService(paciente);
		//Poner mas tiempo luego (300 sec es 5 min)
		checkMedicamentos.setPeriod(Duration.seconds(300));
		checkMedicamentos.setOnSucceeded(e -> {
			//Recoge el valor que regresa el task
			Vector<Receta> medicinaaviso = (Vector<Receta>) checkMedicamentos.getValue();
			//Si no regresa null, hay medicina que avisar y muestra el aviso
			if (medicinaaviso!=null && medicinaaviso.size()>0) {
				System.out.println("Hay" + medicinaaviso.size() );
				mostrarVETomaMedicamentos(medicinaaviso);
			}

		});
		checkMedicamentos.setOnFailed(e -> {System.out.println("Hubo un error con el check medicamentos");});
		checkMedicamentos.start();
	}  


	@SuppressWarnings("deprecation")
	public void mostrarVETomaMedicamentos(Vector<Receta> medicinaaviso) {
		try {
			Date date=java.util.Calendar.getInstance().getTime();
			int horadeldia=0;
			if (date.getHours()<14) {
				horadeldia=0;
			} else if (date.getHours()==14) {
				horadeldia=1;
			} else if (date.getHours()==20) {
				horadeldia=2;
			}
			
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Cargo la ruta del fxml del GUI:
			FXMLLoader loader2= new FXMLLoader (getClass().getResource("/view/AvisoTomaMedicamento.fxml"), bundle);
			ControladorVentanaEmergenteAvisoToma controlador2= new ControladorVentanaEmergenteAvisoToma();
			ControladorVentanaEmergenteAvisoToma.medicamentos= medicinaaviso;
			ControladorVentanaEmergenteAvisoToma.paciente= paciente;
			ControladorVentanaEmergenteAvisoToma.language= language;
			controlador2.setFecha(horadeldia, date.getDay());
			controlador2.setPanelInsertarApartado(panelInsertarApartado);
			loader2.setController(controlador2);
			Parent root= loader2.load();
			//Le asignamos al window su scene
			Stage miStage = new Stage();
			miStage.setScene(new Scene(root));
			miStage.setResizable(true);
			miStage.setTitle("Aviso Toma de Medicamento");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(botonCerrarSesion.getScene().getWindow());
			//Para controlar el cierre de la ventana emergente
			miStage.setOnCloseRequest(e -> {
				e.consume();
				ControladorVentanaEmergenteAvisoToma.checkPastillero.cancel(); //Se cierra el hilo del pastillero
				//Cerramos la ventana emergente
				miStage.close();
			});
			miStage.show();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	void abrirPaginaInicio() {
		//Cargamos la pantalla de inicio del paciente
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);

		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/ResumenUsuarioPaciente.fxml"), bundle);
		ControladorResumenPaciente c = new ControladorResumenPaciente();
		ControladorResumenPaciente.language=language;
		ControladorResumenPaciente.UsuarioLogueado=UsuarioLogueado;
		c.setPacienteRepresentado(paciente);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "Inicio";
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void actualizarImagenPerfil() {
		try{
			ControladorBBDD cBBDD = new ControladorBBDD();
			Image imagen = cBBDD.getFotoPerfil(UsuarioLogueado.getUsuario_dni());
			if(imagen!=null) {
				imagenUsuario.setImage(imagen);
			}
		}catch (Exception e) {
			//No tiene imagen de perfil
		}
	}
	
	
	@FXML
	void initialize() {
		assert panelInsertarApartado != null : "fx:id=\"panelInsertarApartado\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenUsuario\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert nombreUsuario != null : "fx:id=\"nombreUsuario\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert pacient != null : "fx:id=\"pacient\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert botonInicio != null : "fx:id=\"botonInicio\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert botonLocalizacionGPS != null : "fx:id=\"botonActividadFisica\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert botonMedicamentos != null : "fx:id=\"botonMedicamentos\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert botonTickets != null : "fx:id=\"botonTickets\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert botonCorazon != null : "fx:id=\"botonCorazon\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert botonPerfil != null : "fx:id=\"botonPerfil\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		assert botonCerrarSesion != null : "fx:id=\"botonCerrarSesion\" was not injected: check your FXML file 'BarraLateralPaciente.fxml'.";
		
		setLabelNombre();
		//Llamamos al metodo alerta toma de medicamentos
		revisarHora();
		//Abrimos por defecto la pagina de inicio
		abrirPaginaInicio();
		//Cargamos su imagen de perfil
		actualizarImagenPerfil();
		
		//Ocultamos el boton de emergencia puesto que ya no ofrece funcionalidad
		botonEmergencia.setVisible(false);

	}
	
	public void actualizarDatosUsuario() {
		actualizarImagenPerfil();
		setLabelNombre();
	}


}