package control;

import java.util.Date;
import java.util.Iterator;
import java.util.Vector;

import javafx.concurrent.Task;
import model.AgendaMedicamento;
import model.Clinico;
import model.Cuidador;
import model.Paciente;
import model.Receta;

public class CheckTMTask extends Task<Vector<Receta>> {

	private Paciente paciente;
	
	//Le paso un paciente para revisar su medicacion
	public CheckTMTask(Paciente paciente) {
		this.paciente=paciente;
	}
	
	@Override
	protected void succeeded() {
		super.succeeded();
		System.out.println("Se ha terminado de revisar");
		// e.g. show "copy finished" dialog
	}

	@Override
	protected void running() {
		super.running();
		System.out.println("Revisando...");
		// e.g. change mouse courser
	}

	@Override
	protected void failed() {
		super.failed();
		System.out.println("Ha pasado un error en el task");// do stuff if call threw an excpetion
		
	}

	@Override
	protected Vector<Receta> call () throws Exception {
		
		Vector <Receta> medicamentosdehoy = new Vector<Receta>();

		try{  
			//Para ver la hora y el dia
			Date date=java.util.Calendar.getInstance().getTime();	
			System.out.println("Es la hora " + date.getHours());
	
			//Si son las 8 am, avisar los de la manana
			if (date.getHours()==8 && date.getMinutes()==0 ) { 
				//Se le pasa la hora del dia (0=manana) y el dia 
				medicamentosdehoy = recogerLosMedicamentos(0, date.getDay());
			}
			//Si son las 2 pm, avisar los de tarde
			else if (date.getHours()==14 && date.getMinutes()==0) { 
				medicamentosdehoy = recogerLosMedicamentos(1, date.getDay());
			}
			//Si son las 8 pm, avisar los de la noche
			else if (date.getHours()==20 && date.getMinutes()==0) { 
				medicamentosdehoy = recogerLosMedicamentos(2, date.getDay());
			}
			else {
				System.out.println("Todavia no es hora del recordatorio");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		return medicamentosdehoy;
	}

	Vector<Receta> recogerLosMedicamentos(int horadeldia, int dia) {
		//horadel dia 0=manana 1=tarde 2=noche
		//dias va del 0 (domingo) al 6 (sabado)
		Vector <Receta> medicamentosdehoy = new Vector<Receta>();
		Iterator<Receta> itr = paciente.getMedicamentos().iterator();
		Receta medicamentos = null;
		
		switch (dia) {
		case 0:
			while (itr.hasNext()) {
				medicamentos = itr.next();
				// Si el medicamento toca toma el domingo en la manana
				if (!medicamentos.getAgendaMedicamento().get(horadeldia).getD().equals("")) {
					System.out.println("Agregado: " + medicamentos.getNombre());
					medicamentosdehoy.add(medicamentos);
				}
			}
			break;
		case 1:
			while (itr.hasNext()) {
				medicamentos = itr.next();
				// Si el medicamento toca toma el lunes en la manana
				if (!medicamentos.getAgendaMedicamento().get(horadeldia).getL().equals("")) {
					System.out.println("Agregado: " + medicamentos.getNombre());
					medicamentosdehoy.add(medicamentos);
				}
			}
			break;
		case 2:
			while (itr.hasNext()) {
				medicamentos = itr.next();
				if (!medicamentos.getAgendaMedicamento().get(horadeldia).getM().equals("")) {
					System.out.println("Agregado: " + medicamentos.getNombre());
					medicamentosdehoy.add(medicamentos);
				}
			}
			break;
		case 3:
			while (itr.hasNext()) {
				medicamentos = itr.next();
				if (!medicamentos.getAgendaMedicamento().get(horadeldia).getX().equals("")) {
					System.out.println("Agregado: " + medicamentos.getNombre());
					medicamentosdehoy.add(medicamentos);
				}
			}
			break;
		case 4:
			while (itr.hasNext()) {
				medicamentos = itr.next();
				if (!medicamentos.getAgendaMedicamento().get(horadeldia).getJ().equals("")) {
					System.out.println("Agregado: " + medicamentos.getNombre());
					medicamentosdehoy.add(medicamentos);
				}
			}
			break;
		case 5:
			while (itr.hasNext()) {
				medicamentos = itr.next();
				if (!medicamentos.getAgendaMedicamento().get(horadeldia).getV().equals("")) {
					System.out.println("Agregado: " + medicamentos.getNombre());
					medicamentosdehoy.add(medicamentos);
				}
			}
			break;
		case 6:
			while (itr.hasNext()) {
				medicamentos = itr.next();
				if (!medicamentos.getAgendaMedicamento().get(horadeldia).getS().equals("")) {
					System.out.println("Agregado: " + medicamentos.getNombre());
					medicamentosdehoy.add(medicamentos);
				}
			}
			break;
		default:
			break;
		}
		
		return medicamentosdehoy;
	}
	
}
