package control;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ControladorVentanaEmergenteVerificarEmergencia {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView image;

    @FXML
    private Label labelPermanecerEspera;

    @FXML
    private Label labelServicios;

    @FXML
    private Button botonAceptar;

    @FXML
    private Label labelCuidadores;

    static String language;
    
    @FXML
    void handleBotonAceptar(ActionEvent event) {
    	//Cerramos la ventana emergente
   		Stage stage = (Stage) labelCuidadores.getScene().getWindow();
   		stage.close();
    }

    @FXML
    void initialize() {
        assert image != null : "fx:id=\"image\" was not injected: check your FXML file 'VentanaEmergenteVerificarEmergencia.fxml'.";
        assert labelPermanecerEspera != null : "fx:id=\"labelPermanecerEspera\" was not injected: check your FXML file 'VentanaEmergenteVerificarEmergencia.fxml'.";
        assert labelServicios != null : "fx:id=\"labelServicios\" was not injected: check your FXML file 'VentanaEmergenteVerificarEmergencia.fxml'.";
        assert botonAceptar != null : "fx:id=\"botonAceptar\" was not injected: check your FXML file 'VentanaEmergenteVerificarEmergencia.fxml'.";
        assert labelCuidadores != null : "fx:id=\"labelCuidadores\" was not injected: check your FXML file 'VentanaEmergenteVerificarEmergencia.fxml'.";

    }
}