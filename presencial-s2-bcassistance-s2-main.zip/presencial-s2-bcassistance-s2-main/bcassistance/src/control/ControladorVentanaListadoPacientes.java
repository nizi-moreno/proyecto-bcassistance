package control;

import com.jfoenix.controls.JFXButton;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;
import model.Usuario;

public class ControladorVentanaListadoPacientes {
	
	static CredencialUsuario UsuarioLogueado;
	
	static BorderPane panelInsertarApartado;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;
	
    @FXML
    private GridPane gridPane;

	@FXML
	private Label tituloPacientes;

	@FXML
	private Label DescripcionApartado;

	@FXML
	private JFXButton botonAnadirPaciente;

	static String language;
	
	@FXML
	void handleAnadirPaciente(MouseEvent event) {
		System.out.println("boton aniadir paciente");
		//Esto nos abre la ventana para meter el DNI
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/VentanaEmergenteAnadirPaciente.fxml"), bundle);	//Importamos el fxml de la segunda ventana
			ControladorVentanaEmergenteAnadirPaciente control2 = new ControladorVentanaEmergenteAnadirPaciente();	//Creamos el controlador DE LA SEGUNDA VENTANA
			ControladorVentanaEmergenteAnadirPaciente.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaEmergenteAnadirPaciente.language = language;
			ControladorVentanaEmergenteAnadirPaciente.panelInsertarApartado=panelInsertarApartado;
			loader2.setController(control2);				//Al loader (FXML) le asignamoos su controlador			
			Parent root = loader2.load();				//Asignamos como root el fxml
			Stage miStage = new Stage();
			miStage.setScene(new Scene(root));		//El root pasa a ser una escena y la escena pasa a ser primaryStage
			miStage.setTitle("Anadir Paciente");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(((Node) event.getSource()).getScene().getWindow());
			miStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	void mostrarListaPacientes() {//0: paciente, 1:cuidador, 2:clinico, 3:callcenter
		
		//Dependiendo del rol de la credencial, accedemos a una lista u otra
		//ControladorFicherosJson c = new ControladorFicherosJson();
		ControladorBBDD cBBDD = new ControladorBBDD();
		Vector<String> listadoPacientesID =new Vector<>();
		Vector<Paciente> listadoPacientes = new Vector<>();
		
		if (UsuarioLogueado.getRol()==1) {//Cuidador
			//Buscamos al cuidador en el fichero json
			
			listadoPacientesID = cBBDD.listadoPacientesdeCuidador(UsuarioLogueado.getUsuario_dni());
			
			listadoPacientes = cBBDD.BuscarListaPaciente(listadoPacientesID);
			
			
		}else if(UsuarioLogueado.getRol()==2) {//Clinico
			//Buscamos al clinico en el fichero json
			
			listadoPacientesID = cBBDD.listadoPacientesdeClinico(UsuarioLogueado.getUsuario_dni());
			
			listadoPacientes = cBBDD.BuscarListaPaciente(listadoPacientesID);
			
		}
		//ORDENAR
		quicksort(listadoPacientes, 0, listadoPacientes.size());
		
		//Ahora que ya tenemos el listado de pacientes pasamos a crear un gridpane que se ajuste al size() de la lista
		//Siempre vamos a tener 3 columnas, pero hay que ver cuantas filas necesitamos para mostrar a todos los pacientes
		//En cada celda del gridPane meteremos la representacion de un Paciente, tama�o de la celda == 300x300
		
		//int celdasNecesarias = listadoPacientesID.size();//Las celdas que necesitamos = cantidad pacientes
		int celdasNecesarias = listadoPacientes.size();//Las celdas que necesitamos = cantidad pacientes
		
		//Configuramos el gridpane con un bucle, hasta haber colocado a todos los pacientes
		int x=0;//fila
		int y=0;//columna^
		
		for(int j=0; j<celdasNecesarias;j++) {
			//Por cada paciente, creamos su representaci�n en formato cuadrado y lo colocamos en el gridpane
			//idioma
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Creamos un objeto FXMLLoader para cargar la pantalla
			FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/RepresentacionPacienteFormatoCuadrado.fxml"), bundle);
			ControladorVentanaRepresentacionPacienteFormatoCuadrado.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaRepresentacionPacienteFormatoCuadrado.language=language;
			ControladorVentanaRepresentacionPacienteFormatoCuadrado controlador = new ControladorVentanaRepresentacionPacienteFormatoCuadrado();
			controlador.setPanelInsertarApartado(panelInsertarApartado);
			//Le pasamos al controlador el paciente a representar
			controlador.setPacienteRepresentado(listadoPacientes.get(j));
			loader.setController(controlador);
			Parent root;
			try {
				root = loader.load();
				gridPane.add(root, y, x);//A�adimos el paciente al gridPane
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Comparamos las posiciones del gridPane
			if(y==2) {//Reseteamos la y, ya que hemos llenado una fila
				y=0;
				x++;
			}else {
				y++;
			}
		}
	}

	@FXML
	void initialize() {
		assert tituloPacientes != null : "fx:id=\"tituloPacientes\" was not injected: check your FXML file 'VentanaListadoPacientes.fxml'.";
		assert DescripcionApartado != null : "fx:id=\"DescripcionApartado\" was not injected: check your FXML file 'VentanaListadoPacientes.fxml'.";
		assert botonAnadirPaciente != null : "fx:id=\"botonAnadirPaciente\" was not injected: check your FXML file 'VentanaListadoPacientes.fxml'.";
		//Al inicializarse la ventana se muestra la lista de pacientes del Cuidador/Clinico
		mostrarListaPacientes();
	}
	
	//IMPLEMENTACI�N DE QUICKSORT CON EL VECTOR DE PACIENTES
	//M�todo quicksort para valores double 
	public static void quicksort(Vector<Paciente> L, int ini, int fin) {
		if (ini < fin) {	//Si el tama�o del vector es superior a uno
			int x=pivotar(L, ini, fin);
			quicksort(L, ini, x-1);
			quicksort(L, x+1, fin);
		}
	}
	
	//M�todo pivotar para un array de valores tipo double y los ordenamos no crecientemente
	public static int pivotar(Vector<Paciente> l, int ini, int fin) {

		int i = ini;	//Posicion inicial del vector
		String pivote = l.elementAt(ini).getApellido1();	//Cogemos como pivote la posici�n inicial del vector

		if (ini < fin) { // Comprobamos tama�o del vector superior a uno. Sino no hacemos nada pues ya est� ordenado

			for (int j = ini + 1; j < fin; j++) {	//Comenzamos a recorrer desde la posici�n siguiente al inicio (pivote)
				if (l.elementAt(j).getApellido1().compareTo(pivote)<=0) {	//Comparamos los dos strings para ordenar
					i++;
					if (i != j) {
						
						// intercambiar posici�n i y j
						Paciente buffer = l.elementAt(i);
						l.setElementAt(l.elementAt(j), i);
						l.setElementAt(buffer, j);
					}
				}
			}
			// intercambiar posici�n ini y i
			Paciente buffer = l.elementAt(ini);
			l.setElementAt(l.elementAt(i), ini);
			l.setElementAt(buffer, i);
			
		}
		return i;
	}
}
