package control;

import com.jfoenix.controls.JFXButton;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;

public class ControladorBLCuidador {

	static CredencialUsuario UsuarioLogueado;

	static Cuidador cuidador;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private BorderPane panelInsertarApartado;

	@FXML
	private ImageView imagenUsuario;

	@FXML
	private Label labelNombreUsuario;

	@FXML
	private Label labelPerfil;

	@FXML
	private JFXButton botonPacientes;

	@FXML
	private JFXButton botonComunicacion;

	@FXML
	private JFXButton botonPerfil;

	@FXML
	private JFXButton botonCerrarSesion;

	static String language;

	private String panelactual = "Inicio";

	CheckEService<Cuidador> checkEmergencia;

	//Esta es la ventana donde va TODO
	private Stage window;


	//Getters y setters de la window
	public Stage getWindow() {
		return window;
	}

	public void setWindow(Stage window) {
		this.window = window;
	}


	@FXML
	void handleBotonCerrarSesion(ActionEvent event) {
		try {
			checkEmergencia.cancel();	//Cerramos el hilo al cerrar sesi�n
			System.out.println("Se ha cerrado sesion y el hilo de comprobar pacientes se ha cerrado");
			Locale locale = new Locale("es_ES");
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);

			//Cargo la ruta del fxml de la p�gina de login:
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/GUI_Login.fxml"), bundle);
			ControladorLogin controlador1= new ControladorLogin();
			controlador1.indicarCierreSesion();
			controlador1.setWindow(window);
			loader.setController(controlador1);
			Parent root= loader.load();
			//Le asignamos al window su scene
			window.setScene(new Scene(root));
			window.show();


		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonComunicacion(ActionEvent event) {
		//Abrimos el apartado de comunicacion especial para emergencias

		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/VentanaComunicacionEmergencias.fxml"), bundle);
		ControladorVentanaComunicacionEmergencias c = new ControladorVentanaComunicacionEmergencias();
		ControladorVentanaComunicacionEmergencias.language=language;
		c.setPanelInsertarApartado(panelInsertarApartado);
		c.setUsuarioLogueado(cuidador);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonPacientes(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Pacientes"
		System.out.println("Pacientes was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaListadoPacientes.fxml"), bundle);
		ControladorVentanaListadoPacientes c = new ControladorVentanaListadoPacientes();
		ControladorVentanaListadoPacientes.UsuarioLogueado=UsuarioLogueado;
		ControladorVentanaListadoPacientes.language=language;
		ControladorVentanaListadoPacientes.panelInsertarApartado=panelInsertarApartado;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "Pacientes";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonPerfil(ActionEvent event) {
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/PerfilCuidador.fxml"), bundle);
		ControladorPerfilCuidador cuidadorc = new ControladorPerfilCuidador();
		ControladorPerfilCuidador.language=language;
		cuidadorc.setControladorBL(this);
		ControladorPerfilCuidador.cuidador=cuidador;
		ControladorPerfilCuidador.UsuarioLogueado=UsuarioLogueado;
		loader.setController(cuidadorc);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "Perfil";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	} 

	private void setLabelNombre() {
		labelNombreUsuario.setText(cuidador.getNombre() + " " + cuidador.getApellido1());
	}

	void revisarEmergencias() {

		ControladorBBDD cBBDD = new ControladorBBDD();
		//REVISAR SI HAY EMERGENCIAS
		checkEmergencia = new CheckEService<Cuidador>(cuidador);
		checkEmergencia.setPeriod(Duration.seconds(10));
		checkEmergencia.setOnSucceeded(e -> {
			Paciente paciente_e = (Paciente) checkEmergencia.getValue();

			if (paciente_e!=null && !paciente_e.getEmergencia().isReporte_cuidador()) {
				System.out.println("Paciente es " + paciente_e.getNombre() );
				mostrarEmergenteEmergenciaC(paciente_e);
				paciente_e.getEmergencia().setReporte_cuidador(true);
				//Actualiza el estado de emergencia a false si ya se reportó a todos
				if (paciente_e.getEmergencia().isReportado()) {paciente_e.setEstado(false);}
				//Guardar en la BBDD que se reporto
				cBBDD.actualizarReporteEmergencia(paciente_e.getEmergencia().getID_Lectura(), cuidador.getCredencial().getRol());
			}

		});
		checkEmergencia.setOnFailed(e -> {System.out.println("Hubo un error con el check");});
		checkEmergencia.start();


	}

	public void mostrarEmergenteEmergenciaC(Paciente paciente) {
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Cargo la ruta del fxml del GUI:
			FXMLLoader loader2= new FXMLLoader (getClass().getResource("/view/VentanaEmergenteEmergenciaC.fxml"), bundle);
			ControladorVentanaEmergenteEmergenciaC controlador2= new ControladorVentanaEmergenteEmergenciaC();
			ControladorVentanaEmergenteEmergenciaC.paciente= paciente;
			ControladorVentanaEmergenteEmergenciaC.language= language;
			controlador2.setPanelInsertarApartado(panelInsertarApartado);
			loader2.setController(controlador2);
			Parent root= loader2.load();
			//Le asignamos al window su scene
			Stage miStage = new Stage();
			miStage.setScene(new Scene(root));		//El root pasa a ser una escena y la escena pasa a ser primaryStage
			miStage.setTitle("Emergencia Paciente");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(botonCerrarSesion.getScene().getWindow());
			miStage.show();
			controlador2.LabelMensaje();
			controlador2.LabelUbicacion();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void actualizarImagenPerfil() {
		//Cargamos la imagen de perfil (si tiene una)
		try{
			ControladorBBDD cBBDD = new ControladorBBDD();
			Image imagen = cBBDD.getFotoPerfil(UsuarioLogueado.getUsuario_dni());
			if(imagen!=null) {
				imagenUsuario.setImage(imagen);
			}
			
		}catch (Exception e) {
			//No tiene imagen de perfil
		}
	}


	@FXML
	void initialize() {
		assert panelInsertarApartado != null : "fx:id=\"panelInsertarApartado\" was not injected: check your FXML file 'BarraLateralCuidador.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenUsuario\" was not injected: check your FXML file 'BarraLateralCuidador.fxml'.";
		assert labelNombreUsuario != null : "fx:id=\"labelNombreUsuario\" was not injected: check your FXML file 'BarraLateralCuidador.fxml'.";
		assert labelPerfil != null : "fx:id=\"labelPerfil\" was not injected: check your FXML file 'BarraLateralCuidador.fxml'.";
		assert botonPacientes != null : "fx:id=\"botonPacientes\" was not injected: check your FXML file 'BarraLateralCuidador.fxml'.";
		assert botonComunicacion != null : "fx:id=\"botonComunicacion\" was not injected: check your FXML file 'BarraLateralCuidador.fxml'.";
		assert botonPerfil != null : "fx:id=\"botonPerfil\" was not injected: check your FXML file 'BarraLateralCuidador.fxml'.";
		assert botonCerrarSesion != null : "fx:id=\"botonCerrarSesion\" was not injected: check your FXML file 'BarraLateralCuidador.fxml'.";
		//para que se vea el nombre jeje :) -Sol
		setLabelNombre();
		revisarEmergencias();
		//Cargamos la pantalla de pacientes por defecto
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaListadoPacientes.fxml"), bundle);
		ControladorVentanaListadoPacientes c = new ControladorVentanaListadoPacientes();
		ControladorVentanaListadoPacientes.UsuarioLogueado=UsuarioLogueado;
		ControladorVentanaListadoPacientes.language=language;
		ControladorVentanaListadoPacientes.panelInsertarApartado= panelInsertarApartado;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "Pacientes";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//Cargamos la imagen de perfil (si tiene una)
		actualizarImagenPerfil();

	}

	public void actualizarDatosUsuario() {
		actualizarImagenPerfil();
		setLabelNombre();
	}

}