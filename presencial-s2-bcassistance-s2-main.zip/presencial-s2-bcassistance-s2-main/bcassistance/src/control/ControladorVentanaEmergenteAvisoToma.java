package control;

import java.io.IOException;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.Paciente;
import model.Receta;

public class ControladorVentanaEmergenteAvisoToma {

	static Paciente paciente = new Paciente("", "", "", null, null, 0, false); 
	static Vector<Receta> medicamentos = new Vector<Receta>();
	private int dia;
	private int horadeldia;
	
	
    @FXML
    private ImageView image;

    @FXML
    private Button botonmarcar;

    @FXML
    private Label labeltitulo;

    @FXML
    private Label labelmedicacion;

    @FXML
    private Label labelhora;

    static String language = "es_ES";
    
    static CheckPastilleroService checkPastillero;
    
    private CheckTMService checkMedicamentos;

    private BorderPane panelInsertarApartado;
	
	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}
    
	
   
	void revisarTomaBBDD(){
		
		ControladorBBDD cBBDD = new ControladorBBDD();
		//Recorro los medicamentos del paciente y los del vector de los medicamentos del aviso para marcarlos como tomados
		
		Vector<Receta> listaMedicamentos = cBBDD.getRecetas(paciente.getCredencial().getUsuario_dni());
    	Receta recetaactualpaciente = null; 
    	Receta recetaactual = null;
    	
    	//Para revisar el stock
    	boolean bajostock=false;
    	Vector<Receta> medicamentosBajoStock = new Vector<Receta>();
    	
    	for (int i =0; i<listaMedicamentos.size(); i++) {
    		recetaactualpaciente = paciente.getMedicamentos().get(i);
    		for(int j =0; j<medicamentos.size(); j++) {
    			recetaactual = medicamentos.get(j);
    			if (recetaactualpaciente.getNombre().equals(recetaactual.getNombre())) {
    				
    				System.out.println("Tomado " + recetaactualpaciente.getTamanioDosis() +" "+ 
    						recetaactualpaciente.getTipoDosis()+ " de" +recetaactualpaciente.getNombre());
    				paciente.getMedicamentos().get(i).tomar();
    				
    				//Guardamos la nueva cantidad
    				cBBDD.eliminarStock(paciente.getCredencial().getUsuario_dni(), recetaactual.getNombre());
    				
    				//Revisar stock
    				//Si hay lo equivalente o es menos de 2 tomas
    				if (recetaactualpaciente.getStock_disponible()<=2*recetaactualpaciente.getTamanioDosis() ) {
    					bajostock = true;
    					medicamentosBajoStock.add(recetaactualpaciente);
    				}
    				
    			}
    		}
    	}
        
        //Si el stock de alguno es bajo, mostrar la ventana de bajo stock
        if(bajostock) {
        	MostrarVEBajoStock(medicamentosBajoStock);
        }
        
	}
	
	void revisarPastillero(String DNIPaciente, String valorEsperado) {
		//REVISAR SI ESTA ABIERTO EL PASTILLERO
		checkPastillero = new CheckPastilleroService(DNIPaciente, valorEsperado);
    	//Hacemos un delay de 1s para no saturar las conexiones de la BBDD
		checkPastillero.setPeriod(Duration.seconds(1));
		checkPastillero.setOnSucceeded(e -> {
			//Recoge el valor que regresa el task
			Boolean abierto = (Boolean) checkPastillero.getValue();
			//Cuando ya se ha verificado que ha tomado el medicamento
	    	botonmarcar.setVisible(abierto);

		});
		checkPastillero.setOnFailed(e -> {System.out.println("Hubo un error con el check pastillero");});
		checkPastillero.start();
	}  
	
	public String obtenerValorEsperado() {
		String valor=null;
		
		if(horadeldia==0){
    		switch (dia) {
    		case 0:
    			valor="1D";
    			break;
    		case 1:
    			valor="1L";
    			break;
    		case 2:
    			valor="1M";
    			break;
    		case 3:
    			valor="1X";
    			break;
    		case 4:
    			valor="1J";
    			break;
    		case 5:
    			valor="1V";
    			break;
    		case 6:
    			valor="1S";
    			break;
    		}
    	}
    	else if (horadeldia==1) {
    		switch (dia) {
    		case 0:
    			valor="2D";
    			break;
    		case 1:
    			valor="2L";
    			break;
    		case 2:
    			valor="2M";
    			break;
    		case 3:
    			valor="2X";
    			break;
    		case 4:
    			valor="2J";
    			break;
    		case 5:
    			valor="2V";
    			break;
    		case 6:
    			valor="2S";
    			break;
    		}
    	}
    	
    	else if (horadeldia==2) {
    		switch (dia) {
    		case 0:
    			valor="3D";
    			break;
    		case 1:
    			valor="3L";
    			break;
    		case 2:
    			valor="3M";
    			break;
    		case 3:
    			valor="3X";
    			break;
    		case 4:
    			valor="3J";
    			break;
    		case 5:
    			valor="3V";
    			break;
    		case 6:
    			valor="3S";
    			break;
    		}
    	}
		
		return valor;
	}
	
    @FXML
    void handleBotonMarcar(ActionEvent event) {
    	 checkPastillero.cancel();
    	Stage stage = (Stage) botonmarcar.getScene().getWindow();
        stage.close();
    }
    
    void MostrarVEBajoStock(Vector<Receta> medicamentosBajoStock ) {
    	try {

			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Cargo la ruta del fxml del GUI:
			FXMLLoader loader2= new FXMLLoader (getClass().getResource("/view/VentanaEmergenteBajoStock.fxml"), bundle);
			ControladorVentanaEmergenteBajoStock controlador2= new ControladorVentanaEmergenteBajoStock();
			ControladorVentanaEmergenteBajoStock.medicamentosBajoStock= medicamentosBajoStock;
			ControladorVentanaEmergenteBajoStock.language= language;
			ControladorVentanaEmergenteBajoStock.paciente=paciente;
			controlador2.setPanelInsertarApartado(panelInsertarApartado);
			loader2.setController(controlador2);
			Parent root= loader2.load();
			
			//Le asignamos al window su scene
			Stage miStage = new Stage();
			miStage.setScene(new Scene(root));
			miStage.setResizable(true);
			miStage.setTitle("Aviso Bajo Stock de Medicamento");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(botonmarcar.getScene().getWindow());
			miStage.show();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    
    void LabelHora() {
    	if (language.equals("es_ES")) {
    		labelhora.setText(textFechaEs());
    	} else {
    		labelhora.setText(textFechaEn());
    	}
    				
    }
    
    void LabelMedicacion() {
    	String medicamentostext = "";
    	Iterator<Receta> itr = medicamentos.iterator();
    	Receta recetaactual = null;
    	while (itr.hasNext()) {
    		recetaactual = itr.next();
    		medicamentostext+= recetaactual.getNombre() + " " + recetaactual.getTamanioDosis() + " "
    		+ recetaactual.getTipoDosis() + "\n";
    	}
    	
    	labelmedicacion.setText(medicamentostext);
    }
    
    void setFecha(int horadeldia, int dia) {
    	this.horadeldia=horadeldia;
    	this.dia=dia;
    };
    
    String textFechaEs() {
    	String fecha="";
    	if(horadeldia==0){
    		switch (dia) {
    		case 0:
    			fecha="Medicina de la manana del Domingo";
    			break;
    		case 1:
    			fecha="Medicina de la manana del Lunes";
    			break;
    		case 2:
    			fecha="Medicina de la manana del Martes";
    			break;
    		case 3:
    			fecha="Medicina de la manana del Miercoles";
    			break;
    		case 4:
    			fecha="Medicina de la manana del Jueves";
    			break;
    		case 5:
    			fecha="Medicina de la manana del Viernes";
    			break;
    		case 6:
    			fecha="Medicina de la manana del Sabado";
    			break;
    		}
    	}
    	else if (horadeldia==1) {
    		switch (dia) {
    		case 0:
    			fecha="Medicina de la tarde del Domingo";
    			break;
    		case 1:
    			fecha="Medicina de la tarde del Lunes";
    			break;
    		case 2:
    			fecha="Medicina de la tarde del Martes";
    			break;
    		case 3:
    			fecha="Medicina de la tarde del Miercoles";
    			break;
    		case 4:
    			fecha="Medicina de la tarde del Jueves";
    			break;
    		case 5:
    			fecha="Medicina de la tarde del Viernes";
    			break;
    		case 6:
    			fecha="Medicina de la tarde del Sabado";
    			break;
    		}
    	}
    	
    	else if (horadeldia==2) {
    		switch (dia) {
    		case 0:
    			fecha="Medicina de la noche del Domingo";
    			break;
    		case 1:
    			fecha="Medicina de la noche del Lunes";
    			break;
    		case 2:
    			fecha="Medicina de la noche del Martes";
    			break;
    		case 3:
    			fecha="Medicina de la noche del Miercoles";
    			break;
    		case 4:
    			fecha="Medicina de la noche del Jueves";
    			break;
    		case 5:
    			fecha="Medicina de la noche del Viernes";
    			break;
    		case 6:
    			fecha="Medicina de la noche del Sabado";
    			break;
    		}
    	}
    	
    	return fecha;
    }
    
    String textFechaEn() {
    	String fecha="";
    	if(horadeldia==0){
    		switch (dia) {
    		case 0:
    			fecha="Sunday's morning medicine";
    			break;
    		case 1:
    			fecha="Monday's morning medicine";
    			break;
    		case 2:
    			fecha="Tuesday's morning medicine";
    			break;
    		case 3:
    			fecha="Wednesday's morning medicine";
    			break;
    		case 4:
    			fecha="Thursday's morning medicine";
    			break;
    		case 5:
    			fecha="Friday's morning medicine";
    			break;
    		case 6:
    			fecha="Saturday's morning medicine";
    			break;
    		}
    	}
    	else if (horadeldia==1) {
    		switch (dia) {
    		case 0:
    			fecha="Sunday's afternoon medicine";
    			break;
    		case 1:
    			fecha="Monday's afternoon medicine";
    			break;
    		case 2:
    			fecha="Tuesday's afternoon medicine";
    			break;
    		case 3:
    			fecha="Wednesday's afternoon medicine";
    			break;
    		case 4:
    			fecha="Thursday's afternoon medicine";
    			break;
    		case 5:
    			fecha="Friday's afternoon medicine";
    			break;
    		case 6:
    			fecha="Saturday's afternoon medicine";
    			break;
    		}
    	}
    	
    	else if (horadeldia==2) {
    		switch (dia) {
    		case 0:
    			fecha="Sunday's evening medicine";
    			break;
    		case 1:
    			fecha="Monday's evening medicine";
    			break;
    		case 2:
    			fecha="Tuesday's evening medicine";
    			break;
    		case 3:
    			fecha="Wednesday's evening medicine";
    			break;
    		case 4:
    			fecha="Thursday's evening medicine";
    			break;
    		case 5:
    			fecha="Friday's evening medicine";
    			break;
    		case 6:
    			fecha="Saturday's evening medicine";
    			break;
    		}
    	}
    	
    	return fecha;
    }
    

    @FXML
    void initialize() {
    	assert image != null : "fx:id=\"image\" was not injected: check your FXML file 'AvisoTomaMedicamento.fxml'.";
    	assert botonmarcar != null : "fx:id=\"botonmarcar\" was not injected: check your FXML file 'AvisoTomaMedicamento.fxml'.";
    	assert labeltitulo != null : "fx:id=\"labeltitulo\" was not injected: check your FXML file 'AvisoTomaMedicamento.fxml'.";
    	assert labelhora != null : "fx:id=\"labelhora\" was not injected: check your FXML file 'AvisoTomaMedicamento.fxml'.";
    	assert labelmedicacion != null : "fx:id=\"labelmedicacion\" was not injected: check your FXML file 'AvisoTomaMedicamento.fxml'.";
    	
    	LabelHora();
    	LabelMedicacion();
    	
    	//De forma predeterminada escondemos el boton Aceptar
    	botonmarcar.setVisible(false);
    	revisarPastillero(paciente.getCredencial().getUsuario_dni(), obtenerValorEsperado());
    	
    }
    
}

