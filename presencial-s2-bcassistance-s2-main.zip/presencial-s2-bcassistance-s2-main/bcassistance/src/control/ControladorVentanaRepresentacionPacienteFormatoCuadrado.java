package control;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import model.CredencialUsuario;
import model.Paciente;

public class ControladorVentanaRepresentacionPacienteFormatoCuadrado {

	private BorderPane panelInsertarApartado;

	static CredencialUsuario UsuarioLogueado;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private AnchorPane representacionPaciente;

	@FXML
	private ImageView imagenPaciente;

	@FXML
	private Label LabelNombreEdad;

	@FXML
	private ImageView iconoCorazon;

	@FXML
	private ImageView iconoMedicamento;

	@FXML
	private ImageView iconoDeporte;

	Paciente pacienteRepresentado;

	static String language;

	//Getters y setters del panel
	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}


	@FXML
	void handlePacientePresionado(MouseEvent event) {
		System.out.println("Se ha seleccionado el paciente "+pacienteRepresentado.getNombre());

		//SE DEBE LLEVAR A LA FICHA DEL PACIENTE
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader3 = new FXMLLoader(getClass().getResource("/view/VentanaFichaPaciente.fxml"), bundle);	//Importamos el fxml de la segunda ventana
			ControladorVentanaFichaPaciente control2 = new ControladorVentanaFichaPaciente();	//Creamos el controlador DE LA SEGUNDA VENTANA
			control2.setPanelInsertarApartado(panelInsertarApartado);
			ControladorVentanaFichaPaciente.paciente=pacienteRepresentado;
			ControladorVentanaFichaPaciente.UsuarioLogueado= UsuarioLogueado;
			ControladorVentanaFichaPaciente.language = language;
			loader3.setController(control2);				//Al loader (FXML) le asignamoos su controlador			
			Parent root = loader3.load();				//Asignamos como root el fxml

			panelInsertarApartado.setCenter(root);
			//panelactual = "Pacientes";

		} catch(Exception e) {
			e.printStackTrace();
		}
	}



	void rellenarDatosPaciente() {

		//Cargamos la imagen de perfil (si tiene una)
		try{
			if(pacienteRepresentado.getImagenPerfil()!=null) {
				imagenPaciente.setImage(pacienteRepresentado.getImagenPerfil());
			}
		}catch (Exception e) {
			//No tiene imagen de perfil
		}

		//Configuramos los iconos de estado
		//ESTADO CORAZON
		switch (pacienteRepresentado.getEstadoCorazon()) {
		case 0:
			Image image = new Image("/Imagenes/cora verde.png");
			iconoCorazon.setImage(image);
			break;
		case 1:
			Image image1= new Image("/Imagenes/cora amarillo.png");
			iconoCorazon.setImage(image1);
			break;
		case 2: 
			Image image2= new Image("/Imagenes/cora rojo.png");
			iconoCorazon.setImage(image2);
			break;
		}
		//ESTADO MEDICACION
		switch (pacienteRepresentado.getEstadoMedicacion()) {
		case 0:
			Image image =new Image("/Imagenes/pastilla verde.png");
			iconoMedicamento.setImage(image);
			break;
		case 1:
			Image image1=new Image("/Imagenes/pastilla amarilla.png"); 
			iconoMedicamento.setImage(image1);
			break;
		case 2: 
			Image image2=new Image("/Imagenes/pastilla roja.png"); 
			iconoMedicamento.setImage(image2);
			break;
		}
		//ESTADO ACTIVIDAD FISICA
		switch (pacienteRepresentado.getEstadoActividad()) {
		case 0:
			Image image=new Image("/Imagenes/deporte verde.png");
			iconoDeporte.setImage(image);
			break;
		case 1:
			Image image1=new Image("/Imagenes/deporte amarillo.png");
			iconoDeporte.setImage(image1);
			break;
		case 2: 
			Image image2=new Image("/Imagenes/deporte rojo.png");
			iconoDeporte.setImage(image2);
			break;
		}

		//Se rellenan los datos del paciente
		LabelNombreEdad.setText(pacienteRepresentado.getNombre()+" "+pacienteRepresentado.getApellido1()+" "+pacienteRepresentado.getApellido2()+", "+pacienteRepresentado.getEdad());
	}

	@FXML
	void initialize() {
		assert representacionPaciente != null : "fx:id=\"representacionPaciente\" was not injected: check your FXML file 'RepresentacionPacienteFormatoCuadrado.fxml'.";
		assert imagenPaciente != null : "fx:id=\"imagenPaciente\" was not injected: check your FXML file 'RepresentacionPacienteFormatoCuadrado.fxml'.";
		assert LabelNombreEdad != null : "fx:id=\"LabelNombreEdad\" was not injected: check your FXML file 'RepresentacionPacienteFormatoCuadrado.fxml'.";
		assert iconoCorazon != null : "fx:id=\"iconoCorazon\" was not injected: check your FXML file 'RepresentacionPacienteFormatoCuadrado.fxml'.";
		assert iconoMedicamento != null : "fx:id=\"iconoMedicamento\" was not injected: check your FXML file 'RepresentacionPacienteFormatoCuadrado.fxml'.";
		assert iconoDeporte != null : "fx:id=\"iconoDeporte\" was not injected: check your FXML file 'RepresentacionPacienteFormatoCuadrado.fxml'.";
		rellenarDatosPaciente();
	}

	public void setPacienteRepresentado(Paciente paciente) {
		this.pacienteRepresentado=paciente;
	}
}
