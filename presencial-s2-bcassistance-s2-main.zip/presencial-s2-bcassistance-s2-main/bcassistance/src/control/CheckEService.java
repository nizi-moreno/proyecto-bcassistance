package control;

import javafx.concurrent.ScheduledService;
import javafx.concurrent.Task;
import model.Paciente;

//Un service crea un nuevo Thread para que haga trabajo de fondo, ejecuta una tarea (Task)
/* La T es para simbolizar una plantilla, ya que puede ser de tipo T significa ser un tipo cualquiera
* Asi, puedo pasar un objeto tipo clinico, cuidador en esta misma clase sin problema
* Pd: Necesito pasarle un clinico o cuidador para sacar de ahi la informacion de los pacientes que hay que revisar*/
public class CheckEService<T> extends ScheduledService<Paciente> {
	//El que va a estar revisando las emergencias de un pacinete va a ser cuidador o clinico
	private T supervisor;
	
	public CheckEService(T supervisor) {
		this.supervisor=supervisor;
	}
	
	//Crea la tarea (CheckETask)
	@Override
	//El Task es de tipo pPaciente porque devuelve un paciente (el de la emergencia)
	protected Task<Paciente> createTask() {
		//Le paso el supervisor para que revise los pacientes de ese supervisor (Cuidador o Clinico)
		return new CheckETask<T>(supervisor);
	}
	
	
	
}
