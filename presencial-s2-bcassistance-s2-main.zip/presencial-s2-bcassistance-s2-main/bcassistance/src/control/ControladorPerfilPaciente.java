package control;

import java.util.Iterator;
import java.util.Locale;
import java.io.File;
import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.CredencialUsuario;
import model.Paciente;

public class ControladorPerfilPaciente {

	static String language;
	static Paciente paciente;
	static CredencialUsuario UsuarioLogueado;

	ObservableList<Integer> listaDia =FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
	ObservableList<Integer> listaMes =FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9,10,11,12);
	ObservableList<Integer> listaAno =FXCollections.observableArrayList();
	Vector<String> listaError=new Vector<String>(); 


	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="labelPerfil"
	private Label labelPerfil; // Value injected by FXMLLoader

	@FXML // fx:id="labelEditaPerfil"
	private Label labelEditaPerfil; // Value injected by FXMLLoader

	@FXML // fx:id="botonGuardar"
	private JFXButton botonGuardar; // Value injected by FXMLLoader

	@FXML // fx:id="imagenUsuario"
	private ImageView imagenUsuario; // Value injected by FXMLLoader

	@FXML // fx:id="labelNombre"
	private Label labelNombre; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldNombre"
	private JFXTextField textfieldNombre; // Value injected by FXMLLoader

	@FXML // fx:id="labelApellido1"
	private Label labelApellido1; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldApellido1"
	private JFXTextField textfieldApellido1; // Value injected by FXMLLoader

	@FXML // fx:id="labelApellido2"
	private Label labelApellido2; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldApellido2"
	private JFXTextField textfieldApellido2; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldCorreo"
	private JFXTextField textfieldCorreo; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldContrasena"
	private JFXPasswordField textfieldContrasena; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldDNI"
	private JFXTextField textfieldDNI; // Value injected by FXMLLoader

	@FXML // fx:id="comboboxDia"
	private ComboBox<Integer> comboboxDia; // Value injected by FXMLLoader

	@FXML // fx:id="comboboxMes"
	private ComboBox<Integer> comboboxMes; // Value injected by FXMLLoader

	@FXML // fx:id="comboboxAno"
	private ComboBox<Integer> comboboxAno; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldNTlfn"
	private JFXTextField textfieldNTlfn; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldAltura"
	private JFXTextField textfieldAltura; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldPeso"
	private JFXTextField textfieldPeso; // Value injected by FXMLLoader

	private ControladorBLPaciente controladorBL;

	public ControladorBLPaciente getControladorBL() {
		return controladorBL;
	}

	public void setControladorBL(ControladorBLPaciente controladorBL) {
		this.controladorBL = controladorBL;
	}

	@FXML
	private Text miTexto;
	
	@FXML
	private JFXButton botonBaja;
	
	@FXML
	void handleBajaAplicacion(ActionEvent event) {
		//MANEJAMOS LA BAJA DE LA APLICACION
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/VentanaEmergenteBajaAplicacion.fxml"),bundle);
			ControladorVentanaEmergenteBajaAplicacion control = new ControladorVentanaEmergenteBajaAplicacion();
			ControladorVentanaEmergenteBajaAplicacion.language=language;
			ControladorVentanaEmergenteBajaAplicacion.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaEmergenteBajaAplicacion.blPaciente=controladorBL;
			loader.setController(control);
			Parent root = loader.load();
			Stage miStage = new Stage();
			miStage.setTitle("Baja de la aplicacion");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(((Node) event.getSource()).getScene().getWindow());
			ControladorVentanaEmergenteBajaAplicacion.window=((Node) event.getSource()).getScene().getWindow();
			miStage.setScene(new Scene(root));
			miStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}


	@SuppressWarnings("deprecation")
	@FXML
	void handleButtonGuardar(ActionEvent event) {
		listaError.clear();

		//Recogemos los datos introducidos
		System.out.println("Boton guardar pulsado");

		try {
			//NOMBRE Y APELLIDOS
			//Si es diferente al que ya estaba y no esta vacio, se actualiza
			if(!textfieldNombre.getText().equals(paciente.getNombre())&!textfieldNombre.getText().trim().isEmpty()) {
				paciente.setNombre(textfieldNombre.getText());
			}
			//Si esta vacio, no deja guardar
			else if (textfieldNombre.getText().trim().isEmpty()){
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir nombre");}
				else {listaError.add("Fill in name");}
			}
			if(!textfieldApellido1.getText().equals(paciente.getApellido1()) & !textfieldApellido1.getText().trim().isEmpty()) {
				paciente.setApellido1(textfieldApellido1.getText());
			}
			else if (textfieldApellido1.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir primer apellido");}
				else {listaError.add("Fill in first surname");}
			}

			if(!textfieldApellido2.getText().equals(paciente.getNombre())&!textfieldApellido2.getText().trim().isEmpty()) {
				paciente.setApellido2(textfieldApellido2.getText());
			}
			//Este no es obligatorio

			//NACIMIENTO
			Calendar calendar = Calendar.getInstance();
			calendar.clear();
			//Si el dia es distinto
			if (comboboxDia.getValue()!=null && comboboxDia.getValue()!=paciente.getFecha_nacimiento().getDate()) {
				calendar.set(Calendar.DATE, comboboxDia.getValue());
			} else {
				calendar.set(Calendar.DATE, paciente.getFecha_nacimiento().getDate());
			}
			//Si el mes es distinto
			if (comboboxMes.getValue()!=null && comboboxMes.getValue()!=(paciente.getFecha_nacimiento().getMonth()+1)) {
				calendar.set(Calendar.MONTH, comboboxMes.getValue()-1);
			} else {
				calendar.set(Calendar.MONTH, paciente.getFecha_nacimiento().getMonth());
			}
			//Si el anio es distinto
			if (comboboxAno.getValue()!=null && comboboxAno.getValue()!=(paciente.getFecha_nacimiento().getYear()+1900)) {
				calendar.set(Calendar.YEAR, comboboxAno.getValue());
			} else {
				calendar.set(Calendar.YEAR, paciente.getFecha_nacimiento().getYear()+1900);
			}

			paciente.setFecha_nacimiento(calendar.getTime());



			//TELEFONO
			try {
				if (textfieldNTlfn.getText().trim().isEmpty()) {
					if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introduzca el telefono");}
					else {listaError.add("Fill in phone number");}
				}
				else if(textfieldNTlfn.getText().length()!=9) {
					if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Telefono no valido");}
					else {listaError.add("Phone number is not valid");}
				}
				else if (!textfieldNTlfn.getText().equals(""+paciente.getTelefono())) {
					paciente.setTelefono(Integer.parseInt(textfieldNTlfn.getText()));
				}
			}catch(Exception E) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("El telefono debe contener numeros");}
				else {listaError.add("The phone number must contain numbers");}
			}

			//CORREO
			if(textfieldCorreo.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir mail");}
				else {listaError.add("Fill in email");}
			}
			else if(!validarCorreo(textfieldCorreo.getText())) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Mail no validable");}
				else {listaError.add("Not validatable mail");}
			}
			else if (!textfieldCorreo.getText().equals(paciente.getCredencial().getEmail())) {
				paciente.getCredencial().setEmail(textfieldCorreo.getText());
			}

			//CONTRASENA
			if(!textfieldContrasena.getText().equals(paciente.getCredencial().getContrasena())
					&&!textfieldContrasena.getText().trim().isEmpty()) {
				paciente.getCredencial().setContrasena(textfieldContrasena.getText());;
			}
			else if (textfieldContrasena.getText().trim().isEmpty()){
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir una contrasena");}
				else {listaError.add("Choose a password");}
			}

			//ALTURA
			try {
				if (Integer.parseInt(textfieldAltura.getText())>1000) {
					if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Altura no valida");}
					else {listaError.add("Height is not valid");}
				}
				else if (!textfieldNTlfn.getText().equals(""+paciente.getAltura())) {
					paciente.setAltura(Integer.parseInt(textfieldAltura.getText()));
				}
			}catch(Exception E) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("El telefono debe contener numeros");}
				else {listaError.add("The phone number must contain numbers");}
			}

			//PESO
			try {
				if (Double.parseDouble(textfieldPeso.getText())>1000) {
					if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Peso no valido");}
					else {listaError.add("Weight is not valid");}
				}
				else if (!textfieldPeso.getText().equals(""+paciente.getPeso())) {
					paciente.setPeso(Double.parseDouble(textfieldPeso.getText()));
				}
			}catch(Exception E) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("El peso debe contener solo numeros");}
				else {listaError.add("The weight must contain only numbers");}
			}



		}catch(Exception e) {
			listaError.clear();
			if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Se ha producido un error");}
			else {listaError.add("An error has occurred");}
		}


		//MOSTRAMOS LOS ERRORES
		if(!listaError.isEmpty()) {
			miTexto.setText(listaError.toString());
		}
		else{
			miTexto.setText("");
			System.out.println("Usuario actualizado");
			ControladorBBDD cBBDD = new ControladorBBDD();
			cBBDD.modificarPaciente(paciente);
			cBBDD.modificarPacientePesoYAltura(paciente.getPeso(), paciente.getAltura(), paciente.getCredencial().getUsuario_dni());
			//Actualizamos los cambios en la aplicacion para que se muestren en la BL
			ControladorBLPaciente.paciente=paciente;
			this.controladorBL.actualizarDatosUsuario();
		}

		System.out.println("Hemos llegado hasta aqui");
		//Actualizamos la credencial del usuario

	}

	boolean validarDni(String DNI) {

		if (DNI.length()!=9){
			return false;
		}
		DNI=DNI.toUpperCase();
		String parteNumerica=DNI.substring(0,DNI.length()-1);
		int numeroDni = Integer.parseInt(parteNumerica);
		char letraDni = DNI.substring(DNI.length()-1, DNI.length()).toUpperCase().charAt(0);
		char letrasDni[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y',
				'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z',
				'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};

		int divisor=23;
		int resto = numeroDni%divisor;

		String dniCorrecto=numeroDni+""+letrasDni[resto];
		if(DNI.startsWith("0")){
			dniCorrecto = "0"+dniCorrecto;
		}
		if(DNI.startsWith("00")){
			dniCorrecto = "00"+dniCorrecto;
		}
		if(DNI.equals(dniCorrecto)) {
			System.out.println("DNI CORRECTO");
		}
		else {
			System.out.println("DNI NO VALIDO");
			return false;
		}
		return true;
	}

	boolean validarCorreo(String correo) {

		// Patr�n para validar el email
		Pattern pattern = Pattern
				.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
						+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");


		Matcher mather = pattern.matcher(correo);

		if (mather.find() == true) {
			System.out.println("El email ingresado es valido.");
			return true;
		} else {
			System.out.println("El email ingresado es invalido.");
			return false;
		}
	}

	public void rellenarListaAno() {
		int i=2020;
		while(i>=1930) {
			listaAno.add(i);
			i--;
		}			
	}

	@FXML
	void handleCambiarFotoPerfil(MouseEvent event) {
		ControladorBBDD cBDDD = new ControladorBBDD();
		//Debemos abrir un JFileChooser, para que el usuario pueda cambiar su imagen de perfil
		FileChooser fileChooser = new FileChooser();
		//fileChooser.setInitialDirectory(new File("src/ficheros/CarpetasUsuarios/"+paciente.getCredencial().getUsuario_dni()));
		fileChooser.setTitle("Buscar Imagen de Perfil");

		// Agregar filtros para facilitar la busqueda
		fileChooser.getExtensionFilters().addAll(
				new FileChooser.ExtensionFilter("All Images", "*.*"),
				new FileChooser.ExtensionFilter("JPG", "*.jpg"),
				new FileChooser.ExtensionFilter("PNG", "*.png")
				);

		// Obtener la imagen seleccionada
		File imgFile = fileChooser.showOpenDialog(null);

		// Cargamos la imagen de perfil
		if (imgFile != null) {
			Image image = new Image("file:" + imgFile.getAbsolutePath());
			imagenUsuario.setImage(image);
			cBDDD.actualizarFotoPerfil(paciente.getCredencial().getUsuario_dni(), imgFile);
		}

		//Actualizamos la imagen de perfil de la barra lateral
		controladorBL.actualizarImagenPerfil();

	}

	@SuppressWarnings("deprecation")
	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert labelPerfil != null : "fx:id=\"labelPerfil\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert labelEditaPerfil != null : "fx:id=\"labelEditaPerfil\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert botonGuardar != null : "fx:id=\"botonGuardar\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenUsuario\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert labelNombre != null : "fx:id=\"labelNombre\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldNombre != null : "fx:id=\"textfieldNombre\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert labelApellido1 != null : "fx:id=\"labelApellido1\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldApellido1 != null : "fx:id=\"textfieldApellido1\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert labelApellido2 != null : "fx:id=\"labelApellido2\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldApellido2 != null : "fx:id=\"textfieldApellido2\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldCorreo != null : "fx:id=\"textfieldCorreo\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldContrasena != null : "fx:id=\"textfieldContrasena\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldDNI != null : "fx:id=\"textfieldDNI\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert comboboxDia != null : "fx:id=\"comboboxDia\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert comboboxMes != null : "fx:id=\"comboboxMes\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert comboboxAno != null : "fx:id=\"comboboxAno\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldNTlfn != null : "fx:id=\"textfieldNTlfn\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldAltura != null : "fx:id=\"textfieldAltura\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert textfieldPeso != null : "fx:id=\"textfieldPeso\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert miTexto != null : "fx:id=\"miTexto\" was not injected: check your FXML file 'PerfilPaciente.fxml'.";
		assert botonBaja != null : "fx:id=\"botonBaja\" was not injected: check your FXML file 'PerfilClinico.fxml'.";
		
		//rellenar la info en los text field
		textfieldNombre.setText(paciente.getNombre());
		textfieldApellido1.setText(paciente.getApellido1());
		textfieldApellido2.setText(paciente.getApellido2());
		textfieldCorreo.setText(paciente.getCredencial().getEmail());
		textfieldDNI.setText(paciente.getCredencial().getUsuario_dni());
		textfieldContrasena.setText(paciente.getCredencial().getContrasena());
		comboboxDia.setPromptText(""+paciente.getFecha_nacimiento().getDate());
		comboboxMes.setPromptText(""+ (paciente.getFecha_nacimiento().getMonth()+1));
		comboboxAno.setPromptText(""+ (paciente.getFecha_nacimiento().getYear()+1900));
		textfieldNTlfn.setText(""+ paciente.getTelefono());
		ControladorBBDD cBBDD = new ControladorBBDD();
		paciente = cBBDD.ObtenerPesoYAlturaPaciente(paciente);
		textfieldAltura.setText(""+ paciente.getAltura());
		textfieldPeso.setText(""+paciente.getPeso());
		comboboxDia.setItems(listaDia);
		comboboxMes.setItems(listaMes);
		rellenarListaAno();
		comboboxAno.setItems(listaAno);

		//Cargamos la imagen de perfil (si tiene una)
		try{
			Image imagen = cBBDD.getFotoPerfil(paciente.getCredencial().getUsuario_dni());
			if(imagen!=null) {
				imagenUsuario.setImage(imagen);
			}

		}catch (Exception e) {
			//No tiene imagen de perfil
		}

	}

}