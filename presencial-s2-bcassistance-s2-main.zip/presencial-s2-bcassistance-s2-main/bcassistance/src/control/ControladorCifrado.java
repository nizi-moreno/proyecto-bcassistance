package control;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;
import model.Usuario;

public class ControladorCifrado {


	//Leer la clave desde el fichero
	public String leerClaveEncriptacionFichero () {
		String clave="";
		FileReader f;
		try {
			//Aniadimos al FileReader la ruta del archivo
			f = new FileReader("src/ficheros/llave.txt");
			//Le pasamos a un BufferedReader nuestro FileReader
			BufferedReader b = new BufferedReader(f);
			//Asignamos el valor le�do a nuestra variable
			clave =b.readLine();
			//Cerramos el reader
			b.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return clave;
	}

	//Metodos para crear carpetas para los usuairos
	public void comprobarCarpetasUsuarios() {
		ControladorBBDD controlador= new ControladorBBDD();
		//Comprobamos que la carpeta principal se haya creado
		File directorio = new File("src\\ficheros\\CarpetasUsuarios");
        if (!directorio.exists()) {
            if (directorio.mkdir()) {
                System.out.println("Directorio creados: src\\ficheros\\CarpetarUsuarios") ;
            } else {
                System.out.println("Error al crear directorio: src\\ficheros\\CarpetarUsuarios");
            }
        }
		Vector<Usuario> listaUsuarios = controlador.devolverTodosUsuarios();
		String ruta = "src\\ficheros\\CarpetasUsuarios";
		//Vamos a recorrer la lista de usuarios y vamos a comprobrar si tienen una carpeta creada
		for(int i=0; i<listaUsuarios.size(); i++) {
			 File directorio1 = new File(ruta+"\\"+listaUsuarios.get(i).getCredencial().getUsuario_dni());
		        if (!directorio1.exists()) {
		            if (directorio1.mkdir()) {
		                System.out.println("Directorio creado: "+ruta+"\\"+listaUsuarios.get(i).getCredencial().getUsuario_dni());
		            } else {
		                System.out.println("Error al crear directorio: "+ruta+"\\"+listaUsuarios.get(i).getCredencial().getUsuario_dni());
		            }
		        }
		}
	}


}
