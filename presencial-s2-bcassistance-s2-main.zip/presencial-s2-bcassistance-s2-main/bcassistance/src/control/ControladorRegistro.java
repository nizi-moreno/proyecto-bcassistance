package control;

import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;
import model.Usuario;

public class ControladorRegistro {
	ObservableList<Integer> listaDia =FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
	ObservableList<Integer> listaMes =FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9,10,11,12);
	ObservableList<Integer> listaAno =FXCollections.observableArrayList();
	ObservableList<String> listaSexo =FXCollections.observableArrayList("Hombre","Mujer");
	ObservableList<String> listaRol =FXCollections.observableArrayList("Paciente","Cuidador","Especialista");
	ObservableList<String> listaSexoEn =FXCollections.observableArrayList("Male","Female");
	ObservableList<String> listaRolEn =FXCollections.observableArrayList("Patient","Carer","Specialist");
	Vector<String> listaError=new Vector<String>(); 
	Vector<Clinico> clinicos = new Vector<Clinico>();
	Vector<Cuidador> cuidadores = new Vector<Cuidador>();
	Vector<Paciente> pacientes = new Vector<Paciente>();


	int dia;
	int mes;
	int ano;
	Date nacimiento;
	String nombre;
	String apellido1;
	String apellido2;
	String dni;
	String correo;
	String contrasena1;
	String contrasena2;
	int rol = 0;
	boolean sexo;
	int telefono;

	private Stage dialogStage;

	@FXML
	private JFXTextField dniField;

	@FXML
	private JFXTextField nombreField;

	@FXML
	private JFXTextField primerApellidoField;

	@FXML
	private JFXTextField segundoApellidoField;

	@FXML
	private JFXTextField telefonoField;

	@FXML
	private JFXTextField correoField;

	@FXML
	private JFXPasswordField passwordField1;

	@FXML
	private JFXPasswordField passwordField2;

	@FXML ComboBox<Integer> diaCombo;

	@FXML
	private ComboBox<Integer> mesCombo;

	@FXML
	private ComboBox<Integer> anoCombo;

	@FXML
	private JFXButton botonVolverInicio;

	@FXML
	private ComboBox<String> sexoCombo;

	@FXML
	private ComboBox<String> rolCombo;

	@FXML
	private Text miTexto;

	@FXML
	private JFXButton registrarseBoton;

	@FXML
	private ImageView imagBoton;



	boolean registrarBBDD(CredencialUsuario credencial) {
		ControladorBBDD cBBDD=new ControladorBBDD();
		Vector<CredencialUsuario> listaUsuarios = new Vector<CredencialUsuario>();
		ControladorCifrado controlador=new ControladorCifrado();

		/*
		//1. Importamos todos los usuarios
		listaUsuarios=controlador.deserializarJsonCredencialesAArray();

		//2. A�adimos el nuevo usuario
		listaUsuarios.add(credencial);

		//3. Ahora se guardan todos en el Json
		controladorJson.serializarArrayCredencialesAJson(listaUsuarios);

		System.out.println("NUEVO USUARIO GUARDADO");*/

		//Ahora segun si es un medico, paciente o cuidador, lo metemos en su correspondiente lista
		String errorDNI = "";

		if(rol==2) {	//especialista
			Clinico nuevoClinico=new Clinico(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sexo );
			errorDNI=cBBDD.insertarClinico(nuevoClinico);

			/*clinicos=controlador.deserializarJsonClinicosAArray();
			clinicos.add(nuevoClinico);

			controlador.serializarArrayClinicosAJson(clinicos);*/
		}
		else if(rol==1) {	//cuidadores
			Cuidador nuevoCuidador=new Cuidador(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sexo);			
			errorDNI=cBBDD.insertarCuidador(nuevoCuidador);

			/*cuidadores=controlador.deserializarJsonCuidadoresAArray();
			cuidadores.add(nuevoCuidador);
			controlador.serializarArrayCuidadoresAJson(cuidadores);*/
		}
		else if(rol==0) {	//Paciente
			Paciente nuevoPaciente=new Paciente(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sexo);
			errorDNI= cBBDD.insertarPaciente(nuevoPaciente);
			cBBDD.insertarTablaPaciente(nuevoPaciente);
		}

		
		
		//Si hay error al introducir
		if(errorDNI!=null) {
			listaError.add(errorDNI);
			miTexto.setText(listaError.toString());
			return true;
		}
		//Si no hay error
		else {
			System.out.println("Usuario nuevo guardado");
			if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Registro completado con �xito");}
			else {listaError.add("Signing in succesfully completed");}
			return false;
		}
	}

	@SuppressWarnings("deprecation")
	@FXML
	void botonPulsado(ActionEvent event) {
		listaError.clear();

		//Recogemos los datos introducidos
		System.out.println("Boton pulsado");

		try {
			//NOMBRE Y APELLIDOS
			if(!nombreField.getText().trim().isEmpty()) {nombre = nombreField.getText();}
			else {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir nombre");}
				else {listaError.add("Fill in name");}
			}
			if(!primerApellidoField.getText().trim().isEmpty()) {apellido1= primerApellidoField.getText();}
			else {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir primer apellido");}
				else {listaError.add("Fill in first surname");}
			}

			if(!segundoApellidoField.getText().trim().isEmpty()) {apellido2= segundoApellidoField.getText();}
			//Este no es obligatorio

			//DNI
			if(dniField.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir DNI");}
				else {listaError.add("Fill in DNI");}
			}
			
			else if(!validarDni(dniField.getText())){	//Si el DNI no es v�lidp
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("DNI no valido");}
				else {listaError.add("Not valid DNI");}
			}

			/*
			else if(!validarDniNoRepetido(dniField.getText())) {	//Comprobamos que el DNI no est� en uso
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("DNI ya en uso");}
				else {listaError.add("DNI already in use");}

			}*/
			else {
				dni=dniField.getText().toUpperCase();
				System.out.println("DNI " + dni);
			}


			//NACIMIENTO
			if(diaCombo.getValue()!=null) {dia=diaCombo.getValue();/*nacimiento.setDate(dia);*/}    	
			if(mesCombo.getValue()!=null) {mes=mesCombo.getValue();/*nacimiento.setMonth(mes);*/}	
			if(anoCombo.getValue()!=null) {ano=anoCombo.getValue();/*nacimiento.setYear(ano);*/}

			if(diaCombo.getValue()==null || mesCombo.getValue()==null || mesCombo.getValue()==null) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Error en fecha de nacimiento");}
				else {listaError.add("Error occurred with birthdate");}
			}
			else {
				nacimiento=new Date(ano-1900,mes-1,dia);

			}

			//SEXO
			if(sexoCombo.getValue()==null) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Escoger sexo");}
				else {listaError.add("Choose sex");}
			}
			else if(sexoCombo.getValue().equals("Hombre") || sexoCombo.getValue().equals("Male")) sexo=true;
			else if(sexoCombo.getValue().equals("Mujer") || sexoCombo.getValue().equals("Female")) sexo=false;

			//TELEFONO
			try {
				if (telefonoField.getText().trim().isEmpty()) {
					if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introduzca el tel�fono");}
					else {listaError.add("Fill in phone number");}
				}
				else if(telefonoField.getText().length()!=9) {
					if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Tel�fono no v�lido");}
					else {listaError.add("Phone number is not valid");}
				}
				else telefono=Integer.parseInt(telefonoField.getText());
			}catch(Exception E) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("El telefono debe contener numeros");}
				else {listaError.add("The phone number must contain numbers");}
			}

			//CORREO
			if(correoField.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir mail");}
				else {listaError.add("Fill in email");}
			}
			else if(validarCorreo(correoField.getText())) {
				correo=correoField.getText();
			}
			else {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Mail no validable");}
				else {listaError.add("Not validable mail");}
			}
			/*
			//CORREO
			if(!correoField.getText().trim().isEmpty()) {correo=correoField.getText();}
			else {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir mail");}
				else {listaError.add("Fill in email");}
			}
			 */
			//CONTRASE�A
			if(!passwordField1.getText().trim().isEmpty() && !passwordField2.getText().trim().isEmpty()) {
				contrasena1=passwordField1.getText();
				contrasena2=passwordField2.getText();
			}
			else {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir una contrasena");}
				else {listaError.add("Choose a password");}
			}

			if(!passwordField1.getText().equals(passwordField2.getText())) listaError.add("Las contrasenas no coinciden");

			//ROl
			if(rolCombo.getValue()==null) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Debe escoger un rol");}
				else {listaError.add("Must choose a role");}
			}
			else if(rolCombo.getValue().equals("Paciente") || rolCombo.getValue().equals("Patient")) {
				rol=0;

			}

			else if(rolCombo.getValue().equals("Cuidador") || rolCombo.getValue().equals("Carer")) {
				rol=1;

			}
			else if(rolCombo.getValue().equals("Especialista") || rolCombo.getValue().equals("Specialist")) {
				rol=2;  
			}

		}catch(Exception e) {
			listaError.clear();
			if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Se ha producido un error");}
			else {listaError.add("An error has occurred");}
		}


		//MOSTRAMOS LOS ERRORES
		if(!listaError.isEmpty()) {
			miTexto.setText(listaError.toString());
		}
		else{
			miTexto.setText("");
			System.out.println("Usuario creado");
			String contrasenaCodificada = CredencialUsuario.encodePassword(contrasena1);
			boolean alta=true; 
			CredencialUsuario nuevaCredencial=new CredencialUsuario(rol,dni,correo,contrasenaCodificada, alta);
			
			//Comprobamos si hay errores al introducir
			//registrarBBDD(nuevaCredencial);

			/*
			//Comprobamos que se haya creado su carpeta
			ControladorFicherosJson c = new ControladorFicherosJson();
			c.comprobarCarpetasUsuarios();*/

			//Si no hay ning�n error en la BBDD al introducir
			if(registrarBBDD(nuevaCredencial)==false) {
							//Volvemos a la p�gina del login
			try {
					Locale locale = new Locale(ControladorLogin.language);
					ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
					FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/GUI_Login.fxml"), bundle);
					ControladorLogin controladorLogin= new ControladorLogin();
					loader.setController(controladorLogin);
					Parent root= loader.load();
					Scene scene1 = new Scene(root);
					Main.window.setScene(scene1);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}

			

		}

		System.out.println("Hemos llegado hasta aqu�");
		//Creamos la credencial del nuevo usuario

	}
	boolean validarDni(String DNI) {

		if (DNI.length()!=9){
			return false;
		}
		DNI=DNI.toUpperCase();
		//iNTRODUCIR COMPROBACI�N DNI
		String parteNumerica=DNI.substring(0,DNI.length()-1);
		int numeroDni = Integer.parseInt(parteNumerica);
		char letraDni = DNI.substring(DNI.length()-1, DNI.length()).toUpperCase().charAt(0);
		char letrasDni[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y',
				'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z',
				'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};

		int divisor=23;
		int resto = numeroDni%divisor;

		String dniCorrecto=numeroDni+""+letrasDni[resto];
		if(DNI.startsWith("0")){
			dniCorrecto = "0"+dniCorrecto;
		}
		if(DNI.startsWith("00")){
			dniCorrecto = "00"+dniCorrecto;
		}
		if(DNI.equals(dniCorrecto)) {
			System.out.println("DNI CORRECTO");
		}
		else {
			System.out.println("DNI NO V�LIDO");
			return false;
		}
		return true;
	}

	//Comprobamos que el DNI no est� en uso
	boolean validarDniNoRepetido(String DNI) {
		ControladorBBDD controlador= new ControladorBBDD();	
		boolean DNIrepetido=true;
		Vector<Usuario> listadoCredenciales= controlador.devolverTodosUsuarios();
		System.out.println(listadoCredenciales.size());
		for(int i=0;i<=listadoCredenciales.size();i++) {
			if(listadoCredenciales.get(i).getCredencial().getUsuario_dni().equals(DNI)) {
				System.out.println("DNI NO V�LIDO");
				DNIrepetido= false;	//Si el DNI ya existe devolvemos false
			}
		}
		System.out.println("DNI V�LIDO"+ DNI);
		return DNIrepetido;	//devolvemos true si el DNI no est� en uso
	}

	boolean validarCorreo(String correo) {

		// Patr�n para validar el email
		Pattern pattern = Pattern
				.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
						+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");


		Matcher mather = pattern.matcher(correo);

		if (mather.find() == true) {
			System.out.println("El email ingresado es v�lido.");
			return true;
		} else {
			System.out.println("El email ingresado es inv�lido.");
			return false;
		}
	}
	@FXML
	void handleBotonVolverInicio(ActionEvent event) {
		//Volvemos a la p�gina del login
		try {
			Locale locale = new Locale(ControladorLogin.language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/GUI_Login.fxml"), bundle);
			ControladorLogin controladorLogin= new ControladorLogin();
			loader.setController(controladorLogin);
			Parent root= loader.load();
			Scene scene1 = new Scene(root);
			Main.window.setScene(scene1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}



	public void rellenarListaAno() {
		int i=2020;
		while(i>=1930) {
			listaAno.add(i);
			i--;
		}			
	}

	public void initialize() {
		diaCombo.setItems(listaDia);
		mesCombo.setItems(listaMes);
		rellenarListaAno();
		anoCombo.setItems(listaAno);
		if (ControladorLogin.language.contentEquals("es_ES")) {sexoCombo.setItems(listaSexo);}
		else {sexoCombo.setItems(listaSexoEn);};
		if (ControladorLogin.language.contentEquals("es_ES")) {rolCombo.setItems(listaRol);}
		else {rolCombo.setItems(listaRolEn);};

	}



}
