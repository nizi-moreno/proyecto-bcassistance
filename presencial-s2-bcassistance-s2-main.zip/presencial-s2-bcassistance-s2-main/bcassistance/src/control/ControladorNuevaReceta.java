package control;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.AgendaMedicamento;
import model.CredencialUsuario;
import model.Paciente;
import model.Receta;

public class ControladorNuevaReceta{

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="Medicamento"
	private JFXTextField Medicamento; // Value injected by FXMLLoader

	@FXML // fx:id="Unidades"
	private JFXTextField Unidades; // Value injected by FXMLLoader

	@FXML // fx:id="Descripcion"
	private JFXTextArea Descripcion; // Value injected by FXMLLoader

	@FXML // fx:id="Duracion"
	private JFXTextField Duracion; // Value injected by FXMLLoader

	@FXML // fx:id="NuevaReceta"
	private JFXButton NuevaReceta; // Value injected by FXMLLoader
	
	@FXML
    private JFXButton EliminarReceta;

	@FXML // fx:id="CalendarioMedicamentos"
	private TableView<AgendaMedicamento> CalendarioMedicamentos; // Value injected by FXMLLoader

	@FXML // fx:id="Agenda"
	private TableColumn<AgendaMedicamento, String> Agenda; // Value injected by FXMLLoader

	@FXML // fx:id="Lunes"
	private TableColumn<AgendaMedicamento, JFXCheckBox>  Lunes; // Value injected by FXMLLoader

	@FXML // fx:id="Martes"
	private TableColumn<AgendaMedicamento, JFXCheckBox> Martes; // Value injected by FXMLLoader

	@FXML // fx:id="Miercoles"
	private TableColumn<AgendaMedicamento, JFXCheckBox> Miercoles; // Value injected by FXMLLoader

	@FXML // fx:id="Jueves"
	private TableColumn<AgendaMedicamento, JFXCheckBox>  Jueves; // Value injected by FXMLLoader

	@FXML // fx:id="Viernes"
	private TableColumn<AgendaMedicamento, JFXCheckBox> Viernes; // Value injected by FXMLLoader

	@FXML // fx:id="Sabado"
	private TableColumn<AgendaMedicamento, JFXCheckBox> Sabado; // Value injected by FXMLLoader

	@FXML // fx:id="Domingo"
	private TableColumn<AgendaMedicamento, JFXCheckBox>  Domingo; // Value injected by FXMLLoader
	
	@FXML // fx:id="FaltanDatos"
	private Label FaltanDatos; // Value injected by FXMLLoader

	//Creo al paciente porque lo voy a necesitar para guardar la receta
	static Paciente paciente;
	static CredencialUsuario UsuarioLogueado;
	static String language;
	static BorderPane panelInsertarApartado;
	//Cuando esto este true, significa que la ventana va usarse para modificar la receta. Flase es para anadir receta
	static boolean funcionModificar = false;
	
	//el index es para que al modificar la receta, saber cual es en el array del paciente
	static int index;

	void CambiarbotonanadirxModificar() {
		if (language.equals("es_ES")) {NuevaReceta.setText("Modificar Receta");}
		else {NuevaReceta.setText("Update Prescription");}
	}
	
	void rellenarInfo() {
		Receta receta = paciente.getMedicamentos().get(index);
		Medicamento.setText(receta.getNombre());
		Unidades.setText("" +receta.getTamanioDosis());
		Descripcion.setText("" + receta.getDescripcion());
		Duracion.setText("" + (receta.getFrecuencia()/7));
		
	}
	
	void rellenarAgendaMedicamentos() {
		//Hacemos una agenda completa de checkbox gracias a la funci�n AgendaMedicamento.devolverListaCheckBox();
		//Guardamos en un array especial los elementos
		ObservableList<AgendaMedicamento> agendaCheckBoxCompleta = AgendaMedicamento.devolverListaCheckBox();

		//Asignamos valores a nuestras columnas por cada d�a de la semana y hora
		Agenda.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("hora"));
		Lunes.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, JFXCheckBox>("Lunes"));
		Martes.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, JFXCheckBox>("Martes"));
		Miercoles.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, JFXCheckBox>("Miercoles"));
		Jueves.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, JFXCheckBox>("Jueves"));
		Viernes.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, JFXCheckBox>("Viernes"));
		Sabado.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, JFXCheckBox>("Sabado"));
		Domingo.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, JFXCheckBox>("Domingo"));
		
		//Cargamos la informacion en nuestra tabla
		CalendarioMedicamentos.setItems(agendaCheckBoxCompleta);

	}
	
	public boolean comprobarTabla() {
		//Hago este constructo para comprobar que si no hay al menos un cuadrado de mi agenda seleccionado me devuelva un false
		boolean apto=false;
		
		//Me devuelve toda la lista de selecciones de mi checkbox
		ObservableList<AgendaMedicamento> agendaCheckBoxCompleta = CalendarioMedicamentos.getItems();
		
		//Compruebo con un bucle si alguno de todos est� seleccionado
		for(int i=0; i<agendaCheckBoxCompleta.size(); i++) {
			if (agendaCheckBoxCompleta.get(i).getLunes().isSelected()) {
				apto=true;
			}
			if (agendaCheckBoxCompleta.get(i).getMartes().isSelected()) {
				apto=true;
			}
			if (agendaCheckBoxCompleta.get(i).getMiercoles().isSelected()) {
				apto=true;
			}
			if (agendaCheckBoxCompleta.get(i).getJueves().isSelected()) {
				apto=true;
			}
			if (agendaCheckBoxCompleta.get(i).getViernes().isSelected()) {
				apto=true;
			}
			if (agendaCheckBoxCompleta.get(i).getSabado().isSelected()) {
				apto=true;
			}
			if (agendaCheckBoxCompleta.get(i).getDomingo().isSelected()) {
				apto=true;
			}
		}
		//De no ser as�, me devuelve false
		return apto;
	}
	
	@FXML
	void AddReceta(ActionEvent event) {
		
		//Creo un if de que en caso de que alguno de los campos que haya puesto est�n vac�os que salga un mensaje de que faltan datos por rellenar
		//Aqu� utilizo la funci�n anterior de comprobarTabla(). En caso de ser false, me faltar�an datos por rellenar
		if(Medicamento.getText().trim().isEmpty()|| Unidades.getText().trim().isEmpty()||Duracion.getText().trim().isEmpty()||!comprobarTabla()) {			
			//A�adir que si no hay al menos un checkbox seleccionado, te ponga que faltan datos por rellenar
			if (language.equals("es_ES")) {
				FaltanDatos.setText("Faltan datos por rellenar");
			} else {
				FaltanDatos.setText("There are missing fields to fill");
			}
		}
		
		else {
				
			//Relleno todos los datos con los que me ha pasado el m�dico por pantalla:
			/*Nombre del medicamento:*/ String nombreMedicina= Medicamento.getText();
			/*Cantidad a tomar del medicamento:*/ int cantidad= Integer.parseInt(Unidades.getText());
			/*Descripci�n de la receta del medicamento:*/ String descripcion= Descripcion.getText();
			/*Duraci�n de toma del medicamento:*/ int duracion= Integer.parseInt(Duracion.getText());
			/*Stock inicial del medicamento, que para hacer la receta lo ponemos a 0 y ya a�adiremos en el calendario de medicamentos:*/ int stock =0;
			/*Fecha del medicamento*/ Timestamp fecha=new Timestamp(new Date().getTime());
			Receta nuevaReceta= new Receta(nombreMedicina, descripcion, "ud.", cantidad, stock, duracion, fecha);
			System.out.println("La duracion del medicamento es: " + nuevaReceta.getFrecuencia());
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(fecha); 
			calendar.add(Calendar.DAY_OF_YEAR, nuevaReceta.getFrecuencia()); 
			System.out.println("Duracion hasta el dia " + calendar.getTime());
			
			//Creo un observableList de tipo Agenda Medicamento que me devuelva los checkbox seleccionados
			ObservableList<AgendaMedicamento> agendaCheckBoxCompleta = CalendarioMedicamentos.getItems();
			
			//Creo 7 strings que despu�s rellenar�, pero que comienzo inicializandolos con nada.
			String Lunes="", Martes="", Miercoles="", Jueves="", Viernes="", Sabado="", Domingo= "";
			
			//Este es el mensaje que saldr� en la agenda de medicamentos
			String medicamento=cantidad + "Ud-" + nombreMedicina;
			
			//Creo un vector de tipo agenda d�nde me guardar� todos los nuevos datos de la receta a�adida
			Vector<AgendaMedicamento> nuevaAgenda= new Vector<>();
			
			//Comienzo haciendo un for que me recorra todos los checkbox de la agenda
			for(int i=0; i<agendaCheckBoxCompleta.size(); i++) {
				
				//Ahora, d�a a d�a, ir� viendo si el checkbox ha sido seleccionado o no, en caso de ser as�, le paso el mensaje
				//que quiero que salga en la agenda, en caso de no ser as�, no se me guarda nada, ya que lo he inicializado a nada.
				if (agendaCheckBoxCompleta.get(i).getLunes().isSelected()) {
					Lunes=medicamento;
				}
				if (agendaCheckBoxCompleta.get(i).getMartes().isSelected()) {
					Martes=medicamento;
				}
				if (agendaCheckBoxCompleta.get(i).getMiercoles().isSelected()) {
					Miercoles=medicamento;
				}
				if (agendaCheckBoxCompleta.get(i).getJueves().isSelected()) {
					Jueves=medicamento;
				}
				if (agendaCheckBoxCompleta.get(i).getViernes().isSelected()) {
					Viernes=medicamento;
				}
				if (agendaCheckBoxCompleta.get(i).getSabado().isSelected()) {
					Sabado=medicamento;
				}
				if (agendaCheckBoxCompleta.get(i).getDomingo().isSelected()) {
					Domingo=medicamento;
				}
				
				
				if(i==0) {                         //En caso de ser la fila de la ma�ana
					//Creo un nuevo objeto agenda donde guardo el mensaje de cada uno de los d�as
					AgendaMedicamento agenda= new AgendaMedicamento("Manana", Lunes, Martes, Miercoles, Jueves, Viernes, Sabado, Domingo);
					//A�ado este objeto a mi vector creado para una nueva agenda
					nuevaAgenda.add(agenda);					
				}
				else if (i==1) {                   //En caso de ser la fila del mediod�a
					AgendaMedicamento agenda= new AgendaMedicamento("Mediodia", Lunes, Martes, Miercoles, Jueves, Viernes, Sabado, Domingo);
					nuevaAgenda.add(agenda);
				}
				else {                             //En caso de ser la fila de la noche
					AgendaMedicamento agenda= new AgendaMedicamento("Noche", Lunes, Martes, Miercoles, Jueves, Viernes, Sabado, Domingo);
					nuevaAgenda.add(agenda);
				}
				
				//Antes de pasar a la siguiente fila de la hora, vuelvo a inicializar mis horas a nada
				Lunes="";
				Martes="";
				Miercoles="";
				Jueves="";
				Viernes="";
				Sabado="";
				Domingo="";
			}
			
			//A mi receta nueva le paso el vector realizado para la nueva agenda
			nuevaReceta.setAgendaMedicamento(nuevaAgenda);
			
			//Creo de nuevo un objeto de controlador de ficheros, hago un vector de pacientes y busco el paciente al que a�adirle la receta
			ControladorBBDD cBBDD=new ControladorBBDD();			
			/*ControladorFicherosJson controlador= new ControladorFicherosJson();
			/*Vector paicentes: Vector<Paciente> listaPacientes = new Vector<Paciente>();
			listaPacientes= controlador.deserializarJsonPacientesAArray();
			String DNIPaciente= paciente.getCredencial().getUsuario_dni();*/
			
			//A�ado a ese paciente la receta y vuelvo a serializar mi array
			if (!funcionModificar) {
				cBBDD.insertarReceta(paciente.getCredencial().getUsuario_dni(), nuevaReceta, UsuarioLogueado.getUsuario_dni());
			}
			else {
				nuevaReceta.setID(paciente.getMedicamentos().get(index).getID());
				cBBDD.ModificarReceta(nuevaReceta);
				}
			//controlador.serializarArrayPacientesAJson(listaPacientes);
			
			//Agregar la receta al paciente como objeto fuera del fichero para que se reflejen los cambios
			if (!funcionModificar) {paciente.addMedicina(nuevaReceta);}
			else {
				paciente.ModificarMedicina(index, nuevaReceta);
				}
			
			//Para cerrar la ventana emergente
			Node n= (Node) event.getSource();
			Stage stage = (Stage) n.getScene().getWindow();
			stage.close();
			
			//Una vez se a�ade la receta le llevo a la p�gina de ficha de paciente:

			try {
				Locale locale = new Locale(language);
				ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
				FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/VentanaFichaPaciente.fxml"), bundle);
				ControladorVentanaFichaPaciente controlador1= new ControladorVentanaFichaPaciente ();
				ControladorVentanaFichaPaciente.UsuarioLogueado=UsuarioLogueado;
				ControladorVentanaFichaPaciente.language=language;
				ControladorVentanaFichaPaciente.paciente=paciente;
				controlador1.setPanelInsertarApartado(panelInsertarApartado);
				loader.setController(controlador1);
				Parent root;
				root = loader.load();
				panelInsertarApartado.setCenter(root);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	//Eliminar receta del fichero
	public void EliminarReceta(ActionEvent event) {		
		//Creo de nuevo un objeto de controlador de ficheros, hago un vector de pacientes y busco el paciente al que eliminarle la receta
		ControladorBBDD cBBDD=new ControladorBBDD();
		Receta receta = paciente.getMedicamentos().get(index);
		//receta.setID(paciente.getMedicamentos().get(index).getID());
		System.out.println("El nombre de la receta es: " + receta.getNombre());
		paciente.DeleteMedicina(index);
		cBBDD.BorrarReceta(paciente.getCredencial().getUsuario_dni(), receta);	
		
		//Para cerrar la ventana emergente
		Node n= (Node) event.getSource();
		Stage stage = (Stage) n.getScene().getWindow();
		stage.close();
		
		//Una vez se elimina la receta le llevo a la p�gina de la ficha del paciente:
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/VentanaFichaPaciente.fxml"), bundle);
			ControladorVentanaFichaPaciente controlador1= new ControladorVentanaFichaPaciente ();
			ControladorVentanaFichaPaciente.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaFichaPaciente.language=language;
			ControladorVentanaFichaPaciente.paciente=paciente;
			controlador1.setPanelInsertarApartado(panelInsertarApartado);
			loader.setController(controlador1);
			Parent root;
			root = loader.load();
			panelInsertarApartado.setCenter(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	int buscarPaciente (Vector<String> listaPacientes, String DNI) {
		boolean encontrado=false;
		int posicion=-1;                  //Posicion en la que se encuentra el paciente. Pongo -1 para que no se confunda con la posici�n 0 del vector
		int i=0;                          //int para recorrer el vector de pacientes    

		while(i<listaPacientes.size() && !encontrado) {
			//En caso de que el dni del paciente sea el mismo que el del usuario que quiero eliminar:
			if (listaPacientes.get(i).equals(DNI)) {
				encontrado=true;
				posicion=i;               //posici�n del paciente

				//Imprimo el DNI para cerciorarme de que funciona:
				System.out.println("El paciente tiene DNI: "+ listaPacientes.get(i));
			}
			else {
				i++;
			}
		} //Cirro el while
		return posicion;
	}


	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert Medicamento != null : "fx:id=\"Medicamento\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Unidades != null : "fx:id=\"Unidades\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Descripcion != null : "fx:id=\"Descripcion\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Duracion != null : "fx:id=\"Duracion\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert NuevaReceta != null : "fx:id=\"NuevaReceta\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert CalendarioMedicamentos != null : "fx:id=\"CalendarioMedicamentos\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Agenda != null : "fx:id=\"Agenda\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Lunes != null : "fx:id=\"Lunes\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Martes != null : "fx:id=\"Martes\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Miercoles != null : "fx:id=\"Miercoles\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Jueves != null : "fx:id=\"Jueves\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Viernes != null : "fx:id=\"Viernes\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Sabado != null : "fx:id=\"Sabado\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert Domingo != null : "fx:id=\"Domingo\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		assert FaltanDatos != null : "fx:id=\"FaltanDatos\" was not injected: check your FXML file 'NuevaReceta.fxml'.";
		rellenarAgendaMedicamentos();
		
		//Esconder el boton de eliminar por defecto, y solo mostrar si se va a modificar la receta
		if (funcionModificar) {
			EliminarReceta.setVisible(true);
			CambiarbotonanadirxModificar();
		} 
		else {
			EliminarReceta.setVisible(false);
			
		}

	}
}
