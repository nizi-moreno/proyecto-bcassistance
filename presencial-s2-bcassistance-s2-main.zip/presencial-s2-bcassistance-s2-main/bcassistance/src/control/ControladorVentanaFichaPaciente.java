package control;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.AgendaMedicamento;
import model.CredencialUsuario;
import model.Location;
import model.Paciente;

public class ControladorVentanaFichaPaciente {

	static CredencialUsuario UsuarioLogueado;
	static Paciente paciente;

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="LabelPaciente"
	private Label LabelPaciente; // Value injected by FXMLLoader

	@FXML // fx:id="LabelFichaPaciente"
	private Label LabelFichaPaciente; // Value injected by FXMLLoader

	@FXML // fx:id="ImageViewPerfilPaciente"
	private ImageView ImageViewPerfilPaciente; // Value injected by FXMLLoader

	@FXML // fx:id="LabelNombre"
	private Label LabelNombre; // Value injected by FXMLLoader

	@FXML // fx:id="LabelEnfermedades"
	private Label LabelEnfermedades; // Value injected by FXMLLoader

	@FXML // fx:id="LabelTelefono"
	private Label LabelTelefono; // Value injected by FXMLLoader

	@FXML // fx:id="BotonEliminar"
	private JFXButton BotonEliminar; // Value injected by FXMLLoader

	@FXML // fx:id="LabelDistancia"
	private Label LabelDistancia; // Value injected by FXMLLoader

	@FXML // fx:id="LabelDistanciaRecorrida"
	private Label LabelDistanciaRecorrida; // Value injected by FXMLLoader

	@FXML // fx:id="LabelKM"
	private Label LabelKM; // Value injected by FXMLLoader

	@FXML // fx:id="LabelPasos"
	private Label LabelPasos; // Value injected by FXMLLoader

	@FXML // fx:id="LabelPasosRealizados"
	private Label LabelPasosRealizados; // Value injected by FXMLLoader

	@FXML // fx:id="LabelKcal"
	private Label LabelKcal; // Value injected by FXMLLoader

	@FXML // fx:id="LabelKcalQuemadas"
	private Label LabelKcalQuemadas; // Value injected by FXMLLoader

	@FXML // fx:id="LabelObjetivo"
	private Label LabelObjetivo; // Value injected by FXMLLoader

	@FXML // fx:id="LabelObjetivoDiario"
	private Label LabelObjetivoDiario; // Value injected by FXMLLoader

	@FXML // fx:id="ButtonCorazon"
	private JFXButton ButtonCorazon; // Value injected by FXMLLoader

	@FXML // fx:id="LabelFrecuenciaCardiaca"
	private Label LabelFrecuenciaCardiaca; // Value injected by FXMLLoader

	@FXML // fx:id="LabelActual"
	private Label LabelActual; // Value injected by FXMLLoader

	@FXML // fx:id="LabelFrecuenciaActual"
	private Label LabelFrecuenciaActual; // Value injected by FXMLLoader

	@FXML // fx:id="LabelReposo"
	private Label LabelReposo; // Value injected by FXMLLoader

	@FXML // fx:id="LabelFrecuenciaReposo"
	private Label LabelFrecuenciaReposo; // Value injected by FXMLLoader

	@FXML // fx:id="LabelCardiograma"
	private Label LabelCardiograma; // Value injected by FXMLLoader

	@FXML // fx:id="LabelECG"
	private Label LabelECG; // Value injected by FXMLLoader

	@FXML // fx:id="LabelVariabilidad"
	private Label LabelVariabilidad; // Value injected by FXMLLoader

	@FXML // fx:id="LabelFrecuenciaVariabilidad"
	private Label LabelFrecuenciaVariabilidad; // Value injected by FXMLLoader

	@FXML // fx:id="LabelMS"
	private Label LabelMS; // Value injected by FXMLLoader

	@FXML // fx:id="ButtonMedicacion"
	private JFXButton ButtonMedicacion; // Value injected by FXMLLoader
	
    @FXML
    private JFXButton botonLocalizacion;

    @FXML
    private BorderPane miBorderPane;

    @FXML
    private Label labelDireccion;

	@FXML
	private TableView<AgendaMedicamento> TablaListadoMedicamentosDia;

	@FXML // fx:id="TablaListadoMedicamentosDia"
	private TableColumn<AgendaMedicamento, String> ColumnaListadoMedicamentosDia; // Value injected by FXMLLoader

	static String language;

	private String panelactual = "Inicio";

	private BorderPane panelInsertarApartado;

	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}

	@FXML
	void EliminarPaciente(ActionEvent event) {
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/EliminarPaciente.fxml"), bundle);	//Importamos el fxml de la segunda ventana
			ControladorEliminarPaciente control2 = new ControladorEliminarPaciente();	//Creamos el controlador DE LA SEGUNDA VENTANA			
			ControladorEliminarPaciente.UsuarioLogueado=UsuarioLogueado;
			ControladorEliminarPaciente.language = language;
			ControladorEliminarPaciente.panelInsertarApartado=panelInsertarApartado;
			loader2.setController(control2);				//Al loader (FXML) le asignamoos su controlador			
			Parent root = loader2.load();				//Asignamos como root el fxml
			Stage miStage = new Stage();
			miStage.setScene(new Scene(root));		//El root pasa a ser una escena y la escena pasa a ser primaryStage
			miStage.setTitle("Eliminar Paciente");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(((Node) event.getSource()).getScene().getWindow());
			miStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	void HandleMedicacion(ActionEvent event) {

		if(UsuarioLogueado.getRol()==2) {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Creamos un objeto FXMLLoader para cargar la pantalla
			FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaControlMedicamentosClinico.fxml"), bundle);
			ControladorVentanaControlMedicamentosClinico c = new ControladorVentanaControlMedicamentosClinico();
			c.setPanelInsertarApartado(panelInsertarApartado);
			ControladorVentanaControlMedicamentosClinico.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaControlMedicamentosClinico.language=language;
			ControladorVentanaControlMedicamentosClinico.paciente=paciente;
			loader.setController(c);
			Parent root;
			try{
				root = loader.load();
				panelInsertarApartado.setCenter(root);
				panelactual = "Medicamentos";
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else if(UsuarioLogueado.getRol()==1) {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Creamos un objeto FXMLLoader para cargar la pantalla
			FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaControlMedicamentosCuidador.fxml"), bundle);
			ControladorVentanaControlMedicamentosCuidador c = new ControladorVentanaControlMedicamentosCuidador();
			c.setPanelInsertarApartado(panelInsertarApartado);
			ControladorVentanaControlMedicamentosCuidador.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaControlMedicamentosCuidador.language=language;
			ControladorVentanaControlMedicamentosCuidador.paciente=paciente;
			loader.setController(c);
			Parent root;
			try{
				root = loader.load();
				panelInsertarApartado.setCenter(root);
				panelactual = "Medicamentos";
			}catch (IOException e) {
				// TODO Auto-generated catch block
			}
		} 
	}

	@FXML
	void HandleCorazon(ActionEvent event) {
		//Cargamos la pantalla de corazon cuando se presiona el boton "Corazon"
		System.out.println("Corazon was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaCorazonECGPaciente.fxml"), bundle);
		ControladorVentanaCorazonECGPaciente c = new ControladorVentanaCorazonECGPaciente();
		ControladorVentanaCorazonECGPaciente.language=language;
		c.setUsuarioLogueado(UsuarioLogueado);
		c.setPanelInsertarApartado(panelInsertarApartado);
		c.setPaciente(paciente);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			//panelactual = "Corazon";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	String rellenarTituloTabla() {
		try {
			//Recogemos el d�a de la semana para actualizar la tabla que se Muestra
			Date hoy=new Date();
			int numeroDia;
			Calendar cal= Calendar.getInstance();
			cal.setTime(hoy);
			numeroDia=cal.get(Calendar.DAY_OF_WEEK);
			if (language.equals("es_ES")) {
				String[] nombreDias={"Domingo","Lunes","Martes", "Miercoles","Jueves","Viernes","Sabado"};
				return nombreDias[numeroDia-1];// El dia de la semana inicia en el 1 mientras que el array empieza en el 0
			} else {
				String[] nombreDias={"Sunday","Monday","Tuesday", "Wednesday","Thursday","Friday","Saturday"};
				return nombreDias[numeroDia-1];// El dia de la semana inicia en el 1 mientras que el array empieza en el 0
			}

		}
		catch(Exception e) {
			System.out.println("Se ha producido un error al recoger el dia para rellenar el titulo la tabla");
			return "Error";
		}


	}
	String rellenarTabla() {
		try {
			//Recogemos el d�a de la semana para actualizar la tabla que se Muestra
			Date hoy=new Date();
			int numeroDia=0;
			Calendar cal= Calendar.getInstance();
			cal.setTime(hoy);
			numeroDia=cal.get(Calendar.DAY_OF_WEEK);
			if (language.equals("es_ES")) {
				String[] dias={"D","L","M", "M","J","V","S"};
				return dias[numeroDia-1];// El dia de la semana inicia en el 1 mientras que el array empieza en el 0
			} else {
				String[] dias={"Sun","Mon","Tue", "Wed","Thu","Fri","Sat"};
				return dias[numeroDia-1];// El dia de la semana inicia en el 1 mientras que el array empieza en el 0
			}
		}    	catch(Exception e) {
			System.out.println("Se ha producido un error al recoger el dia para rellenar la tabla");
			return "L";	//Si se produce un error se muestra el lunes
		}


	}

	void rellenarTabaMedicamentos() {
		//Accedemos a su lista de medicamentos completo
		//Guardamos en un array especial los elementos
		ObservableList<AgendaMedicamento> agendaCompleta = paciente.devolverAgendaMedicamentos();
		//Asignamos valores a nuestras columnas
		ColumnaListadoMedicamentosDia.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>(rellenarTabla()));//Si se produce un error se muestra el lunes
		//Cargamos la informacion en nuestra tabla
		TablaListadoMedicamentosDia.setItems(agendaCompleta);
		if (language.equals("es_ES")) {TablaListadoMedicamentosDia.setPlaceholder(new Label("No dispone de agenda de medicamentos."));} 
		else {TablaListadoMedicamentosDia.setPlaceholder(new Label("Does not have a medicine schedule."));}
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		ControladorBBDD cBBDD=new ControladorBBDD();
		
		//Actualizamos el paciente con sus localizaciones
		paciente=cBBDD.actualizarLocalizacion(paciente);
		
		//Rellenar paciente
		mostrarMapa();
		
		assert LabelPaciente != null : "fx:id=\"LabelPaciente\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelFichaPaciente != null : "fx:id=\"LabelFichaPaciente\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert ImageViewPerfilPaciente != null : "fx:id=\"ImageViewPerfilPaciente\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelNombre != null : "fx:id=\"LabelNombre\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelEnfermedades != null : "fx:id=\"LabelEnfermedades\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelTelefono != null : "fx:id=\"LabelTelefono\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert BotonEliminar != null : "fx:id=\"BotonEliminar\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelDistancia != null : "fx:id=\"LabelDistancia\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelDistanciaRecorrida != null : "fx:id=\"LabelDistanciaRecorrida\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelKM != null : "fx:id=\"LabelKM\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelPasos != null : "fx:id=\"LabelPasos\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelPasosRealizados != null : "fx:id=\"LabelPasosRealizados\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelKcal != null : "fx:id=\"LabelKcal\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelKcalQuemadas != null : "fx:id=\"LabelKcalQuemadas\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelObjetivo != null : "fx:id=\"LabelObjetivo\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelObjetivoDiario != null : "fx:id=\"LabelObjetivoDiario\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert ButtonCorazon != null : "fx:id=\"ButtonCorazon\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelFrecuenciaCardiaca != null : "fx:id=\"LabelFrecuenciaCardiaca\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelActual != null : "fx:id=\"LabelActual\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelFrecuenciaActual != null : "fx:id=\"LabelFrecuenciaActual\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelReposo != null : "fx:id=\"LabelReposo\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelFrecuenciaReposo != null : "fx:id=\"LabelFrecuenciaReposo\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelCardiograma != null : "fx:id=\"LabelCardiograma\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelECG != null : "fx:id=\"LabelECG\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelVariabilidad != null : "fx:id=\"LabelVariabilidad\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelFrecuenciaVariabilidad != null : "fx:id=\"LabelFrecuenciaVariabilidad\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert LabelMS != null : "fx:id=\"LabelMS\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert ButtonMedicacion != null : "fx:id=\"ButtonMedicacion\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";
		assert TablaListadoMedicamentosDia != null : "fx:id=\"TablaListadoMedicamentosDia\" was not injected: check your FXML file 'VentanaFichaPaciente.fxml'.";

		//Implementaci�n de los label
		//Datos del paciente
		LabelNombre.setText(paciente.getNombre()+" "+paciente.getApellido1());
		LabelEnfermedades.setText(paciente.getCredencial().getUsuario_dni());//DUDO SI EL HISTORIAL SON LAS ENFERMEDADES
		LabelTelefono.setText(Integer.toString(paciente.getTelefono()));

		//Datos de actividad
		//LabelDistanciaRecorrida.setText(Float.toString(paciente.getActividad_semanal().lastElement().getDistancia()));
		//LabelKcalQuemadas.setText(Float.toString(paciente.getActividad_semanal().lastElement().getKcal()));
		//LabelPasosRealizados.setText(Integer.toString(paciente.getActividad_semanal().lastElement().getPasos()));
		//LabelObjetivoDiario.setText(Integer.toString(paciente.getActividad_semanal().lastElement().getObjetivo()));

		//Datos de los sensores

		//La tabla de medicaci�n del d�a
		ColumnaListadoMedicamentosDia.setText(rellenarTituloTabla());//Rellenamos el t�tulo de la tabla con el d�a de la semana
		rellenarTabaMedicamentos();

		//Cargamos la imagen de perfil (si tiene una)
		try{
			ImageViewPerfilPaciente.setImage(paciente.getImagenPerfil());

		}catch (Exception e) {
			//No tiene imagen de perfil
		}
	}
	
	public void mostrarMapa() {
		if(paciente.getRegistroLocalizaciones().size()!=0) {
			Location location=paciente.getRegistroLocalizaciones().get(paciente.getRegistroLocalizaciones().size()-1);
			double latitud = location.getLatitud();
			double longitud = location.getLongitud();
			
			WebView myWebView = new WebView();
			
			WebEngine engine = myWebView.getEngine();
			
			String url = "https://maps.googleapis.com/maps/api/staticmap?center="+latitud+","+longitud+"&zoom=18&scale=1&size=400x250&maptype=roadmap&key="+Main.GOOGLE_API_KEY+"&format=png&visual_refresh=true&markers=size:mid%7Ccolor:0xff0000%7Clabel:L%7C"+latitud+","+longitud;

			engine.load(url);

			//Aniadimos el browserView en el bordePaneInsertarApartado
			miBorderPane.setCenter(myWebView);
			
			
			//Le mostramos la direccion de la ubicacion y la fecha
			labelDireccion.setText("Ultimo registro: "+location.getFechaEscrita());//FALTA ANIADIR DIRECCION

		}else {
			labelDireccion.setText("No tiene registros de localizacion");
		}
	}
	
    @FXML
    void localizacionPulsado(ActionEvent event) {
		//Aqui va a cargarse el panel de la localizaci�n gps del paciente
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Medicamentos"
		System.out.println("LocalizacionGPS was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaLocalizacionGPS.fxml"), bundle);
		ControladorVentanaLocalizacionGPS c = new ControladorVentanaLocalizacionGPS();
		ControladorVentanaLocalizacionGPS.language=language;
		ControladorVentanaLocalizacionGPS.paciente=paciente;
		ControladorVentanaLocalizacionGPS.panelBL=panelInsertarApartado;
		ControladorVentanaLocalizacionGPS.usuarioLogueado=UsuarioLogueado;
		//c.setPaciente(paciente);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			panelactual = "LocalizacionGPS";
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}

