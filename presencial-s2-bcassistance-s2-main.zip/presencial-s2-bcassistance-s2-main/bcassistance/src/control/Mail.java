package control;

import java.io.IOException;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Mail {
	
	//Hago una clase para manejar lo del mail
	
	//Clase encargada de almacenar las propiedades de la conexi�n que vamos a establecer con el servidor 
	private final Properties propiedades= new Properties();
		
	//Clase encargada de manejar la sesi�n de usuario
	private Session sesion;
	
	private void init() {
	
	propiedades.put("mail.smtp.host", "stmp.gmail.com");  //El servidor SMTP de Google
    propiedades.put("mail.smtp.user", "NeedasBiotec6@gmail.com");
    propiedades.put("mail.smtp.password", "Grupo1234");    //La clave de la cuenta
    propiedades.put("mail.smtp.auth", "true");    //Usar autenticaci�n mediante usuario y clave
    propiedades.put("mail.smtp.starttls.enable", "true"); //Para conectar de manera segura al servidor SMTP
    propiedades.put("mail.smtp.port", 587); //El puerto SMTP seguro de Google
    sesion = Session.getDefaultInstance(propiedades);
	}
	
    public void enviarEmail(String mensaje, String direccion_correo) throws MessagingException, IOException {

    	init();
    	try {
    	//Formo el mensaje que deseo enviar. Introduzco al constructor la sesi�n sobre la que voy a enviar el mensaje
        MimeMessage correo = new MimeMessage(sesion);
        
        //La funci�n .setFrom recibe como par�metro la direcci�n del emisor del mensaje de tipo InternetAddress.
        correo.setFrom(new InternetAddress("NeedasBiotec6@gmail.com"));
        //Recibe 2 par�metros, el tipo de receptor (TO) y la direcci�n de correo del receptor
        correo.addRecipient(Message.RecipientType.TO, new InternetAddress(direccion_correo));
       
        //Le paso como par�metro el asunto
        correo.setSubject("Recuperar contrase�a de BCAssistance");
        
        
        //Creamos la parte del mensaje
         correo.setText(mensaje);
       
        //Transport define los par�metros del protocolo de transporte
        Transport t = sesion.getTransport("smtp");
        
        //M�todo connect encargado de establecer la conexi�n con el servidor introduciendo nombre de usuario y contrase�a
        t.connect("smtp.gmail.com",("NeedasBiotec6@gmail.com"), "Grupo1234");
       
        //M�todo SendMessage: Env�a el mensaje al destinatario
        t.sendMessage(correo, correo.getAllRecipients());
        
        //Cierro la conexi�n
        t.close();
    	} catch (MessagingException e) {
    		System.out.print("Error al enviar el mensaje");
    		throw new RuntimeException (e);
    	}

    }

}