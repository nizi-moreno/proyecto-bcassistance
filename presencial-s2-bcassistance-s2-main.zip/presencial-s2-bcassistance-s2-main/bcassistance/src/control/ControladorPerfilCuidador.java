package control;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.CredencialUsuario;
import model.Cuidador;
import java.io.File;
import java.net.URL;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ControladorPerfilCuidador {

	static String language;
	static Cuidador cuidador;
	static CredencialUsuario UsuarioLogueado;

	ObservableList<Integer> listaDia =FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
	ObservableList<Integer> listaMes =FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9,10,11,12);
	ObservableList<Integer> listaAno =FXCollections.observableArrayList();
	Vector<String> listaError=new Vector<String>(); 

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="labelPerfil"
	private Label labelPerfil; // Value injected by FXMLLoader

	@FXML // fx:id="labelEditaPerfil"
	private Label labelEditaPerfil; // Value injected by FXMLLoader

	@FXML // fx:id="botonGuardar"
	private JFXButton botonGuardar; // Value injected by FXMLLoader

	@FXML // fx:id="imagenUsuario"
	private ImageView imagenUsuario; // Value injected by FXMLLoader

	@FXML // fx:id="labelNombre"
	private Label labelNombre; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldNombre"
	private JFXTextField textfieldNombre; // Value injected by FXMLLoader

	@FXML // fx:id="labelApellido1"
	private Label labelApellido1; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldApellido1"
	private JFXTextField textfieldApellido1; // Value injected by FXMLLoader

	@FXML // fx:id="labelApellido2"
	private Label labelApellido2; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldApellido2"
	private JFXTextField textfieldApellido2; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldCorreo"
	private JFXTextField textfieldCorreo; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldContrasena"
	private JFXPasswordField textfieldContrasena; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldDNI"
	private JFXTextField textfieldDNI; // Value injected by FXMLLoader

	@FXML // fx:id="comboboxDia"
	private ComboBox<Integer> comboboxDia; // Value injected by FXMLLoader

	@FXML // fx:id="comboboxMes"
	private ComboBox<Integer> comboboxMes; // Value injected by FXMLLoader

	@FXML // fx:id="comboboxAno"
	private ComboBox<Integer> comboboxAno; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldNTlfn"
	private JFXTextField textfieldNTlfn; // Value injected by FXMLLoader

	@FXML
	private Text miTexto;
	
	@FXML
	private JFXButton botonBaja;
	
	@FXML
	void handleBajaAplicacion(ActionEvent event) {
		//MANEJAMOS LA BAJA DE LA APLICACION
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/VentanaEmergenteBajaAplicacion.fxml"),bundle);
			ControladorVentanaEmergenteBajaAplicacion control = new ControladorVentanaEmergenteBajaAplicacion();
			ControladorVentanaEmergenteBajaAplicacion.language=language;
			ControladorVentanaEmergenteBajaAplicacion.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaEmergenteBajaAplicacion.blCuidador=controladorBL;
			loader.setController(control);
			Parent root = loader.load();
			Stage miStage = new Stage();
			miStage.setTitle("Baja de la aplicacion");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(((Node) event.getSource()).getScene().getWindow());
			ControladorVentanaEmergenteBajaAplicacion.window=((Node) event.getSource()).getScene().getWindow();
			miStage.setScene(new Scene(root));
			miStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private ControladorBLCuidador controladorBL;


	public ControladorBLCuidador getControladorBL() {
		return controladorBL;
	}

	public void setControladorBL(ControladorBLCuidador controladorBL) {
		this.controladorBL = controladorBL;
	}
	@SuppressWarnings("deprecation")
	@FXML
	void handleButtonGuardar(ActionEvent event) {
		ControladorBBDD controlador= new ControladorBBDD();
		listaError.clear();

		//Recogemos los datos introducidos
		System.out.println("Boton guardar pulsado");

		try {
			//NOMBRE Y APELLIDOS
			//Si es diferente al que ya estaba y no esta vacio, se actualiza
			if(!textfieldNombre.getText().equals(cuidador.getNombre())&!textfieldNombre.getText().trim().isEmpty()) {
				cuidador.setNombre(textfieldNombre.getText());
			}
			//Si esta vacio, no deja guardar
			else if (textfieldNombre.getText().trim().isEmpty()){
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir nombre");}
				else {listaError.add("Fill in name");}
			}
			if(!textfieldApellido1.getText().equals(cuidador.getApellido1()) & !textfieldApellido1.getText().trim().isEmpty()) {
				cuidador.setApellido1(textfieldApellido1.getText());
			}
			else if (textfieldApellido1.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir primer apellido");}
				else {listaError.add("Fill in first surname");}
			}

			if(!textfieldApellido2.getText().equals(cuidador.getNombre())&!textfieldApellido2.getText().trim().isEmpty()) {
				cuidador.setApellido2(textfieldApellido2.getText());
			}
			//Este no es obligatorio

			//NACIMIENTO
			Calendar calendar = Calendar.getInstance();
			calendar.clear();
			//Si el dia es distinto
			if (comboboxDia.getValue()!=null && comboboxDia.getValue()!=cuidador.getFecha_nacimiento().getDate()) {
				System.out.println(cuidador.getFecha_nacimiento().getDate());
				calendar.set(Calendar.DATE, comboboxDia.getValue()); 
			} else {
				calendar.set(Calendar.DATE, cuidador.getFecha_nacimiento().getDate());
			}
			//Si el mes es distinto
			if (comboboxMes.getValue()!=null && comboboxMes.getValue()!=(cuidador.getFecha_nacimiento().getMonth()+1)) {
				calendar.set(Calendar.MONTH, comboboxMes.getValue()-1);
			} else {
				calendar.set(Calendar.MONTH, cuidador.getFecha_nacimiento().getMonth());
			}
			//Si el anio es distinto
			if (comboboxAno.getValue()!=null && comboboxAno.getValue()!=(cuidador.getFecha_nacimiento().getYear()+1900)) {
				calendar.set(Calendar.YEAR, comboboxAno.getValue());
			} else {
				calendar.set(Calendar.YEAR, cuidador.getFecha_nacimiento().getYear()+1900);
			}

			cuidador.setFecha_nacimiento(calendar.getTime());

			//TELEFONO
			try {
				if (textfieldNTlfn.getText().trim().isEmpty()) {
					if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introduzca el telefono");}
					else {listaError.add("Fill in phone number");}
				}
				else if(textfieldNTlfn.getText().length()!=9) {
					if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Telefono no valido");}
					else {listaError.add("Phone number is not valid");}
				}
				else if (!textfieldNTlfn.getText().equals(""+cuidador.getTelefono())) {
					cuidador.setTelefono(Integer.parseInt(textfieldNTlfn.getText()));
				}
			}catch(Exception E) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("El telefono debe contener numeros");}
				else {listaError.add("The phone number must contain numbers");}
			}

			//CORREO
			if(textfieldCorreo.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir mail");}
				else {listaError.add("Fill in email");}
			}
			else if(!validarCorreo(textfieldCorreo.getText())) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Mail no validable");}
				else {listaError.add("Not validatable mail");}
			}
			else if (!textfieldCorreo.getText().equals(cuidador.getCredencial().getEmail())) {
				cuidador.getCredencial().setEmail(textfieldCorreo.getText());
			}

			//CONTRASENA
			if(!textfieldContrasena.getText().equals(cuidador.getCredencial().getContrasena())
					&&!textfieldContrasena.getText().trim().isEmpty()) {
				cuidador.getCredencial().setContrasena(textfieldContrasena.getText());;
			}
			else if (textfieldContrasena.getText().trim().isEmpty()){
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir una contrasena");}
				else {listaError.add("Choose a password");}
			}



		}catch(Exception e) {
			listaError.clear();
			if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Se ha producido un error");}
			else {listaError.add("An error has occurred");}
		}


		//MOSTRAMOS LOS ERRORES
		if(!listaError.isEmpty()) {
			miTexto.setText(listaError.toString());
		}
		else{
			miTexto.setText("");
			System.out.println("Usuario actualizado");
			controlador.ModificarCuidador(cuidador);	
			//Actualizamos los cambios en la aplicacion para que se muestren en la BL
			ControladorBLCuidador.cuidador=cuidador;
			this.controladorBL.actualizarDatosUsuario();
		}

		System.out.println("Hemos llegado hasta aqui");
		//Actualizamos la credencial del usuario

	}

	boolean validarDni(String DNI) {

		if (DNI.length()!=9){
			return false;
		}
		DNI=DNI.toUpperCase();
		String parteNumerica=DNI.substring(0,DNI.length()-1);
		int numeroDni = Integer.parseInt(parteNumerica);
		char letraDni = DNI.substring(DNI.length()-1, DNI.length()).toUpperCase().charAt(0);
		char letrasDni[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y',
				'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z',
				'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};

		int divisor=23;
		int resto = numeroDni%divisor;

		String dniCorrecto=numeroDni+""+letrasDni[resto];
		if(DNI.startsWith("0")){
			dniCorrecto = "0"+dniCorrecto;
		}
		if(DNI.startsWith("00")){
			dniCorrecto = "00"+dniCorrecto;
		}
		if(DNI.equals(dniCorrecto)) {
			System.out.println("DNI CORRECTO");
		}
		else {
			System.out.println("DNI NO VALIDO");
			return false;
		}
		return true;
	}

	boolean validarCorreo(String correo) {

		// Patr�n para validar el email
		Pattern pattern = Pattern
				.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
						+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");


		Matcher mather = pattern.matcher(correo);

		if (mather.find() == true) {
			System.out.println("El email ingresado es valido.");
			return true;
		} else {
			System.out.println("El email ingresado es invalido.");
			return false;
		}
	}

	public void rellenarListaAno() {
		int i=2020;
		while(i>=1930) {
			listaAno.add(i);
			i--;
		}			
	}

	@FXML
	void handleCambiarFotoPerfil(MouseEvent event) {
		ControladorBBDD cBDDD = new ControladorBBDD();
		//Debemos abrir un JFileChooser, para que el usuario pueda cambiar su imagen de perfil
		FileChooser fileChooser = new FileChooser();
		//fileChooser.setInitialDirectory(new File("src/ficheros/CarpetasUsuarios/"+cuidador.getCredencial().getUsuario_dni()));
		fileChooser.setTitle("Buscar Imagen de Perfil");

		// Agregar filtros para facilitar la busqueda
		fileChooser.getExtensionFilters().addAll(
				new FileChooser.ExtensionFilter("All Images", "*.*"),
				new FileChooser.ExtensionFilter("JPG", "*.jpg"),
				new FileChooser.ExtensionFilter("PNG", "*.png")
				);

		// Obtener la imagen seleccionada
		File imgFile = fileChooser.showOpenDialog(null);

		// Cargamos la imagen de perfil
		if (imgFile != null) {
			Image image = new Image("file:" + imgFile.getAbsolutePath());
			cBDDD.actualizarFotoPerfil(cuidador.getCredencial().getUsuario_dni(), imgFile);
		}

		//Actualizamos la imagen de perfil de la barra lateral
		controladorBL.actualizarImagenPerfil();
		
	}


	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert labelPerfil != null : "fx:id=\"labelPerfil\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert labelEditaPerfil != null : "fx:id=\"labelEditaPerfil\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert botonGuardar != null : "fx:id=\"botonGuardar\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenUsuario\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert labelNombre != null : "fx:id=\"labelNombre\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert textfieldNombre != null : "fx:id=\"textfieldNombre\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert labelApellido1 != null : "fx:id=\"labelApellido1\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert textfieldApellido1 != null : "fx:id=\"textfieldApellido1\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert labelApellido2 != null : "fx:id=\"labelApellido2\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert textfieldApellido2 != null : "fx:id=\"textfieldApellido2\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert textfieldCorreo != null : "fx:id=\"textfieldCorreo\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert textfieldContrasena != null : "fx:id=\"textfieldContrasena\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert textfieldDNI != null : "fx:id=\"textfieldDNI\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert textfieldNTlfn != null : "fx:id=\"textfieldNTlfn\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert comboboxDia != null : "fx:id=\"comboboxDia\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert comboboxMes != null : "fx:id=\"comboboxMes\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert comboboxAno != null : "fx:id=\"comboboxAno\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert miTexto != null : "fx:id=\"miTexto\" was not injected: check your FXML file 'PerfilCuidador.fxml'.";
		assert botonBaja != null : "fx:id=\"botonBaja\" was not injected: check your FXML file 'PerfilClinico.fxml'.";
		
		//rellenar la info en los text field
		textfieldNombre.setText(cuidador.getNombre());
		textfieldApellido1.setText(cuidador.getApellido1());
		textfieldApellido2.setText(cuidador.getApellido2());
		textfieldCorreo.setText(cuidador.getCredencial().getEmail());
		textfieldDNI.setText(cuidador.getCredencial().getUsuario_dni());
		textfieldContrasena.setText(cuidador.getCredencial().getContrasena());
		comboboxDia.setPromptText(""+cuidador.getFecha_nacimiento().getDate());
		comboboxMes.setPromptText(""+ (cuidador.getFecha_nacimiento().getMonth()+1));
		comboboxAno.setPromptText(""+ (cuidador.getFecha_nacimiento().getYear()+1900));
		textfieldNTlfn.setText(""+ cuidador.getTelefono());
		comboboxDia.setItems(listaDia);
		comboboxMes.setItems(listaMes);
		rellenarListaAno();
		comboboxAno.setItems(listaAno);

		//Cargamos la imagen de perfil (si tiene una)
		try{
			ControladorBBDD cBBDD = new ControladorBBDD();
			Image imagen = cBBDD.getFotoPerfil(cuidador.getCredencial().getUsuario_dni());
			if(imagen!=null) {
				imagenUsuario.setImage(imagen);
			}

		}catch (Exception e) {
			//No tiene imagen de perfil
		}

	}

}