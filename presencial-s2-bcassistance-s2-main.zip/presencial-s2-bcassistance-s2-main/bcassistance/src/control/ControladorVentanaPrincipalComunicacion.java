package control;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;
import model.Usuario;

public class ControladorVentanaPrincipalComunicacion {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Label tituloComunicacion;

	@FXML
	private Label DescripcionApartado;

	@FXML
	private BorderPane borderPaneInsertarApartado;

	static CredencialUsuario usuarioLogueado;
	
	static Usuario user;

	static String language;

	//M�todo para mostrar por defecto la ventana de gesti�n de tickets
	void mostrarVentanaGestionTickets() {
		//Conectamos esta ventana con la VentanaSecundariaComunicacionGestionTickets
		System.out.println("Mostrando la ventana de gestion de tickets");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaSecundariaComunicacionGestionTickets.fxml"), bundle);
		ControladorVentanaSecundariaComunicacionGestionTickets c = new ControladorVentanaSecundariaComunicacionGestionTickets();
		//Le pasamos al controlador el usuario logueado:
		ControladorVentanaSecundariaComunicacionGestionTickets.usuarioLogueado=user;
		ControladorVentanaSecundariaComunicacionGestionTickets.language=language;
		ControladorVentanaSecundariaComunicacionGestionTickets.panelInsertarApartado=borderPaneInsertarApartado;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			borderPaneInsertarApartado.setCenter(root);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void initialize() {
		assert tituloComunicacion != null : "fx:id=\"tituloComunicacion\" was not injected: check your FXML file 'VentanaPrincipalComunicacion.fxml'.";
		assert DescripcionApartado != null : "fx:id=\"DescripcionApartado\" was not injected: check your FXML file 'VentanaPrincipalComunicacion.fxml'.";
		assert borderPaneInsertarApartado != null : "fx:id=\"borderPaneInsertarApartado\" was not injected: check your FXML file 'VentanaPrincipalComunicacion.fxml'.";
		mostrarVentanaGestionTickets();
	}
}