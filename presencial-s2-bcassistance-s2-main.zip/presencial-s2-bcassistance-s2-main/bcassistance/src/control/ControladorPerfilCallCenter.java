package control;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import model.Callcenter;
import model.CredencialUsuario;

public class ControladorPerfilCallCenter {
	
	static String language;
	static Callcenter callcenter;
	Vector<String> listaError=new Vector<String>(); 

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="labelPerfil"
	private Label labelPerfil; // Value injected by FXMLLoader

	@FXML // fx:id="labelEditaPerfil"
	private Label labelEditaPerfil; // Value injected by FXMLLoader

	@FXML // fx:id="botonGuardar"
	private JFXButton botonGuardar; // Value injected by FXMLLoader

	@FXML // fx:id="imagenUsuario"
	private ImageView imagenUsuario; // Value injected by FXMLLoader

	@FXML // fx:id="labelNombre"
	private Label labelNombre; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldNombre"
	private JFXTextField textfieldNombre; // Value injected by FXMLLoader

	@FXML // fx:id="labelApellido1"
	private Label labelApellido1; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldApellido1"
	private JFXTextField textfieldApellido1; // Value injected by FXMLLoader

	@FXML // fx:id="labelApellido2"
	private Label labelApellido2; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldApellido2"
	private JFXTextField textfieldApellido2; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldCorreo"
	private JFXTextField textfieldCorreo; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldContrasena"
	private JFXPasswordField textfieldContrasena; // Value injected by FXMLLoader

	@FXML // fx:id="textfieldDNI"
	private JFXTextField textfieldDNI; // Value injected by FXMLLoader

	@FXML
	private Text miTexto;

	private ControladorBLCallCenter controladorBL;

	public ControladorBLCallCenter getControladorBL() {
		return controladorBL;
	}

	public void setControladorBL(ControladorBLCallCenter controladorBL) {
		this.controladorBL = controladorBL;
	}

	@SuppressWarnings("deprecation")
	@FXML
	void handleButtonGuardar(ActionEvent event) {
		ControladorBBDD controlador= new ControladorBBDD();
		listaError.clear();

		//Recogemos los datos introducidos
		System.out.println("Boton guardar pulsado");

		try {
			//NOMBRE Y APELLIDOS
			//Si es diferente al que ya estaba y no esta vacio, se actualiza
			if(!textfieldNombre.getText().equals(callcenter.getNombre())&!textfieldNombre.getText().trim().isEmpty()) {
				callcenter.setNombre(textfieldNombre.getText());
			}
			//Si esta vacio, no deja guardar
			else if (textfieldNombre.getText().trim().isEmpty()){
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir nombre");}
				else {listaError.add("Fill in name");}
			}
			if(!textfieldApellido1.getText().equals(callcenter.getApellido1()) & !textfieldApellido1.getText().trim().isEmpty()) {
				callcenter.setApellido1(textfieldApellido1.getText());
			}
			else if (textfieldApellido1.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir primer apellido");}
				else {listaError.add("Fill in first surname");}
			}
			//SEGUNDO APELLIDO (no es obligatorio)
			if(!textfieldApellido2.getText().equals(callcenter.getNombre())&!textfieldApellido2.getText().trim().isEmpty()) {
				callcenter.setApellido2(textfieldApellido2.getText());
			}	

			//CORREO
			if(textfieldCorreo.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir mail");}
				else {listaError.add("Fill in email");}
			}
			else if(!validarCorreo(textfieldCorreo.getText())) {
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Mail no validable");}
				else {listaError.add("Not validable mail");}
			}
			else if (!textfieldCorreo.getText().equals(callcenter.getCredencial().getEmail())) {
				callcenter.getCredencial().setEmail(textfieldCorreo.getText());
			}

			//CONTRASENA
			if(!textfieldContrasena.getText().equals(callcenter.getCredencial().getContrasena())
					&&!textfieldContrasena.getText().trim().isEmpty()) {
				callcenter.getCredencial().setContrasena(textfieldContrasena.getText());;
			}
			else if (textfieldContrasena.getText().trim().isEmpty()){
				if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Introducir una contrasena");}
				else {listaError.add("Choose a password");}
			}

		}catch(Exception e) {
			listaError.clear();
			if (ControladorLogin.language.contentEquals("es_ES")) {listaError.add("Se ha producido un error");}
			else {listaError.add("An error has occurred");}
		}


		//MOSTRAMOS LOS ERRORES
		if(!listaError.isEmpty()) {
			miTexto.setText(listaError.toString());
		}
		else{
			miTexto.setText("");
			System.out.println("Usuario actualizado");
			controlador.ModificarCallCenter(callcenter);	
			//Actualizamos los cambios en la aplicacion para que se muestren en la BL
			ControladorBLCallCenter.UsuarioLogueado=callcenter;
			this.controladorBL.actualizarDatosUsuario();
		}
		
		System.out.println("Hemos llegado hasta aqui");
		//Actualizamos la credencial del usuario

	}

	boolean validarDni(String DNI) {

		if (DNI.length()!=9){
			return false;
		}
		DNI=DNI.toUpperCase();
		String parteNumerica=DNI.substring(0,DNI.length()-1);
		int numeroDni = Integer.parseInt(parteNumerica);
		char letraDni = DNI.substring(DNI.length()-1, DNI.length()).toUpperCase().charAt(0);
		char letrasDni[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y',
				'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z',
				'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};

		int divisor=23;
		int resto = numeroDni%divisor;

		String dniCorrecto=numeroDni+""+letrasDni[resto];
		if(DNI.startsWith("0")){
			dniCorrecto = "0"+dniCorrecto;
		}
		if(DNI.startsWith("00")){
			dniCorrecto = "00"+dniCorrecto;
		}
		if(DNI.equals(dniCorrecto)) {
			System.out.println("DNI CORRECTO");
		}
		else {
			System.out.println("DNI NO V�LIDO");
			return false;
		}
		return true;
	}

	boolean validarCorreo(String correo) {

		// Patron para validar el email
		Pattern pattern = Pattern
				.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
						+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");


		Matcher mather = pattern.matcher(correo);

		if (mather.find() == true) {
			System.out.println("El email ingresado es valido.");
			return true;
		} else {
			System.out.println("El email ingresado es invalido.");
			return false;
		}
	}

	@FXML
	void handleCambiarFotoPerfil(MouseEvent event) throws FileNotFoundException {
		ControladorBBDD cBDDD = new ControladorBBDD();
		//Debemos abrir un JFileChooser, para que el usuario pueda cambiar su imagen de perfil
		FileChooser fileChooser = new FileChooser();
		//fileChooser.setInitialDirectory(new File("src/ficheros/CarpetasUsuarios/"+callcenter.getCredencial().getUsuario_dni()));
		fileChooser.setTitle("Buscar Imagen de Perfil");

		// Agregar filtros para facilitar la busqueda
		fileChooser.getExtensionFilters().addAll(
				new FileChooser.ExtensionFilter("All Images", "*.*"),
				new FileChooser.ExtensionFilter("JPG", "*.jpg"),
				new FileChooser.ExtensionFilter("PNG", "*.png")
				);

		// Obtener la imagen seleccionada
		File imgFile = fileChooser.showOpenDialog(null);

		// Cargamos la imagen de perfil
		if (imgFile != null) {
			Image image = new Image("file:" + imgFile.getAbsolutePath());
			imagenUsuario.setImage(image);
			cBDDD.actualizarFotoPerfil(callcenter.getCredencial().getUsuario_dni(), imgFile);
		}

		//Actualizamos la imagen de perfil de la barra lateral
		controladorBL.actualizarImagenPerfil();
		
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert labelPerfil != null : "fx:id=\"labelPerfil\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert labelEditaPerfil != null : "fx:id=\"labelEditaPerfil\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert botonGuardar != null : "fx:id=\"botonGuardar\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenUsuario\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert labelNombre != null : "fx:id=\"labelNombre\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert textfieldNombre != null : "fx:id=\"textfieldNombre\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert labelApellido1 != null : "fx:id=\"labelApellido1\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert textfieldApellido1 != null : "fx:id=\"textfieldApellido1\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert labelApellido2 != null : "fx:id=\"labelApellido2\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert textfieldApellido2 != null : "fx:id=\"textfieldApellido2\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert textfieldCorreo != null : "fx:id=\"textfieldCorreo\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert textfieldContrasena != null : "fx:id=\"textfieldContrasena\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert textfieldDNI != null : "fx:id=\"textfieldDNI\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		assert miTexto != null : "fx:id=\"miTexto\" was not injected: check your FXML file 'PerfilCallCenter.fxml'.";
		
		
		//rellenar la info en los text field
		textfieldNombre.setText(callcenter.getNombre());
		textfieldApellido1.setText(callcenter.getApellido1());
		textfieldApellido2.setText(callcenter.getApellido2());
		textfieldCorreo.setText(callcenter.getCredencial().getEmail());
		textfieldDNI.setText(callcenter.getCredencial().getUsuario_dni());
		textfieldContrasena.setText(callcenter.getCredencial().getContrasena());

		//Cargamos la imagen de perfil (si tiene una)
		try{
			ControladorBBDD cBBDD = new ControladorBBDD();
			Image imagen = cBBDD.getFotoPerfil(callcenter.getCredencial().getUsuario_dni());
			if(imagen!=null) {
				imagenUsuario.setImage(imagen);
			}

		}catch (Exception e) {
			//No tiene imagen de perfil
		}

	}
}