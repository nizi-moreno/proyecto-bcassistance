package control;

import java.util.Vector;

import javafx.concurrent.ScheduledService;
import javafx.concurrent.Task;
import model.Paciente;
import model.Receta;

public class CheckTMService extends ScheduledService<Vector<Receta>>{

		private Paciente paciente;
		private int hora012;
		
		//Le paso un paciente para revisar su medicacion y la hora del dia 
		public CheckTMService(Paciente paciente) {
			this.paciente=paciente;
		}
		@Override
		//El Task es de tipo Medicamentos porque devuelve medicamentos, la 
		protected Task<Vector<Receta>> createTask() {
			return new CheckTMTask(paciente);
		}
		
}
