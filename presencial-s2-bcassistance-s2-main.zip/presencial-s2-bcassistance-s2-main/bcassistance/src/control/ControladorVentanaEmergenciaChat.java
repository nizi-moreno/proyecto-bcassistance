package control;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXTextArea;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import model.Cuidador;
import model.EmergenciaChat;
import model.Location;
import model.Paciente;


public class ControladorVentanaEmergenciaChat {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Label labelAvisoEmergencia;

	@FXML
	private Label labelInforme;

	@FXML
	private BorderPane borderPaneInsertarMapa;

	@FXML
	private Label labelLocalizacion;

	@FXML
	private Label labelNombre;

	@FXML
	private Label labelApellidos;

	@FXML
	private Label labelDNI;

	@FXML
	private Label labelTelefono;

	@FXML
	private ImageView imagenUsuario;

	@FXML
	private JFXTextArea textAreaDireccion;

	@FXML
	private TableView<Cuidador> tableViewCuidadores;

	@FXML
	private TableColumn<Cuidador, String> tableColumnCuidadores;

	private EmergenciaChat emergenciaARepresentar;

	static String language;


	public EmergenciaChat getEmergenciaARepresentar() {
		return emergenciaARepresentar;
	}

	public void setEmergenciaARepresentar(EmergenciaChat emergenciaARepresentar) {
		this.emergenciaARepresentar = emergenciaARepresentar;
	}

	void rellenarTablaCuidadores() {

		Paciente paciente = emergenciaARepresentar.devolverPaciente();
		ObservableList<Cuidador> listadoCuidadores = paciente.NombreCuidadores(); 

		//Asignamos valores a nuestra columna de cuidadores
		tableColumnCuidadores.setCellValueFactory(new PropertyValueFactory<Cuidador, String>("contacto"));

		//Cargamos la informacion en nuestra tabla
		tableViewCuidadores.setItems(listadoCuidadores);

		if (language.contentEquals("es_ES")) {
			tableViewCuidadores.setPlaceholder(new Label("No dispone de cuidadores."));
		} else {
			tableViewCuidadores.setPlaceholder(new Label("Does not have any carer."));
		}

	}

	void rellenarLocalizacion() {

		Location location = emergenciaARepresentar.getLocalizacion();

		double latitud = location.getLatitud();
		double longitud = location.getLongitud();

		WebView myWebView = new WebView();
		
		WebEngine engine = myWebView.getEngine();
		
		String url = "https://maps.googleapis.com/maps/api/staticmap?center="+latitud+","+longitud+
				"&zoom=18&scale=1&size=250x200&maptype=roadmap&key="+Main.GOOGLE_API_KEY+"&format=png&visual_refresh=true&markers=size:mid%7Ccolor:0xff0000%7Clabel:L%7C"+
				latitud+","+longitud;
		
		engine.load(url);

	
		borderPaneInsertarMapa.setCenter(myWebView);

		//Le mostramos la direccion de la ubicacion y la fecha
		textAreaDireccion.setText(location.getFechaEscrita()+"\n"+location.getDireccion());

	}

	void rellenarDatosPaciente() {

		Paciente paciente = emergenciaARepresentar.devolverPaciente();
		
		try{
			imagenUsuario.setImage(paciente.getImagenPerfil());
			
		}catch (Exception e) {
			//No tiene imagen de perfil
		}

		//Mostramos sus datos personales
		labelNombre.setText(paciente.getNombre());
		labelApellidos.setText(paciente.getApellido1()+" "+paciente.getApellido2());
		labelDNI.setText(paciente.getCredencial().getUsuario_dni());
		labelTelefono.setText(paciente.getTelefono()+"");

	}

	@FXML
	void initialize() {
		assert labelAvisoEmergencia != null : "fx:id=\"labelAvisoEmergencia\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert labelInforme != null : "fx:id=\"labelInforme\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert borderPaneInsertarMapa != null : "fx:id=\"borderPaneInsertarMapa\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert textAreaDireccion != null : "fx:id=\"textAreaDireccion\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert labelLocalizacion != null : "fx:id=\"labelLocalizacion\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert labelNombre != null : "fx:id=\"labelNombre\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert labelApellidos != null : "fx:id=\"labelApellidos\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert labelDNI != null : "fx:id=\"labelDNI\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert labelTelefono != null : "fx:id=\"labelTelefono\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert tableViewCuidadores != null : "fx:id=\"tableViewCuidadores\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert tableColumnCuidadores != null : "fx:id=\"tableColumnCuidadores\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenMapa\" was not injected: check your FXML file 'VentanaEmergenciaChat.fxml'.";

		//Rellenamos los datos de la ventana
		rellenarTablaCuidadores();
		rellenarLocalizacion();
		rellenarDatosPaciente();

	}
}
