package control;

import java.net.URL;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import model.Paciente;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ControladorVentanaEmergenteAnadirStockMedicamentos {

	static Paciente paciente;
	static String language;
	static int index;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Button ButtonAnadir;

	@FXML
	private HBox labelMedicamento;

	@FXML
	private Label LabelMedicamento;

	@FXML
	private Label Labelcantidad;

	@FXML
	private TextField TFCantidad;

	@FXML
	private Label textUnidad;

	@FXML
	private Text miTexto;

	private BorderPane panelInsertarApartado;

	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}

	//identificamos el medicamento que ha selecionado y la canidad de la que dispone
	void LabelMedicamento(){
		LabelMedicamento.setText(paciente.getMedicamentos().get(index).getNombre());
		TFCantidad.setText("0");
		textUnidad.setText(paciente.getMedicamentos().get(index).getTipoDosis());
	}

	@FXML
	void AnadirStock(ActionEvent event) {
		ControladorBBDD controlador= new ControladorBBDD();

		try {    		
			if (TFCantidad.getText().trim().isEmpty()) {
				if (ControladorLogin.language.contentEquals("es_ES")) {miTexto.setText("Introduzca la cantidad a añadir");}
				else {miTexto.setText("Fill in the quantity to add");}
			}
			else  {
				if(Integer.parseInt(TFCantidad.getText())>=0) {
					String dni_paciente=paciente.getCredencial().getUsuario_dni();
					String nombreReceta=paciente.getMedicamentos().get(index).getNombre();
					int stock=Integer.parseInt(TFCantidad.getText());
					controlador.anadirStock(dni_paciente,nombreReceta,stock);
					paciente.getMedicamentos().get(index).setStock_disponible(paciente.getMedicamentos().get(index).getStock_disponible()+stock);
					mostrarControlMedicamentos();
				}
				/*int cantidadanadida= paciente.getMedicamentos().get(index).getStock_disponible() + Integer.parseInt(TFCantidad.getText());
				if(cantidadanadida>=0) {
					paciente.getMedicamentos().get(index).setStock_disponible(cantidadanadida);*/
				
				else {
					if (ControladorLogin.language.contentEquals("es_ES")) {miTexto.setText("La cantidad no es valida.");}
					else {miTexto.setText("The quantity is not a valid number.");}
				}
			}

		} catch(Exception E) {
			if (ControladorLogin.language.contentEquals("es_ES")) {miTexto.setText("La cantidad no es valida.");}
			else {miTexto.setText("The quantity is not a valid number.");}
		}


	}

	void mostrarControlMedicamentos() {
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader3 = new FXMLLoader(getClass().getResource("/view/VentanaControlMedicamentosPaciente.fxml"), bundle);	
			ControladorVentanaControlMedicamentosPaciente control2 = new ControladorVentanaControlMedicamentosPaciente();
			ControladorBBDD controlador= new ControladorBBDD();
			control2.setPanelInsertarApartado(panelInsertarApartado);
			control2.setPaciente(controlador.BuscarPaciente(paciente.getCredencial().getUsuario_dni()));
			ControladorVentanaFichaPaciente.language = language;
			loader3.setController(control2);				

			Parent root = loader3.load();				
			panelInsertarApartado.setCenter(root);

			//Cerramos la ventanaEmergente
			Stage stage = (Stage) ButtonAnadir.getScene().getWindow();
			stage.close();

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	/*void ActualizarFichero(Paciente paciente) {
		ControladorFicherosJson controladorJson = new ControladorFicherosJson();

		Vector<Paciente> pacientes = new Vector<Paciente>();
		pacientes = controladorJson.deserializarJsonPacientesAArray();

		//2. Buscamos y actualizo el paciente
		Iterator<Paciente> itr = controladorJson.deserializarJsonPacientesAArray().iterator();
		boolean exito = false;
		Paciente pacienteItr = null;
		int i =0;

		while (itr.hasNext() && !exito) {
			pacienteItr = itr.next();
			if (pacienteItr.getCredencial().getUsuario_dni().equals(paciente.getCredencial().getUsuario_dni())) {
				exito = true;
				pacientes.remove(i);
				pacientes.add(i, paciente);
			}
			i++;
		}

		//3. Ahora se guardan todos en el Json
		controladorJson.serializarArrayPacientesAJson(pacientes);
	}*/

	@FXML
	void initialize() {
		assert ButtonAnadir != null : "fx:id=\"ButtonAnadir\" was not injected: check your FXML file 'VentanaEmergenteAnadirStockMedicamentos.fxml'.";
		assert labelMedicamento != null : "fx:id=\"labelMedicamento\" was not injected: check your FXML file 'VentanaEmergenteAnadirStockMedicamentos.fxml'.";
		assert LabelMedicamento != null : "fx:id=\"LabelMedicamento\" was not injected: check your FXML file 'VentanaEmergenteAnadirStockMedicamentos.fxml'.";
		assert Labelcantidad != null : "fx:id=\"Labelcantidad\" was not injected: check your FXML file 'VentanaEmergenteAnadirStockMedicamentos.fxml'.";
		assert TFCantidad != null : "fx:id=\"TFCantidad\" was not injected: check your FXML file 'VentanaEmergenteAnadirStockMedicamentos.fxml'.";
		assert textUnidad != null : "fx:id=\"textUnidad\" was not injected: check your FXML file 'VentanaEmergenteAnadirStockMedicamentos.fxml'.";
		assert miTexto != null : "fx:id=\"miTexto\" was not injected: check your FXML file 'VentanaEmergenteAnadirStockMedicamentos.fxml'.";
		LabelMedicamento();
	}
}
