package control;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.mail.MessagingException;

import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXButton;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import model.CredencialUsuario;
import model.Usuario;

public class ControladorOlvidarContrasena {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="email"
	private JFXTextField email; // Value injected by FXMLLoader

	@FXML // fx:id="botonVolver"
	private JFXButton botonVolver; // Value injected by FXMLLoader

	@FXML // fx:id="BotonEnviar"
	private JFXButton BotonEnviar; // Value injected by FXMLLoader

	@FXML // fx:id="EmailIncorrecto"
	private Label EmailIncorrecto; // Value injected by FXMLLoader

	final static int Codigoaleatorio= (int)(1000000 * Math.random());
	static String correo;


	@FXML
	void handleBotonVolver(ActionEvent event) {
		//Cargo la ruta del fxml del GUI:
		try {
			Locale locale = new Locale(ControladorLogin.language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/GUI_Login.fxml"), bundle);
			ControladorLogin controladorLogin= new ControladorLogin();
			loader.setController(controladorLogin);
			Parent root= loader.load();
			Scene scene1 = new Scene(root);
			Main.window.setScene(scene1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	@FXML
	void PulsarEnviado(ActionEvent event) {

		boolean acceso=false;
		int i=0;

		//Deserializo los usuarios y los meto en un vector usuario		
		Vector<Usuario> listaUsuarios = new Vector<Usuario>();
		ControladorBBDD controlador= new ControladorBBDD();
		listaUsuarios= controlador.devolverTodosUsuarios();
		System.out.println(listaUsuarios.size());
		while(i<listaUsuarios.size() && !acceso) {                                                         //Bucle lista de usuarios
			if (email.getText().equals(listaUsuarios.get(i).getCredencial().getEmail())){                  //Cojo el email del usuario
				acceso=true;
				//Enviamos un correo al usuario correspondiente:
				try {
					Mail c= new Mail();   
					//El correo al que le envie el mensaje ser� el puesto en el cuadro de email
					correo = email.getText();
					//Env�o el email con el c�digo de confirmaci�n
					c.enviarEmail("Codigo de confirmacion para la recuperacion de contrasena:" + Codigoaleatorio, correo);
				} catch (MessagingException | IOException e) {
					e.printStackTrace();
				}

				//Para ambos idiomas en caso de que se env�e bien el mensaje:
				if (ControladorLogin.language.contentEquals("es_ES")) {
					EmailIncorrecto.setText("El codigo del paciente se ha enviado correctamente");
				} 
				else {
					EmailIncorrecto.setText( "The pacient code has been sent succesfully");
				}

				//Te lleva a la interfaz grafica del codigo de verificacion
				try {
					Locale locale = new Locale(ControladorLogin.language);
					ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
					FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/CodigoVerificacion.fxml"), bundle);
					ControladorCambiarContrasena controlador1= new ControladorCambiarContrasena();
					loader.setController(controlador1);
					Parent root;
					root = loader.load();
					Scene scene1 = new Scene(root);
					Main.window.setScene(scene1);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} i++;
		}


		//Para ambos idiomas en caso de que se env�e mal el mensaje:
		if(acceso==false && i== listaUsuarios.size()) {
			if (ControladorLogin.language.contentEquals("es_ES")) {
				EmailIncorrecto.setText( "Email no registrado. Pruebe de nuevo");
			} else {
				EmailIncorrecto.setText( "Email not registered. Try again");
			}
			i=0;
		}
	} 


	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert email != null : "fx:id=\"email\" was not injected: check your FXML file 'RecuperarContrasena.fxml'.";
		assert botonVolver != null : "fx:id=\"botonVolver\" was not injected: check your FXML file 'RecuperarContrasena.fxml'.";
		assert BotonEnviar != null : "fx:id=\"BotonEnviar\" was not injected: check your FXML file 'RecuperarContrasena.fxml'.";
		assert EmailIncorrecto != null : "fx:id=\"EmailIncorrecto\" was not injected: check your FXML file 'RecuperarContrasena.fxml'.";

	}
}