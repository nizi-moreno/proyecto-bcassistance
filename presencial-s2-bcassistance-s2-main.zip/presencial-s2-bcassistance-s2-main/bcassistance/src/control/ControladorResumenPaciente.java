package control;

import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.Vector;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.AgendaMedicamento;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;
import model.Ticket;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


public class ControladorResumenPaciente {

	//private BorderPane panelInsertarApartado;
	static CredencialUsuario UsuarioLogueado;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML // fx:id="LabelPaciente"
	private Label LabelPaciente; // Value injected by FXMLLoader

	@FXML // fx:id="LabelEstado"
	private Label LabelEstado; // Value injected by FXMLLoader

	@FXML // fx:id="CaritaVerde"
	private ImageView CaritaVerde; // Value injected by FXMLLoader

	@FXML // fx:id="ImagenCorazon"
	private ImageView ImagenCorazon; // Value injected by FXMLLoader

	@FXML // fx:id="ImagenMapa"
	private ImageView ImagenMapa; // Value injected by FXMLLoader

	@FXML // fx:id="ImagenMedicamento"
	private ImageView ImagenMedicamento; // Value injected by FXMLLoader

	@FXML // fx:id="TablaListadoMedicamentosDia"
	private TableView<AgendaMedicamento> TablaListadoMedicamentosDia; // Value injected by FXMLLoader

	@FXML // fx:id="ColumnaListadoMedicamentosDia"
	private TableColumn<AgendaMedicamento, String> ColumnaListadoMedicamentosDia; // Value injected by FXMLLoader

	@FXML // fx:id="LabelNotificaciones"
	private Label LabelNotificaciones; // Value injected by FXMLLoader

	@FXML // fx:id="LabelUsuarios"
	private Label LabelUsuarios; // Value injected by FXMLLoader

	@FXML // fx:id="TablaListadoClinicos"
	private TableView<Clinico> TablaListadoClinicos; // Value injected by FXMLLoader

	@FXML // fx:id="LabelClinico"
	private TableColumn<Clinico, String> LabelClinico; // Value injected by FXMLLoader

	@FXML // fx:id="TablaListadoCuidadores"
	private TableView<Cuidador> TablaListadoCuidadores; // Value injected by FXMLLoader

	@FXML // fx:id="LabelCuidador"
	private TableColumn<Cuidador, String> LabelCuidador; // Value injected by FXMLLoader

	@FXML
	private TableView<Ticket> tableViewMensajesSinLeer;

	@FXML
	private TableColumn<Ticket, String> ColumnMensajesSinLeer;

	Paciente pacienteRepresentado;

	static String language;
	private String panelactual = "Inicio";

	/*Getters y setters del panel
	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}*/

	public String rellenarTituloTabla() {
		try {
			//Actualizo la tabla seg�n el d�a de la semana:
			Date hoy=new Date();
			int numeroDia;
			Calendar cal= Calendar.getInstance();
			cal.setTime(hoy);
			numeroDia=cal.get(Calendar.DAY_OF_WEEK);
			if (language.equals("es_ES")) {
				String[] nombreDias={"Domingo","Lunes","Martes", "Miercoles","Jueves","Viernes","Sabado"};
				return nombreDias[numeroDia-1];// El dia de la semana inicia en el 1 mientras que el array empieza en el 0
			} else {
				String[] nombreDias={"Sunday","Monday","Tuesday", "Wednesday","Thursday","Friday","Saturday"};
				return nombreDias[numeroDia-1];// El dia de la semana inicia en el 1 mientras que el array empieza en el 0
			}

		}
		catch(Exception e) {
			System.out.println("Se ha producido un error al recoger el dia para rellenar el titulo la tabla");
			return "Error";
		}
	}

	public String rellenarTabla() {
		try {
			//Actualizamos la tabla seg�n de d�a que sea de la semana
			Date hoy=new Date();
			int numeroDia=0;
			Calendar cal= Calendar.getInstance();
			cal.setTime(hoy);
			numeroDia=cal.get(Calendar.DAY_OF_WEEK);
			if (language.equals("es_ES")) {
				String[] dias={"D","L","M", "M","J","V","S"};
				return dias[numeroDia-1]; //Ponemos el -1 para que nos de el lunes como primer d�a de la semana
			} 
			else {
				String[] dias={"Sun","Mon","Tue", "Wed","Thu","Fri","Sat"};
				return dias[numeroDia-1]; //Ponemos el -1 para que nos de el lunes como primer d�a de la semana
			}
		}    	
		catch(Exception e) {
			System.out.println("Se ha producido un error al recoger el dia para rellenar la tabla");
			return "L";	//Si se produce un error se muestra el lunes
		}
	}


	public ObservableList<Clinico> clinicoAsociado(){
		ObservableList<Clinico> clinicoAsociado= FXCollections.observableArrayList();
		clinicoAsociado.add(pacienteRepresentado.NombreClinico());
		return clinicoAsociado;
	}

	void rellenarTablaClinicos() {
		ObservableList<Clinico> clinicoAsociado= clinicoAsociado();	
		//LabelClinico = new TableColumn<>("pacienteRepresentado.NombreClinico()");
		LabelClinico.setCellValueFactory(new PropertyValueFactory<Clinico, String>("nombreYApellidos")); 
		TablaListadoClinicos.setItems(clinicoAsociado);
		if (language.equals("es_ES")) {
			TablaListadoClinicos.setPlaceholder(new Label("No dispone de clinico."));
		} 
		else {
			TablaListadoClinicos.setPlaceholder(new Label("Does not have clinic."));
		}
	}

	void rellenarTablaCuidadores() {
		ObservableList<Cuidador> cuidadorAsociado= pacienteRepresentado.NombreCuidadores();
		LabelCuidador.setCellValueFactory(new PropertyValueFactory<Cuidador,String>("nombreYApellidos"));
		TablaListadoCuidadores.setItems(cuidadorAsociado);

		if (language.equals("es_ES")) {
			TablaListadoClinicos.setPlaceholder(new Label("No dispone de cuidadores."));
		} 
		else {
			TablaListadoClinicos.setPlaceholder(new Label("Does not have carerers."));
		}
	}

	void rellenarTablaMedicamentos() {
		//Hacemos un observableList que ser� donde se vea la agenda completa de los medicamentos que tengo guardados en ese paciente:
		ObservableList<AgendaMedicamento> agendaCompleta = pacienteRepresentado.devolverAgendaMedicamentos();

		//Asignamos valores a nuestras columnas:
		//En caso de error, se muestra el lunes.
		ColumnaListadoMedicamentosDia.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>(rellenarTabla()));

		//Guardamos la informaci�n en nuestra tabla de medicamentos
		TablaListadoMedicamentosDia.setItems(agendaCompleta);
		//En caso de que no se disponga de medicamentos
		if (language.equals("es_ES")) {
			TablaListadoMedicamentosDia.setPlaceholder(new Label("No dispone de agenda de medicamentos."));
		} 
		else {
			TablaListadoMedicamentosDia.setPlaceholder(new Label("Does not have a medicine schedule."));
		}
	}

	void rellenarDatosPaciente() {
		//Configuramos los iconos de estado
		if (pacienteRepresentado.isEstado()==false) {
			Image imagen = new Image ("/Imagenes/feli.png");
			CaritaVerde.setImage(imagen);
		}
		else {
			Image imagen2 = new Image("/Imagenes/sad.png");
			CaritaVerde.setImage(imagen2);
		}
		//ESTADO CORAZON
		switch (pacienteRepresentado.getEstadoCorazon()) {
		case 0:
			Image image = new Image("/Imagenes/cora verde.png");
			ImagenCorazon.setImage(image);
			break;
		case 1:
			Image image1= new Image("/Imagenes/cora amarillo.png");
			ImagenCorazon.setImage(image1);
			break;
		case 2: 
			Image image2= new Image("/Imagenes/cora rojo.png");
			ImagenCorazon.setImage(image2);
			break;
		}
		//ESTADO MEDICACION
		switch (pacienteRepresentado.getEstadoMedicacion()) {
		case 0:
			Image image =new Image("/Imagenes/pastilla verde.png");
			ImagenMedicamento.setImage(image);
			break;
		case 1:
			Image image1=new Image("/Imagenes/pastilla amarilla.png"); 
			ImagenMedicamento.setImage(image1);
			break;
		case 2: 
			Image image2=new Image("/Imagenes/pastilla roja.png"); 
			ImagenMedicamento.setImage(image2);
			break;
		}
		//ESTADO ACTIVIDAD FISICA
		switch (pacienteRepresentado.getEstadoActividad()) {
		case 0:
			Image image=new Image("/Imagenes/ubicacionverde.png");
			ImagenMapa.setImage(image);
			break;
		case 2: 
			Image image2=new Image("/Imagenes/ubicacionroja.png");
			ImagenMapa.setImage(image2);
			break;
		}
	}

	void rellenarMensajesSinLeer() {
		//Rellenamos los mensajes sin leer del paciente
		//Obtenemos de la base de datos los tickets
		ControladorBBDD cBBDD= new ControladorBBDD();
		pacienteRepresentado.setListaTickets(cBBDD.consultarTickets(pacienteRepresentado.getCredencial().getUsuario_dni()));
		
		ObservableList<Ticket> listaTickets = FXCollections.observableArrayList();
		
		if(pacienteRepresentado.getListaTickets()!=null) {
		for(int i=0; i<pacienteRepresentado.getListaTickets().size(); i++) {
			for(int j=0; j<pacienteRepresentado.getListaTickets().get(i).getListaMensajes().size(); j++) {
				if(!pacienteRepresentado.getListaTickets().get(i).getListaMensajes().get(j).isLectura()) {
					if(!pacienteRepresentado.getListaTickets().get(i).getListaMensajes().get(j).getAutor().equals(pacienteRepresentado.getCredencial().getUsuario_dni())) {
						listaTickets.add(pacienteRepresentado.getListaTickets().get(i));
					}					
				}				
			}
		}

		//Asignamos valores a nuestras columnas:
		//En caso de error, se muestra el lunes.
		ColumnMensajesSinLeer.setCellValueFactory(new PropertyValueFactory<Ticket, String>("tituloSinLeer"));

		//Guardamos la informaci�n en nuestra tabla de medicamentos
		tableViewMensajesSinLeer.setItems(listaTickets);


		if (language.equals("es_ES")) {
			tableViewMensajesSinLeer.setPlaceholder(new Label("Ha leido todos sus mensajes."));
		} 
		else {
			tableViewMensajesSinLeer.setPlaceholder(new Label("You have read all your messages."));
		}
	}else {
		if (language.equals("es_ES")) {
			tableViewMensajesSinLeer.setPlaceholder(new Label("No dispone de ningun ticket abierto."));
		} 
		else {
			tableViewMensajesSinLeer.setPlaceholder(new Label("Does not have any open ticket."));
		}
	}
}

@FXML
void initialize() {
	assert LabelPaciente != null : "fx:id=\"LabelPaciente\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert LabelEstado != null : "fx:id=\"LabelEstado\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert CaritaVerde != null : "fx:id=\"CaritaVerde\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert ImagenCorazon != null : "fx:id=\"ImagenCorazon\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert ImagenMapa != null : "fx:id=\"ImagenMapa\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert ImagenMedicamento != null : "fx:id=\"ImagenMedicamento\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert TablaListadoMedicamentosDia != null : "fx:id=\"TablaListadoMedicamentosDia\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert ColumnaListadoMedicamentosDia != null : "fx:id=\"ColumnaListadoMedicamentosDia\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert LabelNotificaciones != null : "fx:id=\"LabelNotificaciones\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert LabelUsuarios != null : "fx:id=\"LabelUsuarios\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert TablaListadoClinicos != null : "fx:id=\"TablaListadoClinicos\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert LabelClinico != null : "fx:id=\"LabelClinico\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert TablaListadoCuidadores != null : "fx:id=\"TablaListadoCuidadores\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert LabelCuidador != null : "fx:id=\"LabelCuidador\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert tableViewMensajesSinLeer != null : "fx:id=\"tableViewMensajesSinLeer\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";
	assert ColumnMensajesSinLeer != null : "fx:id=\"ColumnMensajesSinLeer\" was not injected: check your FXML file 'ResumenUsuarioPaciente.fxml'.";

	//La tabla de medicacion del dia
	rellenarDatosPaciente();
	ColumnaListadoMedicamentosDia.setText(rellenarTituloTabla());             //Rellenamos el titulo de la tabla con el dia de la semana
	rellenarTablaMedicamentos();
	rellenarTablaClinicos();
	rellenarTablaCuidadores();
	rellenarMensajesSinLeer();
}

public void setPacienteRepresentado(Paciente paciente) {
	this.pacienteRepresentado=paciente;
}
}
