package control;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;

public class ControladorVentanaEmergenteBajaAplicacion {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private ImageView image;

	@FXML
	private Button botonAceptar;

	@FXML
	private Button botonCancelar;

	@FXML
	private Label mensajeBajaAplicacion;

	static String language;

	static Window window;

	static CredencialUsuario UsuarioLogueado;

	public static ControladorBLClinico blClinico;

	public static ControladorBLPaciente blPaciente;

	public static ControladorBLCuidador blCuidador;

	@FXML
	void handleBotonAceptar(ActionEvent event) {
		//DAMOS DE BAJA AL USUARIO

		//HAY QUE HACERLO CON LA BBDD
		ControladorBBDD cBBDD=new ControladorBBDD();
		
		if (UsuarioLogueado.getRol()== 0) {             //El usuario es un pacientes
			//Si el usuario es un paciente, hay que actualizar su fecha de baja, borrar su cl�nico y cualquier relaci�n de cuidadores
			 
			//Borramos su clinico asociado
			cBBDD.borrarClinicoDePaciente(UsuarioLogueado.getUsuario_dni());
			
			//Borramos la relaci�n con los cuidadores
			cBBDD.borrarRelacionPacienteCuidador(UsuarioLogueado.getUsuario_dni());
			
			//Anadimos fecha de baja
			cBBDD.insertarFechaBaja(UsuarioLogueado.getUsuario_dni());
			
			
		}
		else if(UsuarioLogueado.getRol()== 1) {         //El usuario es un cuidador
			//Hay que ponerle fecha de baja y hay que eliminar sus relaciones con pacientes	
			
			//Borramos la relaci�n con los cuidadores
			cBBDD.borrarRelacionPacienteCuidador_solo_con_DNI_Cuidador(UsuarioLogueado.getUsuario_dni());
			
			//Anadimos fecha de baja
			cBBDD.insertarFechaBaja(UsuarioLogueado.getUsuario_dni());
		}

		else if(UsuarioLogueado.getRol()== 2) {         //El usuario es un cl�nico
			
			//Hay que borrarlo de todos los pacientes que lo tengan
			cBBDD.bajaClinico(UsuarioLogueado.getUsuario_dni());
			
			//Anadimos fecha de baja
			cBBDD.insertarFechaBaja(UsuarioLogueado.getUsuario_dni());
						
		}					
		else {
			System.out.println("Ha habido un problema en el sistema");
		}

		//CERRAMOS ESTA VENTANA
		Node n= (Node) event.getSource();
		Stage stage = (Stage) n.getScene().getWindow();
		stage.close();

		//MOSTRAMOS UNA VENTANA DE CONFIRMACION
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/VentanaEmergenteConfirmacionBaja.fxml"),bundle);
			ControladorVentanaEmergenteConfirmacionBaja control = new ControladorVentanaEmergenteConfirmacionBaja();
			ControladorVentanaEmergenteConfirmacionBaja.language=language;
			control.setBlClinico(blClinico);
			control.setBlCuidador(blCuidador);
			control.setBlPaciente(blPaciente);
			loader.setController(control);
			Parent root = loader.load();
			Stage miStage = new Stage();
			miStage.setTitle("Confirmacion baja aplicacion");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(window);
			miStage.setScene(new Scene(root));
			miStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleBotonCancelar(ActionEvent event) {
		//CERRAMOS LA VENTANA EMERGENTE
		Node n= (Node) event.getSource();
		Stage stage = (Stage) n.getScene().getWindow();
		stage.close();
	}

	@FXML
	void initialize() {
		assert image != null : "fx:id=\"image\" was not injected: check your FXML file 'VentanaEmergenteBajaAplicacion.fxml'.";
		assert botonAceptar != null : "fx:id=\"botonAceptar\" was not injected: check your FXML file 'VentanaEmergenteBajaAplicacion.fxml'.";
		assert botonCancelar != null : "fx:id=\"botonCancelar\" was not injected: check your FXML file 'VentanaEmergenteBajaAplicacion.fxml'.";
		assert mensajeBajaAplicacion != null : "fx:id=\"mensajeBajaAplicacion\" was not injected: check your FXML file 'VentanaEmergenteBajaAplicacion.fxml'.";

	}
}

