package control;


import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.BorderPane;
import model.AgendaMedicamento;
import model.Callcenter;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.ECGFile;
import model.Emergencia;
import model.EmergenciaChat;
import model.Location;
import model.Mensaje;
import model.Paciente;
import model.Receta;
import model.Ticket;
import model.Usuario;


public class ControladorBBDD {

	//  Database credentials
	private static final String USER = "pr_BCAssistance";
	private static final String PASS = "tortilla";

	//Setear el formato de Data de Java por el formato aceptado de Datetime de sql 
	private static final java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	//Variables para preparar la conexion y sentencias sql
	private String sql;
	private Connection conn = null;
	private Statement stmt = null;

	public String insertarPaciente(Paciente paciente) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "Insert into usuario(usuario_dni, nombre, apellido1, apellido2, "
					+ "fecha_nacimiento, rol, email, sexo, telefono, contrasena) "
					+ "values(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar
			//Convertir boolean de sexo a int
			int sexo = paciente.getSexo()? 1:0;

			//Se rellena los values del sql 
			ps.setString(1, paciente.getCredencial().getUsuario_dni());
			ps.setString(2, paciente.getNombre());
			ps.setString(3, paciente.getApellido1());
			ps.setString(4, paciente.getApellido2());
			ps.setString(5, sdf.format(paciente.getFecha_nacimiento()));
			ps.setInt(6, paciente.getCredencial().getRol());
			ps.setString(7, paciente.getCredencial().getEmail());
			ps.setInt(8, sexo);
			ps.setInt(9, paciente.getTelefono());
			ps.setString(10, CredencialUsuario.encodePassword(paciente.getCredencial().getContrasena()));

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();
			//imagen.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe. DEVOLVEMOS ERROR");
			return "Error DNI";
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return null;

	}
	/**
	 * 
	 * @param paciente
	 * @return	//Devolvemos el paciente con sus localizaciones
	 */
	public Paciente actualizarLocalizacion(Paciente paciente){
		String DNI=paciente.getCredencial().getUsuario_dni();
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT lecturagps.* FROM lecturagps JOIN sensor ON sensor.id_sensor = lecturagps.id_sensor_GPS WHERE sensor.dni_paciente='"+ DNI +"' and sensor.fecha_baja is null" ;
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				double latitud=rs.getDouble("latitud");
				double longitud=rs.getDouble("longitud");
				Date fecha = rs.getDate("fecha");
				Location location=new Location(latitud, longitud, fecha);

				//Almacenarlos para luego devolver
				paciente.addLocation(location);

				//System.out.print( "latitud = " + latitud );
				//System.out.println( ", longitud = " + longitud );
			}
			rs.close();
			stmt.close();


			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return paciente;

	}

	public ObservableList<ECGFile> devolverDateECG(Paciente paciente, BorderPane panelInsertarApartado, String Nlanguage){
		String DNI=paciente.getCredencial().getUsuario_dni();
		//Creamos la observable list
		ObservableList<ECGFile> ECGBBDD = FXCollections.observableArrayList();

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM lecturaecg JOIN sensor ON sensor.id_sensor = lecturaecg.id_sensor_ecg WHERE sensor.dni_paciente='"+ DNI +"' order by fecha DESC" ;
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				//Recogemos la fecha como STRING, ya que luego la volvemos a meter mas a delante en la BBDD
				String fecha=rs.getString("fecha");
				int id=rs.getInt("id_lecturas");
				ECGFile file=new ECGFile(fecha,id, panelInsertarApartado, Nlanguage, paciente);
				ECGBBDD.add(file);

			}
			rs.close();
			stmt.close();


			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return ECGBBDD;

	}

	//Se comprueba que el sensor no tiene fecha de baja
	public String[] devolverECG(int id){		
		//Inicializamos la variable
		String valor="";
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM lecturaecg join sensor on id_sensor_ecg=sensor.id_sensor WHERE id_lecturas='"+ id +"' and sensor.fecha_baja is null" ;
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				//Recogemos el string
				valor=rs.getString("valor");
			}
			rs.close();
			stmt.close();

			//System.out.println(valor);

			valor=valor.replace(";;", ";");
			System.out.println("ECG: "+valor);
			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//El ECG es un array de posiciones indeterminadas
		//Convertimos el String a un array separando por ";"
		String[] ECG=valor.split(";");
		return ECG;

	}

	//Devolver ECG en lista de memoria din�mica
	public List<Integer> devolverECGList(int id){		
		//Inicializamos la variable
		String valor="";
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM lecturaecg join sensor on id_sensor_ecg=sensor.id_sensor WHERE id_lecturas='"+ id +"' and sensor.fecha_baja is null" ;
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				//Recogemos el string
				valor=rs.getString("valor");
			}
			rs.close();
			stmt.close();

			//System.out.println(valor);

			valor=valor.replace(";;", ";");
			System.out.println("ECG: "+valor);
			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//El ECG es un array de posiciones indeterminadas
		//Convertimos el String a un array separando por ";"
		List<Integer> ECG = Arrays.stream(valor.split(";"))
				.map(Integer::parseInt)
				.collect(Collectors.toList());
		return ECG;

	}

	//Insertar clinico en la tabla de usuarios
	public String insertarClinico(Clinico clinico) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "Insert into usuario(usuario_dni, nombre, apellido1, apellido2, "
					+ "fecha_nacimiento, rol, email, sexo, telefono, contrasena) "
					+ "values(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar
			//Convertir boolean de sexo a int
			int sexo = clinico.getSexo()? 1:0;

			/*Convertir img a blob
			String ruta = "src/ficheros/CarpetasUsuarios/"+clinico.getCredencial().getUsuario_dni()+
					"/"+clinico.getCredencial().getUsuario_dni()+".png";
			System.out.println(ruta);
			File file = new File(ruta);
			FileInputStream imagen = new FileInputStream(file.getAbsolutePath());*/

			//Se rellena los values del sql 
			ps.setString(1, clinico.getCredencial().getUsuario_dni());
			ps.setString(2, clinico.getNombre());
			ps.setString(3, clinico.getApellido1());
			ps.setString(4, clinico.getApellido2());
			ps.setString(5, sdf.format(clinico.getFecha_nacimiento()));
			ps.setInt(6, clinico.getCredencial().getRol());
			ps.setString(7, clinico.getCredencial().getEmail());
			//ps.setString(8, null);
			ps.setInt(8, sexo);
			ps.setInt(9, clinico.getTelefono());
			ps.setString(10, CredencialUsuario.encodePassword(clinico.getCredencial().getContrasena()));

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();
			//imagen.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Clinico ya existe. DEVOLVEMOS ERROR");
			return "Error DNI";
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return null;
	}

	/*
	 * OJO: Este m�todo tiene dos caminos segun si el paciente que queremos insertar tiene o no
	 * un clinico asociado.
	 * Si no lo tiene (null) se usa otra sentencia SQL donde no se inserta el clinico.
	 */

	//Insertar Cuidador en la tabla de usuarios
	public String insertarCuidador(Cuidador cuidador) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "Insert into usuario(usuario_dni, nombre, apellido1, apellido2, "
					+ "fecha_nacimiento, rol, email, sexo, telefono, contrasena) "
					+ "values(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar
			//Convertir boolean de sexo a int
			int sexo = cuidador.getSexo()? 1:0;

			/*Convertir img a blob
			String ruta = "src/ficheros/CarpetasUsuarios/"+cuidador.getCredencial().getUsuario_dni()+
					"/"+cuidador.getCredencial().getUsuario_dni()+".png";
			System.out.println(ruta);
			File file = new File(ruta);
			FileInputStream imagen = new FileInputStream(file.getAbsolutePath());*/

			//Se rellena los values del sql 
			ps.setString(1, cuidador.getCredencial().getUsuario_dni());
			ps.setString(2, cuidador.getNombre());
			ps.setString(3, cuidador.getApellido1());
			ps.setString(4, cuidador.getApellido2());
			ps.setString(5, sdf.format(cuidador.getFecha_nacimiento()));
			ps.setInt(6, cuidador.getCredencial().getRol());
			ps.setString(7, cuidador.getCredencial().getEmail());
			//ps.setBinaryStream(8, imagen, (int) file.length());
			//ps.setString(8, null);
			ps.setInt(8, sexo);
			ps.setInt(9, cuidador.getTelefono());
			String encodedpass = CredencialUsuario.encodePassword(cuidador.getCredencial().getContrasena());
			ps.setString(10, encodedpass);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();
			//imagen.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Cuidador ya existe. DEVOLVEMOS ERROR");
			return "Error DNI";
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return null;
	}

	//Insertar un paciente en la BBDD. Previamente debe haberse insertado como usuario 
	public void insertarTablaPaciente(Paciente paciente) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//CASO 1: NO HAY M�DICO ASOCIADO
			if(paciente.getClinico().equals("")) {
				System.out.println("-Sin clinico asociado");
				sql = "Insert into paciente(dni_paciente, peso, altura, estadoCorazon, estadoMedicacion, estadoActividadGPS) "
						+ "values(?,?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);

				//Se rellena los values del sql 
				ps.setString(1, paciente.getCredencial().getUsuario_dni());				
				ps.setDouble(2, paciente.getPeso());
				ps.setInt(3, paciente.getAltura());
				ps.setInt(4,paciente.getEstadoCorazon());
				ps.setInt(5,paciente.getEstadoMedicacion());
				ps.setInt(6,paciente.getEstadoActividad());
				//STEP 4: Insertando un valor.
				ps.executeUpdate();
				ps.close();
				conn.close();

			}
			//CASO 2: SI HAY M�DICO ASOCIADAO
			else {
				//STEP 3: Preparar la sentencia sql.
				sql = "Insert into paciente(dni_paciente, dni_clinico, peso, altura, estadoCorazon, estadoMedicacion, estadoActividadGPS) "
						+ "values(?,?,?,?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);

				//Se rellena los values del sql 
				ps.setString(1, paciente.getCredencial().getUsuario_dni());
				ps.setString(2, paciente.getClinico());
				ps.setDouble(3, paciente.getPeso());
				ps.setInt(4, paciente.getAltura());
				ps.setInt(5,paciente.getEstadoCorazon());
				ps.setInt(6,paciente.getEstadoMedicacion());
				ps.setInt(7,paciente.getEstadoActividad());

				//STEP 4: Insertando un valor.
				ps.executeUpdate();
				ps.close();
				conn.close();
			}

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}


	public Vector<Paciente> ConsultarPacientes() {
		Vector<Paciente> vectorPacientes = new Vector<Paciente>();

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM usuario JOIN paciente on usuario.usuario_dni = paciente.dni_paciente WHERE rol=0 AND fecha_baja is null";
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");
				String clinico = rs.getString("dni_clinico");
				int peso = rs.getInt("peso");
				int altura = rs.getInt("altura");
				int estadoCorazon = rs.getInt("estadoCorazon");
				int estadoMedicacion = rs.getInt("EstadoMedicacion");

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				Paciente paciente = new Paciente(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);

				//Agregar los datos extrta si tiene
				paciente.setPeso(peso);
				paciente.setAltura(altura);
				paciente.setEstadoCorazon(estadoCorazon);
				paciente.setEstadoMedicacion(estadoMedicacion);

				//Recuperar las recetas y anadirlas al paciente
				Vector <Receta> recetas = getRecetas(dni);

				for (int i=0; i<recetas.size();i++) {
					paciente.addMedicina(recetas.get(i));
				}

				//Almacenarlos para luego devolver
				vectorPacientes.add(paciente);

				System.out.print( "DNI = " + dni );
				System.out.print( ", nombre = " + nombre + " " + apellido1 + " " + apellido2);
				System.out.print( ", fecha nacimiento = " + nacimiento );
				System.out.println( ", sexo = " + sexo );
			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//STEP 6: Devolver el array con la respuesta
		return vectorPacientes;

	}

	public Paciente BuscarPaciente(String DNI) {
		Paciente paciente = null;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			//sql = "SELECT * FROM usuario WHERE usuario_dni='"+ paciente.getCredencial().getUsuario_dni() +"'";
			sql = "SELECT usuario.*, paciente.dni_clinico FROM usuario JOIN paciente on usuario.usuario_dni = paciente.dni_paciente "
					+ "WHERE usuario_dni='"+ DNI +"' AND fecha_baja is null" ;
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");
				String clinico = rs.getString("dni_clinico");
				java.sql.Blob blob = rs.getBlob("foto_perfil");  
				InputStream in = blob.getBinaryStream();  
				BufferedImage buffer = ImageIO.read(in);
				Image imagen = convertToFxImage(buffer);


				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				paciente = new Paciente(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);
				paciente.setClinico(clinico);
				paciente.setImagenPerfil(imagen);

				Vector <Receta> recetas = new Vector<Receta>();
				//Recuperar las recetas y anadirlas al paciente
				String sql2 = "SELECT * FROM receta JOIN agendamedicamento a on receta.id_receta = a.id_receta"
						+ " WHERE dni_paciente=" + "'"+DNI+"'" + "AND DATE_ADD(receta.fecha, INTERVAL receta.frecuenia week) > UNIX_TIMESTAMP();";

				//System.out.println("sql Select: "+sql);
				ResultSet rs2 = stmt.executeQuery(sql2); 

				while ( rs2.next() ) {
					//Para crear la receta
					int ID = rs2.getInt("id_receta");
					String nombreReceta= rs2.getString("nombre");
					String descripcion = rs2.getString("descripcion");
					int stock = rs2.getInt("Stock");
					int udxtoma= rs2.getInt("unidades_por_toma");
					int frecuencia = rs2.getInt("frecuenia");
					Timestamp fecha = rs2.getTimestamp("fecha");


					Receta nuevaReceta= new Receta(nombreReceta, descripcion, "ud.", udxtoma, stock , frecuencia/7, fecha, ID);

					//Para crear y asignar la agenda de la receta
					Vector<AgendaMedicamento> nuevaAgenda= new Vector<>();

					AgendaMedicamento agendaManana= new AgendaMedicamento("Manana", rs2.getString("LManana"), rs2.getString("MManana"), 
							rs2.getString("XManana"), rs2.getString("JManana"), rs2.getString("VManana"), rs2.getString("SManana"), rs2.getString("DManana"));
					nuevaAgenda.add(agendaManana);

					AgendaMedicamento agendaMediodia= new AgendaMedicamento("Mediodia", rs2.getString("LMediodia"), rs2.getString("MMediodia"), 
							rs2.getString("XMediodia"), rs2.getString("JMediodia"), rs2.getString("VMediodia"), rs2.getString("SMediodia"), rs2.getString("DMediodia"));
					nuevaAgenda.add(agendaMediodia);

					AgendaMedicamento agendaNoche= new AgendaMedicamento("Noche", rs2.getString("LNoche"), rs2.getString("MNoche"), 
							rs2.getString("XNoche"), rs2.getString("JNoche"), rs2.getString("VNoche"), rs2.getString("SNoche"), rs2.getString("DNoche"));
					nuevaAgenda.add(agendaNoche);

					nuevaReceta.setAgendaMedicamento(nuevaAgenda);

					//Anadir al resultado de las recetas
					recetas.add(nuevaReceta);

				}
				

				for (int i=0; i<recetas.size();i++) {
					paciente.addMedicina(recetas.get(i));
				}

				//Recuperar sus cuidadores
				Vector <String> cuidadores = listadoDNICuidadoresdePaciente(DNI);
				paciente.setCuidadores(cuidadores);


				System.out.print( "DNI = " + dni );
				System.out.print( ", nombre = " + nombre + " " + apellido1 + " " + apellido2);
				System.out.print( ", fecha nacimiento = " + nacimiento );
				System.out.println( ", sexo = " + sexo );
			}


			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return paciente;
	}

	public Vector<Paciente>  BuscarListaPaciente(Vector<String> DNIPacientes) {
		Vector<Paciente> listaPacientes = new Vector<Paciente>();
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			String listaDNI = "";
			for(int i=0; i<DNIPacientes.size();i++) {
				listaDNI = "'" + DNIPacientes.get(i) + "'," + (String) listaDNI;
			}
			listaDNI = listaDNI + "0";
			System.out.println(listaDNI);

			//STEP 3: Preparar la sentencia sql.
			//sql = "SELECT * FROM usuario WHERE usuario_dni='"+ paciente.getCredencial().getUsuario_dni() +"'";
			sql = "SELECT usuario.*, paciente.dni_clinico FROM usuario JOIN paciente on usuario.usuario_dni = paciente.dni_paciente "
					+ "WHERE usuario_dni IN ("+ listaDNI +") AND fecha_baja is null" ;
			System.out.println(sql);
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");
				String clinico = rs.getString("dni_clinico");
				java.sql.Blob blob = rs.getBlob("foto_perfil");  
				InputStream in = blob.getBinaryStream();  
				BufferedImage buffer = ImageIO.read(in);
				Image imagen = convertToFxImage(buffer);

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				Paciente paciente = new Paciente(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);
				paciente.setClinico(clinico);
				paciente.setImagenPerfil(imagen);

				Vector <Receta> recetas = new Vector<Receta>();
				//Recuperar las recetas y anadirlas al paciente
				String sql2 = "SELECT * FROM receta JOIN agendamedicamento a on receta.id_receta = a.id_receta"
						+ " WHERE dni_paciente=" + "'"+credencial.getUsuario_dni()+"'" + "AND DATE_ADD(receta.fecha, INTERVAL receta.frecuenia week) > UNIX_TIMESTAMP();";
				//Recuperar las recetas y anadirlas al paciente
				//System.out.println("sql Select: "+sql);
				ResultSet rs2 = stmt.executeQuery(sql2); 

				while ( rs2.next() ) {
					//Para crear la receta
					int ID = rs2.getInt("id_receta");
					String nombreReceta= rs2.getString("nombre");
					String descripcion = rs2.getString("descripcion");
					int stock = rs2.getInt("Stock");
					int udxtoma= rs2.getInt("unidades_por_toma");
					int frecuencia = rs2.getInt("frecuenia");
					Timestamp fecha = rs2.getTimestamp("fecha");


					Receta nuevaReceta= new Receta(nombreReceta, descripcion, "ud.", udxtoma, stock , frecuencia/7, fecha, ID);

					//Para crear y asignar la agenda de la receta
					Vector<AgendaMedicamento> nuevaAgenda= new Vector<>();

					AgendaMedicamento agendaManana= new AgendaMedicamento("Manana", rs2.getString("LManana"), rs2.getString("MManana"), 
							rs2.getString("XManana"), rs2.getString("JManana"), rs2.getString("VManana"), rs2.getString("SManana"), rs2.getString("DManana"));
					nuevaAgenda.add(agendaManana);

					AgendaMedicamento agendaMediodia= new AgendaMedicamento("Mediodia", rs2.getString("LMediodia"), rs2.getString("MMediodia"), 
							rs2.getString("XMediodia"), rs2.getString("JMediodia"), rs2.getString("VMediodia"), rs2.getString("SMediodia"), rs2.getString("DMediodia"));
					nuevaAgenda.add(agendaMediodia);

					AgendaMedicamento agendaNoche= new AgendaMedicamento("Noche", rs2.getString("LNoche"), rs2.getString("MNoche"), 
							rs2.getString("XNoche"), rs2.getString("JNoche"), rs2.getString("VNoche"), rs2.getString("SNoche"), rs2.getString("DNoche"));
					nuevaAgenda.add(agendaNoche);

					nuevaReceta.setAgendaMedicamento(nuevaAgenda);

					//Anadir al resultado de las recetas
					recetas.add(nuevaReceta);

				}

				for (int i=0; i<recetas.size();i++) {
					paciente.addMedicina(recetas.get(i));
				}

				listaPacientes.add(paciente);


				System.out.print( "DNI = " + dni );
				System.out.print( ", nombre = " + nombre + " " + apellido1 + " " + apellido2);
				System.out.print( ", fecha nacimiento = " + nacimiento );
				System.out.println( ", sexo = " + sexo );
			}


			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return listaPacientes;
	}

	public Clinico BuscarClinico(String DNI) {
		Clinico clinico = null;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM usuario WHERE usuario_dni='"+ DNI +"' AND fecha_baja is null";
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");
				Image imagen=null;
				try {
					java.sql.Blob blob = rs.getBlob("foto_perfil");  
					InputStream in = blob.getBinaryStream();  
					BufferedImage buffer = ImageIO.read(in);
					imagen = convertToFxImage(buffer);
				}
				catch(Exception e){

				}

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				clinico = new Clinico(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);
				clinico.setImagenPerfil(imagen);

				Vector <String> pacientesID= listadoPacientesdeClinico(dni);

				for(int i=0; i<pacientesID.size(); i++) {
					clinico.addPacienteID(pacientesID.get(i));
				}

				System.out.print( "DNI = " + dni );
				System.out.print( ", nombre = " + nombre + " " + apellido1 + " " + apellido2);
				System.out.print( ", fecha nacimiento = " + nacimiento );
				System.out.println( ", sexo = " + sexo );
			}


			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return clinico;
	}

	public Vector<String> listadoPacientesdeClinico(String DNI) {
		//Vector <String> pacientes = null;
		Vector <String> pacientes = new Vector<String>();
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT paciente.dni_paciente " + 
					"FROM paciente " + 
					"Join usuario u on paciente.dni_paciente = u.usuario_dni " +
					"WHERE dni_clinico='"+ DNI +"' AND fecha_baja is null";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("dni_paciente");
				pacientes.add(dni);

			}

			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return pacientes;

	}


	public Cuidador BuscarCuidador(String DNI) {
		Cuidador cuidador = null;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			//sql = "SELECT * FROM usuario WHERE usuario_dni='"+ paciente.getCredencial().getUsuario_dni() +"'";
			sql = "SELECT * FROM usuario WHERE usuario_dni='"+ DNI +"' AND fecha_baja is null";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");
				java.sql.Blob blob = rs.getBlob("foto_perfil");  
				InputStream in = blob.getBinaryStream();  
				BufferedImage buffer = ImageIO.read(in);
				Image imagen = convertToFxImage(buffer);

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				cuidador = new Cuidador(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);
				cuidador.setImagenPerfil(imagen);

				System.out.print( "DNI = " + dni );
				System.out.print( ", nombre = " + nombre + " " + apellido1 + " " + apellido2);
				System.out.print( ", fecha nacimiento = " + nacimiento );
				System.out.println( ", sexo = " + sexo );
			}


			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return cuidador;
	}

	public Vector<String> listadoPacientesdeCuidador(String DNI) {
		//	Vector <String> pacientes = null;
		Vector <String> pacientes = new Vector<String>();
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT paciente.dni_paciente "
					+ "FROM paciente Join tiene t on paciente.dni_paciente = t.dni_paciente "
					+ "Join usuario u on paciente.dni_paciente = u.usuario_dni "
					+ "WHERE t.dni_cuidador='"+ DNI +"' AND fecha_baja is null";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("dni_paciente");
				pacientes.add(dni);

			}

			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return pacientes;

	}

	//Cuidadores de un paciente
	public Vector<String> listadoDNICuidadoresdePaciente(String DNIPaciente) {
		Vector <String> cuidadores = new Vector<String>();
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT t.dni_cuidador\n" + 
					"FROM tiene t\n" + 
					"Join usuario u on t.dni_cuidador = u.usuario_dni\n" + 
					"WHERE t.dni_paciente='"+DNIPaciente+ "' AND fecha_baja is null;";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("dni_cuidador");
				cuidadores.add(dni);

			}

			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return cuidadores;

	}

	//Cuidadores de un paciente
	public Vector<Cuidador> listadoNombresCuidadoresdePaciente(String DNIPaciente) {
		Vector <Cuidador> cuidadores = new Vector<Cuidador>();
		Cuidador cuidador = null;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT u.* \n" + 
					"FROM tiene t\n" + 
					"Join usuario u on t.dni_cuidador = u.usuario_dni\n" + 
					"WHERE t.dni_paciente='"+DNIPaciente+ "' AND fecha_baja is null;";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );

			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");
				java.sql.Blob blob = rs.getBlob("foto_perfil");  
				InputStream in = blob.getBinaryStream();  
				BufferedImage buffer = ImageIO.read(in);
				Image imagen = convertToFxImage(buffer);

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				cuidador = new Cuidador(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);
				cuidador.setImagenPerfil(imagen);

				cuidadores.add(cuidador);

			}

			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return cuidadores;

	}
	//Cuidadores de un paciente
	public Clinico listadoNombresClinicosdePaciente(String DNIPaciente) {
		Clinico clinico = null;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT u.* \n" + 
					"FROM paciente t\n" + 
					"Join usuario u on t.dni_clinico = u.usuario_dni\n" + 
					"WHERE t.dni_paciente='"+DNIPaciente+ "' AND fecha_baja is null;";
			
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			
			while ( rs.next() ) {
			String dni = rs.getString("usuario_dni");
			Date fecha_baja = rs.getDate("fecha_baja");
			String  nombre = rs.getString("nombre");
			String  apellido1 = rs.getString("apellido1");
			String  apellido2 = rs.getString("apellido2");
			Date nacimiento = rs.getDate("fecha_nacimiento");
			int rol = rs.getInt("rol");
			String email = rs.getString("email");
			int sexo = rs.getInt("sexo");
			int telefono = rs.getInt("telefono");
			String contrasena = rs.getString("contrasena");
			java.sql.Blob blob = rs.getBlob("foto_perfil");  
			InputStream in = blob.getBinaryStream();  
			BufferedImage buffer = ImageIO.read(in);
			Image imagen = convertToFxImage(buffer);

			//Convertir los datos para los constructores
			Boolean alta = (fecha_baja==null) ? true:false;
			Boolean sex = sexo==1 ? true:false;

			//Crear la credencial y el paciente
			CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
			clinico = new Clinico(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);
			clinico.setImagenPerfil(imagen);
			System.out.println(clinico.getNombre());
			}

			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return clinico;

	}
	public Callcenter BuscarCallcenter(String DNI) {
		Callcenter callcenter = null;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM usuario WHERE usuario_dni='"+ DNI +"' AND fecha_baja is null";
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");
				java.sql.Blob blob = rs.getBlob("foto_perfil");  
				InputStream in = blob.getBinaryStream();  
				BufferedImage buffer = ImageIO.read(in);
				Image imagen = convertToFxImage(buffer);

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				callcenter = new Callcenter(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);
				callcenter.setImagenPerfil(imagen);

				System.out.print( "DNI = " + dni );
				System.out.print( ", nombre = " + nombre + " " + apellido1 + " " + apellido2);
				System.out.print( ", fecha nacimiento = " + nacimiento );
				System.out.println( ", sexo = " + sexo );
			}


			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return callcenter;
	}

	public int devolverRol(String DNI) {
		int rol=-1;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			//sql = "SELECT * FROM usuario WHERE usuario_dni='"+ paciente.getCredencial().getUsuario_dni() +"'";
			sql = "SELECT * FROM usuario WHERE usuario_dni='"+ DNI +"'";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				rol = rs.getInt("rol");

			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

			//return rol;

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return rol;

	}

	//Anadir un paciente a un cuidador
	public void relacionarPacienteCuidador(String cuidador, String paciente) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "Insert into tiene(dni_paciente, dni_cuidador) "
					+ "values(?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar

			//Se rellena los values del sql 
			ps.setString(1, paciente);
			ps.setString(2, cuidador);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	/*
	 * Se hace un UPDATE a una fila de la tabla de pacientes para asociarles el nuemo 
	 * clinico que antes era NULL
	 */
	public void relacionarPacienteClinico(String clinico, String paciente) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "Update paciente set dni_clinico= ? where dni_paciente=? ";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar

			//Se rellena los values del sql 
			ps.setString(1, clinico);
			ps.setString(2, paciente);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	//Funci�n a�adir recetas a un paciente y cl�nico
	public void recetasPacieteClinico(Receta receta, Paciente paciente) {

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//A�ado la receta a la lista de recetas			
			//STEP 3: Preparar la sentencia sql: 
			sql = "Insert into receta(dni_clinico, dni_paciente, nombre, "
					+ "descripcion, stock, unidades_por_toma, frecuenia, fecha, tipo_dosis) "
					+ "values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);

			//INSERTAR TODAS LAS RECETAS:
			//Relleno los values del sql 
			ps.setString(1, paciente.getClinico());
			System.out.println(paciente.getClinico());
			ps.setString(2, paciente.getCredencial().getUsuario_dni());
			System.out.println(paciente.getCredencial().getUsuario_dni());
			ps.setString(3, receta.getNombre());
			System.out.println(receta.getNombre());
			ps.setString(4, receta.getDescripcion());
			System.out.println(receta.getDescripcion());
			ps.setInt(5, receta.getStock_disponible());
			System.out.println(receta.getStock_disponible());
			ps.setInt(6, receta.getUnidadesPorToma());
			System.out.println(receta.getUnidadesPorToma());
			ps.setInt(7, receta.getFrecuencia());
			System.out.println(receta.getFrecuencia());
			ps.setString(8, sdf.format(receta.getFecha()));
			System.out.println(sdf.format(receta.getFecha()));
			ps.setString(9, receta.getTipoDosis());
			System.out.println(receta.getTipoDosis());

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}


	public int devolverIdUltimaReceta(String dniPaciente){

		int idReceta=0;

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM receta WHERE fecha=(SELECT MAX(fecha) FROM receta WHERE dni_paciente='"+dniPaciente+"')";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while ( rs.next() ) {
				idReceta= rs.getInt("id_receta");
			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

			System.out.println("ID ULTIMA RECETA BBDD: "+idReceta);

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return idReceta;
	}



	public int devolverStockReceta(String dniPaciente, String nombre){

		int stockReceta=0;

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM receta WHERE nombre=" + "'"+nombre+"'" + "AND dni_paciente='" + dniPaciente + "'";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql); 

			while ( rs.next() ) {
				stockReceta= rs.getInt("stock");
			}

			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

			System.out.println("ID ULTIMA RECETA BBDD: "+ stockReceta);

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return stockReceta;
	} 

	public void anadirStock (String dniPaciente, String nombre, int stock) {
		try {
			//Sumo el valor que me han dado a la nueva receta
			int stocknuevo= stock + devolverStockReceta(dniPaciente, nombre);
			System.out.println(stocknuevo);

			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "UPDATE receta SET stock=? WHERE nombre='"+nombre+"' AND dni_paciente='" + dniPaciente + "'";

			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setInt(1, stocknuevo);

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//Metemos la agenda de medicamentos
		//insertarAgendaMedicamento(dniPaciente, receta);


	}

	public void eliminarStock (String dniPaciente, String nombre) {
		try {
			//Sumo el valor que me han dado a la nueva receta
			int stocknuevo= devolverStockReceta(dniPaciente, nombre)-1;
			System.out.println(stocknuevo);

			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "UPDATE receta SET stock=? WHERE nombre='"+nombre+"' AND dni_paciente='" + dniPaciente + "'";

			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setInt(1, stocknuevo);

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//Metemos la agenda de medicamentos
		//insertarAgendaMedicamento(dniPaciente, receta);


	}

	public void insertarAgendaMedicamento(String dniPaciente, Receta receta) {
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			sql = "Insert into agendamedicamento(id_receta, LManana, MManana, XManana, JManana, VManana,SManana, DManana,"
					+ "LMediodia, MMediodia,XMediodia,JMediodia,VMediodia,SMediodia, DMediodia,"
					+ "LNoche, MNoche,XNoche,JNoche,VNoche,SNoche, DNoche) "
					+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setInt(1, devolverIdUltimaReceta(dniPaciente));
			ps.setString(2, receta.getAgendaMedicamento().get(0).getL()+"");
			System.out.println(receta.getAgendaMedicamento().get(0).getL());
			ps.setString(3, receta.getAgendaMedicamento().get(0).getM()+"");
			ps.setString(4, receta.getAgendaMedicamento().get(0).getX()+"");
			ps.setString(5, receta.getAgendaMedicamento().get(0).getJ()+"");
			ps.setString(6, receta.getAgendaMedicamento().get(0).getV()+"");
			ps.setString(7, receta.getAgendaMedicamento().get(0).getS()+"");
			ps.setString(8, receta.getAgendaMedicamento().get(0).getD()+"");
			ps.setString(9, receta.getAgendaMedicamento().get(1).getL()+"");
			ps.setString(10, receta.getAgendaMedicamento().get(1).getM()+"");
			ps.setString(11, receta.getAgendaMedicamento().get(1).getX()+"");
			ps.setString(12, receta.getAgendaMedicamento().get(1).getJ()+"");
			ps.setString(13, receta.getAgendaMedicamento().get(1).getV()+"");
			ps.setString(14, receta.getAgendaMedicamento().get(1).getS()+"");
			ps.setString(15, receta.getAgendaMedicamento().get(1).getD()+"");
			ps.setString(16, receta.getAgendaMedicamento().get(2).getL()+"");
			ps.setString(17, receta.getAgendaMedicamento().get(2).getM()+"");
			ps.setString(18, receta.getAgendaMedicamento().get(2).getX()+"");
			ps.setString(19, receta.getAgendaMedicamento().get(2).getJ()+"");
			ps.setString(20, receta.getAgendaMedicamento().get(2).getV()+"");
			ps.setString(21, receta.getAgendaMedicamento().get(2).getS()+"");
			ps.setString(22, receta.getAgendaMedicamento().get(2).getD()+"");

			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	public void insertarReceta (String dniPaciente, Receta receta, String dniClinico ) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "Insert into receta(dni_clinico, dni_paciente, nombre, descripcion, stock, unidades_por_toma, frecuenia, tipo_dosis) "
					+ "values(?,?,?,?,?,?,?,?)";

			PreparedStatement ps = conn.prepareStatement(sql);

			//Se rellena los values del sql 
			ps.setString(1, dniClinico);
			ps.setString(2, dniPaciente);
			ps.setString(3, receta.getNombre());
			ps.setString(4, receta.getDescripcion());
			ps.setInt(5, 0);
			ps.setInt(6, receta.getUnidadesPorToma());
			ps.setInt(7, receta.getFrecuencia());
			ps.setString(8, receta.getTipoDosis());

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//Metemos la agenda de medicamentos
		insertarAgendaMedicamento(dniPaciente, receta);

	}

	/**LOGIN OPTIMIZADO2
	 * Si no lo encuentra, nos devuelve un usuario null
	 * 
	 * @param DNI
	 * @return
	 */

	public Usuario loginOptimizado2(String DNI, String pswdNoEncriptada) {

		//Necesitamos la contrasena encriptada para comparar con la BBDD
		String encriptedPassword=CredencialUsuario.encodePassword(pswdNoEncriptada);
		System.out.println("Usuario: "+ DNI);
		System.out.println("Encriptada: "+encriptedPassword);

		Usuario usuario=null;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			//sql = "SELECT * FROM usuario WHERE usuario_dni='"+ paciente.getCredencial().getUsuario_dni() +"'";
			sql = "SELECT * FROM usuario WHERE usuario_dni='"+ DNI +"' AND contrasena='"+ encriptedPassword +"'";
			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				usuario = new Usuario(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);

				System.out.print( "DNI = " + dni );
				System.out.print( ", nombre = " + nombre + " " + apellido1 + " " + apellido2);
				System.out.print( ", fecha nacimiento = " + nacimiento );
				System.out.println( ", sexo = " + sexo );
			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

			//return rol;

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		if(usuario==null) {
			System.out.println("-->Usuario no encontrado en la BBDD");
		}
		return usuario;

	}



	public void ModificarContrasena(Usuario usuario){		

		try {
			//Sumo el valor que me han dado a la nueva receta
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");	

			//STEP 3: Preparar la sentencia sql.

			sql = "UPDATE usuario SET contrasena=? WHERE usuario_dni='" + usuario.getCredencial().getUsuario_dni() + "'";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setString(1, CredencialUsuario.encodePassword(usuario.getCredencial().getContrasena()));

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();
			System.out.println("HECHO");

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Contrase�a ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}



	public Vector<Usuario> devolverTodosUsuarios(){

		Vector<Usuario> usuarios = new Vector<>();
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM usuario WHERE fecha_baja is NULL";
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(rol, dni, email, contrasena, alta);
				Usuario usuario = new Usuario(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);

				//Almacenarlos para luego devolver
				usuarios.add(usuario);

				System.out.print( "DNI = " + dni );
				System.out.print( ", nombre = " + nombre + " " + apellido1 + " " + apellido2);
				System.out.print( ", fecha nacimiento = " + nacimiento );
				System.out.println( ", sexo = " + sexo );
			}
			rs.close();
			stmt.close();


			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return usuarios;

	}

	//Metodo que devuleve las recetas de un paciente para rellenar la lista de recetas y agenda
	public Vector<Receta> getRecetas(String DNI) {

		Vector<Receta> vectorRecetas= new Vector<Receta>();

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM receta JOIN agendamedicamento a on receta.id_receta = a.id_receta"
					+ " WHERE dni_paciente=" + "'"+DNI+"'" + "AND DATE_ADD(receta.fecha, INTERVAL receta.frecuenia week) > UNIX_TIMESTAMP();";

			//System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql); 

			while ( rs.next() ) {
				//Para crear la receta
				int ID = rs.getInt("id_receta");
				String nombre= rs.getString("nombre");
				String descripcion = rs.getString("descripcion");
				int stock = rs.getInt("Stock");
				int udxtoma= rs.getInt("unidades_por_toma");
				int frecuencia = rs.getInt("frecuenia");
				Timestamp fecha = rs.getTimestamp("fecha");


				Receta nuevaReceta= new Receta(nombre, descripcion, "ud.", udxtoma, stock , frecuencia/7, fecha, ID);

				//Para crear y asignar la agenda de la receta
				Vector<AgendaMedicamento> nuevaAgenda= new Vector<>();

				AgendaMedicamento agendaManana= new AgendaMedicamento("Manana", rs.getString("LManana"), rs.getString("MManana"), 
						rs.getString("XManana"), rs.getString("JManana"), rs.getString("VManana"), rs.getString("SManana"), rs.getString("DManana"));
				nuevaAgenda.add(agendaManana);

				AgendaMedicamento agendaMediodia= new AgendaMedicamento("Mediodia", rs.getString("LMediodia"), rs.getString("MMediodia"), 
						rs.getString("XMediodia"), rs.getString("JMediodia"), rs.getString("VMediodia"), rs.getString("SMediodia"), rs.getString("DMediodia"));
				nuevaAgenda.add(agendaMediodia);

				AgendaMedicamento agendaNoche= new AgendaMedicamento("Noche", rs.getString("LNoche"), rs.getString("MNoche"), 
						rs.getString("XNoche"), rs.getString("JNoche"), rs.getString("VNoche"), rs.getString("SNoche"), rs.getString("DNoche"));
				nuevaAgenda.add(agendaNoche);

				nuevaReceta.setAgendaMedicamento(nuevaAgenda);

				//Anadir al resultado de las recetas
				vectorRecetas.add(nuevaReceta);

			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return vectorRecetas;
	}

	/*
	 * Se elimina el clinico asociado de un paciente.
	 * Solo necesitamos pasarle el DNI del paciente que queremos borrar su cl�nico asociado.
	 */	



	public void ModificarReceta(Receta receta){
		/* Datos:
		 * Nombre
		 * Descripcion
		 * stock
		 * unidadesxtoma
		 * frecuencia (solo si es mayor a la actual)
		 * NO: fecha, tipodosis
		 */

		//1. Consultar las recetas  y conseguir la key de la Nreceta
		try {
			//Sumo el valor que me han dado a la nueva receta
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			System.out.println("ID: " + receta.getID());

			sql = "update receta JOIN agendamedicamento a on receta.id_receta = a.id_receta "
					+ "set nombre='"+ receta.getNombre()+"',"
					+ "descripcion='" + receta.getDescripcion()+ "',"
					+ "stock=" + receta.getStock_disponible()+ ","
					+ "unidades_por_toma=" + receta.getUnidadesPorToma()+ ","
					+ "frecuenia=" + receta.getFrecuencia() + ","
					+ "LManana='" + receta.getAgendaMedicamento().get(0).getL() + "',"
					+ "MManana='" + receta.getAgendaMedicamento().get(0).getM() + "',"
					+ "XManana='" + receta.getAgendaMedicamento().get(0).getX() + "',"
					+ "JManana='" + receta.getAgendaMedicamento().get(0).getJ() + "',"
					+ "VManana='" + receta.getAgendaMedicamento().get(0).getV() + "',"
					+ "SManana='" + receta.getAgendaMedicamento().get(0).getS() + "',"
					+ "DManana='" + receta.getAgendaMedicamento().get(0).getD() + "',"
					+ "LMediodia='" + receta.getAgendaMedicamento().get(1).getL() + "',"
					+ "MMediodia='" + receta.getAgendaMedicamento().get(1).getM() + "',"
					+ "XMediodia='" + receta.getAgendaMedicamento().get(1).getX() + "',"
					+ "JMediodia='" + receta.getAgendaMedicamento().get(1).getJ() + "',"
					+ "VMediodia='" + receta.getAgendaMedicamento().get(1).getV() + "',"
					+ "SMediodia='" + receta.getAgendaMedicamento().get(1).getS() + "',"
					+ "DMediodia='" + receta.getAgendaMedicamento().get(1).getD() + "',"
					+ "LNoche='" + receta.getAgendaMedicamento().get(2).getL() + "',"
					+ "MNoche='" + receta.getAgendaMedicamento().get(2).getM() + "',"
					+ "XNoche='" + receta.getAgendaMedicamento().get(2).getX() + "',"
					+ "JNoche='" + receta.getAgendaMedicamento().get(2).getJ() + "',"
					+ "VNoche='" + receta.getAgendaMedicamento().get(2).getV() + "',"
					+ "SNoche='" + receta.getAgendaMedicamento().get(2).getS() + "',"
					+ "DNoche='" + receta.getAgendaMedicamento().get(2).getD() +"' "
					+" where receta.id_receta="+ receta.getID()+";";

			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();


		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}
	//Metemos la agenda de medicamentos
	//insertarAgendaMedicamento(dniPaciente, receta);


	public void ModificarClinico(Clinico clinico){		

		try {
			//Sumo el valor que me han dado a la nueva receta
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");	

			//STEP 3: Preparar la sentencia sql.

			sql = "UPDATE usuario SET nombre=?, apellido1=?, apellido2=?, fecha_nacimiento=?,"
					+ "telefono=?, email=?, contrasena=? WHERE usuario_dni='" + clinico.getCredencial().getUsuario_dni() + "'";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setString(1, clinico.getNombre());
			ps.setString(2, clinico.getApellido1());
			ps.setString(3, clinico.getApellido2());
			ps.setString(4, sdf.format(clinico.getFecha_nacimiento()));
			ps.setInt(5, clinico.getTelefono());
			ps.setString(6, clinico.getCredencial().getEmail());			
			ps.setString(7, CredencialUsuario.encodePassword(clinico.getCredencial().getContrasena()));

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();
			System.out.println("HECHO");

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	public void modificarPaciente(Paciente paciente){		
		try {
			//Sumo el valor que me han dado a la nueva receta
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.

			sql = "UPDATE usuario SET nombre=?, apellido1=?, apellido2=?, fecha_nacimiento=?,"
					+ "telefono=?, email=?, contrasena=? WHERE usuario_dni='" + paciente.getCredencial().getUsuario_dni() + "'";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setString(1, paciente.getNombre());
			ps.setString(2, paciente.getApellido1());
			ps.setString(3, paciente.getApellido2());
			ps.setString(4, sdf.format(paciente.getFecha_nacimiento()));
			ps.setInt(5, paciente.getTelefono());
			ps.setString(6, paciente.getCredencial().getEmail());			
			ps.setString(7, CredencialUsuario.encodePassword(paciente.getCredencial().getContrasena()));

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//Metemos la agenda de medicamentos
		//insertarAgendaMedicamento(dniPaciente, receta);
	}

	public void modificarPacientePesoYAltura(double peso, int altura, String dniPaciente){		
		try {
			//Sumo el valor que me han dado a la nueva receta
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.

			sql = "UPDATE paciente "
					+ "SET peso = ?, altura=? "
					+ "WHERE (dni_paciente) = '"+dniPaciente+"'";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setDouble(1, peso);
			ps.setInt(2, altura);

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//Metemos la agenda de medicamentos
		//insertarAgendaMedicamento(dniPaciente, receta);
	}

	public void ModificarCuidador(Cuidador cuidador){		
		try {
			//Sumo el valor que me han dado a la nueva receta
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.

			sql = "UPDATE usuario SET nombre=?, apellido1=?, apellido2=?, fecha_nacimiento=?,"
					+ "telefono=?, email=?, contrasena=? WHERE usuario_dni='" + cuidador.getCredencial().getUsuario_dni() + "'";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setString(1, cuidador.getNombre());
			ps.setString(2, cuidador.getApellido1());
			ps.setString(3, cuidador.getApellido2());
			ps.setString(4, sdf.format(cuidador.getFecha_nacimiento()));
			ps.setInt(5, cuidador.getTelefono());
			ps.setString(6, cuidador.getCredencial().getEmail());			
			ps.setString(7, CredencialUsuario.encodePassword(cuidador.getCredencial().getContrasena()));

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//Metemos la agenda de medicamentos
		//insertarAgendaMedicamento(dniPaciente, receta);
	}

	public void ModificarCallCenter(Callcenter callcenter){		
		try {
			//Sumo el valor que me han dado a la nueva receta
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.

			sql = "UPDATE usuario SET nombre=?, apellido1=?, apellido2=?,"
					+ "email=?, contrasena=? WHERE usuario_dni='" + callcenter.getCredencial().getUsuario_dni() + "'";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setString(1, callcenter.getNombre());
			ps.setString(2, callcenter.getApellido1());
			ps.setString(3, callcenter.getApellido2());
			ps.setString(4, callcenter.getCredencial().getEmail());			
			ps.setString(5, CredencialUsuario.encodePassword(callcenter.getCredencial().getContrasena()));

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//Metemos la agenda de medicamentos
		//insertarAgendaMedicamento(dniPaciente, receta);
	}

	public Vector<Receta> ModificarReceta(String dniPaciente, String columnaAModificarMAYUS, Object datoNuevo, int NReceta){
		/* Datos:
		 * Nombre
		 * Descripcion
		 * stock
		 * unidadesxtoma
		 * frecuencia (solo si es mayor a la actual)
		 * NO: fecha, tipodosis
		 */

		//1. Consultar las recetas  y conseguir la key de la Nreceta
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			if(columnaAModificarMAYUS.equals("NOMBRE")) {

				String nombre = datoNuevo.toString();

				sql = "WITH user_recetas (rownumber, id_receta, nombre)"
						+"	AS ( SELECT "
						+"	    ROW_NUMBER() OVER (ORDER BY receta.id_receta ASC) AS rownumber, id_receta, nombre"
						+"	    FROM receta)"
						+"	UPDATE receta"
						+"	SET nombre = '" + nombre + "'"
						+"	WHERE user_recetas.rownumber='" + NReceta + "' AND receta.id_receta = user_recetas.id_receta ;";


			} else if(columnaAModificarMAYUS.equals("DESCRIPCION")) {

				String descripcion = datoNuevo.toString();

				sql = "WITH user_recetas (rownumber, id_receta, nombre)"
						+"	AS ( SELECT "
						+"	    ROW_NUMBER() OVER (ORDER BY receta.id_receta ASC) AS rownumber, id_receta, nombre"
						+"	    FROM receta)"
						+"	UPDATE receta"
						+"	SET descripcion = '" + descripcion + "'"
						+"	WHERE user_recetas.rownumber='" + NReceta + "' AND receta.id_receta = user_recetas.id_receta ;";

			} else if(columnaAModificarMAYUS.equals("STOCK")) {

				int stock = (Integer) datoNuevo;

				sql = "WITH user_recetas (rownumber, id_receta, nombre)"
						+"	AS ( SELECT "
						+"	    ROW_NUMBER() OVER (ORDER BY receta.id_receta ASC) AS rownumber, id_receta, nombre"
						+"	    FROM receta)"
						+"	UPDATE receta"
						+"	SET stock = '" + stock + "'"
						+"	WHERE user_recetas.rownumber='" + NReceta + "' AND receta.id_receta = user_recetas.id_receta ;";


			} else if(columnaAModificarMAYUS.equals("UNIDADES_POR_TOMA")) {

				int unidadesxtoma = (Integer) datoNuevo;

				sql = "WITH user_recetas (rownumber, id_receta, nombre)"
						+"	AS ( SELECT "
						+"	    ROW_NUMBER() OVER (ORDER BY receta.id_receta ASC) AS rownumber, id_receta, nombre"
						+"	    FROM receta)"
						+"	UPDATE receta"
						+"	SET stock = '" + unidadesxtoma + "'"
						+"	WHERE user_recetas.rownumber='" + NReceta + "' AND receta.id_receta = user_recetas.id_receta ;";


			} else if(columnaAModificarMAYUS.equals("FRECUENCIA")) {

				int stock = (Integer) datoNuevo;


				sql = "WITH user_recetas (rownumber, id_receta, nombre)"
						+"	AS ( SELECT "
						+"	    ROW_NUMBER() OVER (ORDER BY receta.id_receta ASC) AS rownumber, id_receta, nombre"
						+"	    FROM receta)"
						+"	UPDATE receta"
						+"	SET stock = '" + stock + "'"
						+"	WHERE user_recetas.rownumber='" + NReceta + "' AND receta.id_receta = user_recetas.id_receta ;";


			} 

			stmt = conn.createStatement();

			//STEP 4: Insertando un valor.*/
			stmt.executeUpdate(sql);  
			stmt.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
		return null;
	}

	/*
	 * Se elimina el clinico asociado de un paciente.
	 * Solo necesitamos pasarle el DNI del paciente que queremos borrar su cl�nico asociado.
	 */
	public void borrarClinicoDePaciente(String paciente) {

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");
			//STEP 3: Preparar la sentencia sql.
			sql = "Update paciente set dni_clinico= NULL where dni_paciente=? ";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar

			//Se rellena los values del sql 
			ps.setString(1, paciente);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}


	public void borrarRelacionPacienteCuidador(String cuidador, String paciente) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "DELETE FROM tiene where dni_paciente=? and dni_cuidador=?";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar

			//Se rellena los values del sql 
			ps.setString(1, paciente);
			ps.setString(2, cuidador);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
	}

	public void borrarRelacionPacienteCuidador(String paciente) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "DELETE FROM tiene where dni_paciente=?";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar

			//Se rellena los values del sql 
			ps.setString(1, paciente);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
	}

	public void borrarRelacionPacienteCuidador_solo_con_DNI_Cuidador(String cuidador) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "DELETE FROM tiene where dni_cuidador=?";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar

			//Se rellena los values del sql 
			ps.setString(1, cuidador);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
	}

	/**
	 * Se elimina el cl�nico de todos los pacientes que lo tienen asociado
	 * @param clinco
	 */
	public void bajaClinico(String clinico) {

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");
			//STEP 3: Preparar la sentencia sql.
			sql = "Update paciente set dni_clinico= NULL where dni_clinico=? ";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar

			//Se rellena los values del sql 
			ps.setString(1, clinico);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	public void insertarFechaBaja(String usuario) {

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");
			//STEP 3: Preparar la sentencia sql.
			sql = "Update usuario set fecha_baja = UTC_TIMESTAMP() where usuario_dni=? ";
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP3.1: Preparando los datos a insertar

			//Se rellena los values del sql 
			ps.setString(1, usuario);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	//Crear un nuevo ticket en la BBDD
	public void insertarTicket(Ticket ticket) {//funciona
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "Insert into ticket(asunto)"+"values(?)";
			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setString(1, ticket.getAsunto());

			String dniDestinatario = "";
			if (ticket.getListaMensajes().get(0).getAutor().equals(ticket.getCredencialA())) {
				dniDestinatario=ticket.getCredencialB();
			}else {
				dniDestinatario=ticket.getCredencialA();
			}

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 5: Cerrando conexion.
			conn.close();

			//Ahora insertamos el primer mensaje
			insertarMensaje(ticket.getListaMensajes().get(0), obtenerIDTicketAPartirAsunto(ticket.getAsunto()), dniDestinatario);

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("El ticket ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	public int obtenerIDTicketAPartirAsunto(String asunto) {//funciona
		int idTicket = 0;
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM ticket WHERE asunto='"+asunto+"'";
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while ( rs.next() ) {
				idTicket= rs.getInt("id_ticket");
				System.out.println("ID DEL TICKET "+idTicket);
			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {

		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try


		return idTicket;
	}

	public void insertarMensaje(Mensaje mensaje, int idTicket, String dniDestinatario) {//funciona
		System.out.println("----DNI DEL DESTINATARIO: "+dniDestinatario);
		System.out.println("----ID TICKET: "+idTicket);
		System.out.println("----CONTENIDO MENSAJE: "+mensaje.getContenido());
		System.out.println("----AUTOR MENSAJE: "+mensaje.getAutor());
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "INSERT INTO mensaje(id_ticket, remitente, destinatario, contenido, indicadorLectura)"
					+ "VALUES(?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);

			//Se rellena los values del sql 
			ps.setInt(1, idTicket);
			ps.setString(2, mensaje.getAutor());
			ps.setString(3, dniDestinatario);
			ps.setString(4, mensaje.getContenido());
			ps.setInt(5, 0);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();
			System.out.println("SE HA INSERTADO EL MENSAJE DEL PRIEMER TICKET!!!");

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("El mensaje ya existe\n");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	public Vector<Ticket> consultarTickets(String dniUsuario) {
		Vector<Ticket> listaTickets = new Vector<Ticket>();

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT mensaje.*, t.asunto, u.rol FROM mensaje "
					+ "JOIN ticket t on mensaje.id_ticket = t.id_ticket "
					+ "JOIN usuario u on mensaje.remitente = u.usuario_dni "
					+ " WHERE (remitente='"+dniUsuario+"' OR destinatario='"+dniUsuario+"') AND u.fecha_baja IS null";
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				int idMensaje = rs.getInt("id_mensaje");
				int idTicket = rs.getInt("id_ticket");
				String asunto = rs.getString("asunto");

				//Construimos con esto el mensaje
				String remitente = rs.getString("remitente");
				String destinatario = rs.getString("destinatario");
				String contenido = rs.getString("contenido");//
				Date fecha = rs.getDate("fecha");
				int lectura = rs.getInt("indicadorLectura");
				boolean read=false;

				//Procesamos la lectura para convertirlo en boolean
				if(lectura==1) {
					read=true;
				}


				//Creamos el objeto mensaje
				Mensaje mensaje = new Mensaje(contenido, fecha, remitente, read, idMensaje);
				//Tenemos que incorporar estos mensajes a la lista tickets, por lo tanto:
				//Comprobamos si todavia no se ha creado ningun ticket
				if(listaTickets.size()==0) {
					//Creamos el ticket y le metemos el mensaje que leemos
					Ticket ticket = new Ticket(asunto, mensaje, fecha, remitente, destinatario);
					ticket.setId_ticket(idTicket);
					//Si el remitente es un Call Center, seguro se trata de una emergencia y lo tratamos como tal
					if(rs.getInt("rol")==3) {
						String dniPaciente = asunto.substring(13);
						String[] coordenadas= contenido.substring(37).split(",");
						try {
							Location location = new Location(Double.parseDouble(coordenadas[0]), Double.parseDouble(coordenadas[1]), fecha);
							EmergenciaChat emergencia = new EmergenciaChat(location, dniPaciente);
							ticket.setEmergenciaChat(emergencia);

						} catch (Exception e) {
							System.out.println("No son coordenadas validas");
						}

					}
					ticket.setIndicadorLectura(false);
					listaTickets.add(ticket);
					//System.out.println("Se ha insertado en el primer ticket");
				}else {
					boolean insertado=false; //suponemos de primeras que el mensaje no se ha insertado aun en ningun ticket
					//Quiere decir que ya hay algun ticket creado, por eso recorremos la lista de tickets
					int i=0;
					while(insertado==false && i<listaTickets.size()) {
						if(listaTickets.get(i).getAsunto().equals(asunto) && listaTickets.get(i).getId_ticket()==idTicket) {
							//Quiere decir que el mensaje pertenece a este ticket
							listaTickets.get(i).aniadirMensaje(mensaje);
							//System.out.println("Se ha insertado en un ticket ya creado ");
							insertado=true;
						}
						i++;
					}

					if(insertado==false) {
						//Quiere decir que no se ha insertado en ningun mensaje, por lo que aun no hemos creado su ticket
						Ticket ticket = new Ticket(asunto, mensaje, fecha, remitente, destinatario);

						ticket.setId_ticket(idTicket);
						//Si el remitente es un Call Center, seguro se trata de una emergencia y lo tratamos como tal
						if(rs.getInt("rol")==3) {
							String dniPaciente = asunto.substring(13);
							String[] coordenadas= contenido.substring(37).split(",");
							try {
								Location location = new Location(Double.parseDouble(coordenadas[0]), Double.parseDouble(coordenadas[1]), fecha);
								EmergenciaChat emergencia = new EmergenciaChat(location, dniPaciente);
								ticket.setEmergenciaChat(emergencia);

							} catch (Exception e) {
								System.out.println("No son coordenadas validas");
							}

						}
						ticket.setIndicadorLectura(false);
						listaTickets.add(ticket);
						//System.out.println("Se ha insertado en un ticket que no existia");
					}
				}

			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//STEP 6: Devolver el array con la respuesta
		return listaTickets;

	}

	public boolean comprobarNoExisteAsuntoIgualTicket(String asunto) {//funciona
		//Con este metodo lo que evitamos es que se creen tickets con el mismo asunto
		boolean existe=false;

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM ticket";
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while ( rs.next() ) {
				String asunto1= rs.getString("asunto");
				if(asunto1.equals(asunto)) {
					existe=true;
				}
			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return existe;
	}

	public String devolverClinicoAsociadoAPaciente(String dniPaciente) {//funciona
		//Con este metodo lo que evitamos es que se creen tickets con el mismo asunto
		String dniClinico="";

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM paciente WHERE dni_paciente='"+dniPaciente+"'";
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while ( rs.next() ) {
				dniClinico= rs.getString("dni_clinico");
			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return dniClinico;
	}

	public Paciente ObtenerPesoYAlturaPaciente(Paciente pac) {
		Paciente paciente =pac;

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM paciente WHERE dni_paciente='"+pac.getCredencial().getUsuario_dni()+"'";
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				double peso = rs.getDouble("peso");
				int altura = rs.getInt("altura");
				//Se lo aniadimos al paciente
				paciente.setPeso(peso);
				paciente.setAltura(altura);
			}
			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		//STEP 6: Devolver el array con la respuesta
		return paciente;

	}
	public void BorrarReceta (String dniPaciente, Receta receta) {
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//Lo primero que tengo que hacer es coger el id de la receta para primero eliminar la agenda de medicamentos. 
			sql= "SELECT * FROM receta WHERE nombre=" + "'"+receta.getNombre()+"'" + "AND dni_paciente='" + dniPaciente + "'";
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql); 
			String id_receta= "";

			while ( rs.next() ) {
				id_receta= rs.getString("id_receta");
			}

			rs.close();
			stmt.close();

			//STEP 5: Cerrando conexion.
			//conn.close();			

			//STEP 6: Preparo la siguiente sentencia SQL en la que elimino la receta de la agenda:
			sql = "DELETE FROM agendamedicamento where id_receta='"+ id_receta + "'";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.executeUpdate();
			ps.close();

			//STEP 7: Cerrando conexion.
			//conn.close();

			//STEP 8: Elimino la receta de la tabla receta:
			sql = "DELETE FROM receta where id_receta='"+ id_receta + "'";
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
			ps.close();

			//STEP 7: Cerrando conexion.
			conn.close();


		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try
	}

	public void modificarIndicadorLecturaMensaje(int id_mensaje){		

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");	

			//STEP 3: Preparar la sentencia sql
			sql = "UPDATE mensaje SET indicadorLectura=1 WHERE id_mensaje="+id_mensaje;
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();
			System.out.println("HECHO");

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Contrase�a ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	//En este se usa la ruta del archivo
	public void aniadirFotoPerfil (String dniPaciente) {
		try {

			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//Convertir img a blob
			String ruta = "src/ficheros/CarpetasUsuarios/"+dniPaciente+
					"/"+dniPaciente+".png";
			System.out.println(ruta);
			File file = new File(ruta);
			FileInputStream imagen = new FileInputStream(file.getAbsolutePath());
			System.out.println("A�adimos foto");

			//STEP 3: Preparar la sentencia sql.
			sql = "UPDATE usuario SET foto_perfil=? WHERE usuario_dni='" + dniPaciente + "'";

			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setBlob(1, imagen);

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	//En este se usa la imagen como objeto
	public void actualizarFotoPerfil (String dniPaciente,  File imagen) {
		try {

			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//Convertir img a blob
			FileInputStream imagenBlob = new FileInputStream(imagen.getAbsolutePath());

			//STEP 3: Preparar la sentencia sql.
			sql = "UPDATE usuario SET foto_perfil=? WHERE usuario_dni='" + dniPaciente + "'";

			PreparedStatement ps = conn.prepareStatement(sql);

			ps.setBlob(1, imagenBlob);

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	public Image getFotoPerfil (String dniPaciente) {
		Image imagen =null;

		try {

			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT foto_perfil FROM usuario WHERE usuario_dni='" + dniPaciente + "'";
			stmt = conn.createStatement();

			//Convertir blob a img
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next()) {
				java.sql.Blob blob = rs.getBlob("foto_perfil");  
				if(blob!=null) {
					InputStream in = blob.getBinaryStream();  
					BufferedImage buffer = ImageIO.read(in);
					imagen = convertToFxImage(buffer);
				}
			}

			rs.close();
			stmt.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return imagen;
	}

	private static Image convertToFxImage (BufferedImage image) {
		WritableImage wr = null;
		if (image != null) {
			wr = new WritableImage(image.getWidth(), image.getHeight());
			PixelWriter pw = wr.getPixelWriter();
			for (int x = 0; x < image.getWidth(); x++) {
				for (int y = 0; y < image.getHeight(); y++) {
					pw.setArgb(x, y, image.getRGB(x, y));
				}
			}
		}

		return new ImageView(wr).getImage();
	}


	//Metodo para leer emergencias
	public Paciente getPacienteEmergencia(String DNIResponsable, int rol) {

		Paciente paciente = null;

		try {

			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			//1:cuidador, 2:clinico, 3:callcenter
			if (rol == 1) {
				sql = "SELECT u.*, p.dni_clinico, l.* " + 
						"FROM paciente p " + 
						"Join tiene t on p.dni_paciente = t.dni_paciente " + 
						"Join usuario u on t.dni_paciente = u.usuario_dni " + 
						"JOIN sensor s on p.dni_paciente = s.dni_paciente " + 
						"JOIN lecturasos l on s.id_sensor = l.id_sensor_SOS " + 
						"where t.dni_cuidador = '"+ DNIResponsable + "' and reporteCuidador = 0 " + 
						" and s.fecha_baja is null " + 
						"LIMIT 1";

			} else if (rol == 2) {
				sql = "SELECT u.*, p.dni_clinico, l.* FROM paciente p " + 
						"JOIN usuario u on p.dni_paciente = u.usuario_dni " + 
						"JOIN sensor s on p.dni_paciente = s.dni_paciente " + 
						"JOIN lecturasos l on s.id_sensor = l.id_sensor_SOS " + 
						"WHERE p.dni_clinico = '"+ DNIResponsable + "' and reporteClinico = 0 " + 
						" and s.fecha_baja is null " + 
						"LIMIT 1";

			} 
			else if (rol == 3) {
				sql = "SELECT u.*, p.dni_clinico, l.* " + 
						"FROM paciente p " + 
						"JOIN sensor s on p.dni_paciente = s.dni_paciente " + 
						"JOIN lecturasos l on s.id_sensor = l.id_sensor_SOS " + 
						"JOIN usuario u on u.usuario_dni = p.dni_paciente " + 
						"where reporteCallCenter = 0 and s.fecha_baja is null " + 
						"LIMIT 1";
			} 

			stmt = conn.createStatement();

			//Recuperar la emergencia
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				int id_lecturas = rs.getInt("id_lecturas");
				int id_sensor_SOS = rs.getInt("id_sensor_SOS");
				Date fecha = rs.getDate("fecha");
				int reporteClinico = rs.getInt("reporteClinico");
				int reporteCuidador = rs.getInt("reporteCuidador");
				int reporteCallCenter = rs.getInt("reporteCallCenter");
				Double latitud = rs.getDouble("latitud");
				Double longitud = rs.getDouble("longitud");

				//Transformar int a boolean
				Boolean r_clinico = reporteClinico==1 ? true:false;
				Boolean r_cuidador = reporteCuidador==1 ? true:false;
				Boolean r_callcenter = reporteCallCenter==1 ? true:false;

				Emergencia emergencia = new Emergencia();

				emergencia.setID(id_lecturas);
				emergencia.setReporte_clinico(r_clinico);
				emergencia.setReporte_cuidador(r_cuidador);
				emergencia.setReporte_callcenter(r_callcenter);
				emergencia.setCoordenadas(longitud, latitud);
				emergencia.setFecha(fecha);

				String dni = rs.getString("usuario_dni");
				Date fecha_baja = rs.getDate("fecha_baja");
				String  nombre = rs.getString("nombre");
				String  apellido1 = rs.getString("apellido1");
				String  apellido2 = rs.getString("apellido2");
				Date nacimiento = rs.getDate("fecha_nacimiento");
				int paciente_rol = rs.getInt("rol");
				String email = rs.getString("email");
				int sexo = rs.getInt("sexo");
				int telefono = rs.getInt("telefono");
				String contrasena = rs.getString("contrasena");
				String clinico = rs.getString("dni_clinico");

				//Convertir los datos para los constructores
				Boolean alta = (fecha_baja==null) ? true:false;
				Boolean sex = sexo==1 ? true:false;

				//Crear la credencial y el paciente
				CredencialUsuario credencial = new CredencialUsuario(paciente_rol, dni, email, contrasena, alta);
				paciente = new Paciente(nombre, apellido1, apellido2, credencial, nacimiento, telefono, sex);
				paciente.setClinico(clinico);
				paciente.setEmergencia(emergencia);

				//Recuperar las recetas y anadirlas al paciente
				Vector <Receta> recetas = getRecetas(credencial.getUsuario_dni());

				for (int i=0; i<recetas.size();i++) {
					paciente.addMedicina(recetas.get(i));
				}


			}

			rs.close();
			stmt.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Agenda ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return paciente;
	}

	//Metodo para actualizar el estado del reporte de las emergencias
	public void actualizarReporteEmergencia(int ID_Lectura, int rol) {

		try {

			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			//1:cuidador, 2:clinico, 3:callcenter
			if (rol == 1) {
				sql = "UPDATE lecturasos SET reporteCuidador=1 WHERE id_lecturas = " + ID_Lectura;
			} else if (rol == 2) {
				sql = "UPDATE lecturasos SET reporteClinico=1 WHERE id_lecturas = " + ID_Lectura;
			} else if (rol == 3) {
				sql = "UPDATE lecturasos SET reporteCallCenter=1 WHERE id_lecturas = " + ID_Lectura;
			}

			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP 4: Insertando un valor.*/
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			e.printStackTrace();
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

	}

	public void enviarChatEmergencia(EmergenciaChat emergencia, String DNICallCenter) {

		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance?allowMultiQueries=true", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql para recoger los cuidadores asociados.
			sql = "SELECT u.usuario_dni " + 
					"FROM paciente " + 
					"JOIN tiene t on paciente.dni_paciente = t.dni_paciente " + 
					"JOIN usuario u on t.dni_cuidador = u.usuario_dni " + 
					"WHERE t.dni_paciente='"+ emergencia.getDniPaciente()+"';";

			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			Vector <String> dniCuidadores = new Vector<String>();
			while ( rs.next() ) {
				dniCuidadores.add(rs.getString("usuario_dni"));
			}

			sql="";
			//Hacer un for para hacer tantas inserciones de mensajes como Cuidadores haya
			//SU SE CAMBIA ESTO, FALLA EL METODO DE CONSULTA DE MENSAJES DE EMERGENCIAS
			for (int i=0; i<dniCuidadores.size();i++) {
				sql = sql + "SET @TheID = (SELECT id_ticket FROM ticket ORDER BY id_ticket DESC LIMIT 1) +1;\n" +
						"INSERT INTO ticket(id_ticket, asunto) VALUES (@TheID , 'Emergencia - "+ emergencia.getDniPaciente()+"');\n" +
						"INSERT INTO mensaje (id_ticket, remitente, destinatario, contenido, indicadorLectura) " + 
						"VALUES (@TheID , '"+ DNICallCenter +"', '"+dniCuidadores.get(i)+"', 'Emergencia del paciente "
						+ emergencia.getDniPaciente()+ " en " + emergencia.getLocalizacion().getLatitud() + 
						" , "+ emergencia.getLocalizacion().getLongitud() + "', 0); \n";

			}

			sql = sql + "UPDATE lecturasos SET reporteCallCenter=1 WHERE id_lecturas = " + emergencia.getID();
			System.out.println(sql);
			PreparedStatement ps = conn.prepareStatement(sql);

			//STEP 4: Insertando un valor.
			ps.executeUpdate();
			ps.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("DATA DUPLICADA");
		}catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try


	}

	public String devolverLecturaPastillero(String dni){		
		//Inicializamos la variable
		String valor="";
		try {
			//CONEXION
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://2.139.176.212/prbcassistance", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 3: Preparar la sentencia sql.
			sql = "SELECT * FROM lecturapastillero join sensor on id_sensor_pastillero=sensor.id_sensor \n"
					+ "WHERE sensor.dni_paciente='"+dni+"' AND fecha >= now() - interval 2 HOUR - interval 5 minute ORDER BY fecha DESC LIMIT 1" ;
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				//Recogemos el string
				valor=rs.getString("valor");

			}
			rs.close();
			stmt.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("Paciente ya existe");
		}catch (SQLException se) {
			//Handle errors for JDBC
			System.out.println("Error");
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			System.out.println("Error");
			e.printStackTrace();
		} finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		return valor;

	}

}


