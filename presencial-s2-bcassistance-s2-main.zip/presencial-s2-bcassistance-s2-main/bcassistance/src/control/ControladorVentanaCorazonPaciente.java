package control;

import java.io.IOException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import model.CredencialUsuario;
import model.Paciente;


public class ControladorVentanaCorazonPaciente {

	@FXML
	private Label tituloPacientes;

	@FXML
	private Label DescripcionApartado;

	@FXML
	private Label LabelFrecuenciaActual;

	@FXML
	private Label LabelVariabilidad;

	@FXML
	private Label LabelFrecuenciaReposo;

	@FXML
	private GridPane gridPane;

	@FXML
	private BarChart<String, Integer> barChart;

	@FXML
	private CategoryAxis xAxis;

	private ObservableList<String> diasSemana = FXCollections.observableArrayList();

	Vector<Paciente> listaPacientes=new Vector<>();

	Paciente paciente;

	CredencialUsuario UsuarioLogueado;

	static String language;

	//GETTERS  Y SETTERS
	public CredencialUsuario getUsuarioLogueado() {
		return UsuarioLogueado;
	}
	public void setUsuarioLogueado(CredencialUsuario usuarioLogueado) {
		UsuarioLogueado = usuarioLogueado;
	}

	@FXML    
	void initialize() {
		//MyThread myThread = new MyThread();
		//myThread.start();	
		cambiarLabels();
		rellenarTabla();


		/*
		Vector<Paciente> miVector=new Vector<Paciente>();
		ControladorFicherosJson c=new ControladorFicherosJson();
		miVector=c.deserializarJsonPacientesAArray();
		ResumenECG res=new ResumenECG();
		Vector<ActividadCardiaca> ActividaDias= new Vector<>();
		for(int i=0; i<=6;i++) {
			ActividadCardiaca act=new ActividadCardiaca();
			act.setMediaPulsaciones(i+2);
			ActividaDias.add(act);
		}

		res.setActividaDias(ActividaDias);
		miVector.elementAt(3).setResumenECG(res);
		c.serializarArrayPacientesAJson(miVector);
		 */

		//RecogerDatosYRellenar();

	}
	void cambiarLabels() {
		identificarPaciente();

		//CredencialUsuario user=new CredencialUsuario(1, "92204233Q","Mail", "123456789");///////
		//UsuarioLogueado=user;/////////)

		//tituloPacientes.setText("Coraz�n");
		//DescripcionApartado.setText("Vigila tus constantes vitales");
		//LabelFrecuenciaActual.setText(Integer.toString(paciente.getResumenECG().getPulsacionesActuales()));
		//LabelFrecuenciaReposo.setText(Integer.toString(paciente.getResumenECG().getLatenciaReposo()));
		//LabelVariabilidad.setText(Integer.toString(paciente.getResumenECG().getLatencia()));
		//CrearGrafica();
		System.out.println("Labels actualizados");
	}

	void rellenarTabla() {
		System.out.println("hola");
		String[] dias = new String[7];
		// Get an array with the English month names.
		if (language.equals("es_ES")) {
			dias[0]="Domingo"; dias[1]="Lunes"; dias[2]="Martes";
			dias[3]="Miercoles"; dias[4]="Jueves"; dias[5]="Viernes"; dias[6]="Sabado";
		} else {
			dias[0]="Sunday"; dias[1]="Monday"; dias[2]="Tuesday";
			dias[3]="Wednesday"; dias[4]="Thursday"; dias[5]="Friday"; dias[6]="Saturday";
		}
		// Convert it to a list and add it to our ObservableList of months.
		diasSemana.addAll(Arrays.asList(dias));

		// Assign the month names as categories for the horizontal axis.
		xAxis.setCategories(diasSemana);



		int[] monthCounter = new int[7];

		int posicionActual=identificarPosicionArrayDias(dias);

		XYChart.Series<String, Integer> series = new XYChart.Series<>();

		// Create a XYChart.Data object for each month. Add it to the series.
		int recorrerVectorAlReves=0;
		for (int i = posicionActual; i >= 0; i--) {
			monthCounter[i]=i+2;

			//int valorBarra=paciente.getResumenECG().getActividaDias().elementAt(paciente.getResumenECG().getActividaDias().size()-1-recorrerVectorAlReves).getMediaPulsaciones();

			///series.getData().add(new XYChart.Data<>(dias[i],valorBarra));	//ESTO ES EL VALOR DE CADA COLUMNA
			recorrerVectorAlReves++;
		}

		barChart.getData().add(series); 
	}

	String recogerDiaActual() {
		String[] nombreDias=new String[7];
		Date hoy=new Date();
		int numeroDia;
		Calendar cal= Calendar.getInstance();
		cal.setTime(hoy);
		numeroDia=cal.get(Calendar.DAY_OF_WEEK);
		if (language.equals("es_ES")) {
			nombreDias[0]="Domingo"; nombreDias[1]="Lunes"; nombreDias[2]="Martes";
			nombreDias[3]="Miercoles"; nombreDias[4]="Jueves"; nombreDias[5]="Viernes"; nombreDias[6]="Sabado";
		} else {
			nombreDias[0]="Sunday"; nombreDias[1]="Monday"; nombreDias[2]="Tuesday";
			nombreDias[3]="Wednesday"; nombreDias[4]="Thursday"; nombreDias[5]="Friday"; nombreDias[6]="Saturday";
		}
		return nombreDias[numeroDia-1];// El dia de la semana inicia en el 1 mientras que el array empieza en el 0
	}

	int identificarPosicionArrayDias(String[] dias) {
		int position=0;
		String diaActual=recogerDiaActual();
		for(int i=0;i<dias.length;i++) {
			if(dias[i].equals(diaActual)) {
				position=i;
			}
		}
		return position;
	}

	void CrearGrafica(){

		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/GraficaCorazonPaciente.fxml"), bundle);
		//		ControladorVentanaRepresentacionPacienteFormatoCuadrado.UsuarioLogueado=UsuarioLogueado;
		ControladorGraficaCorazonPaciente controlador = new ControladorGraficaCorazonPaciente();
		//		controlador.setPanelInsertarApartado(panelInsertarApartado);
		//Le pasamos al controlador el paciente a representar
		//		controlador.setPacienteRepresentado(listadoPacientes.get(j));
		loader.setController(controlador);
		Parent root;
		try {
			root = loader.load();
			gridPane.add(root, 0, 0);//A�adimos el paciente al gridPane

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	void identificarPaciente() {


		//HAY QUE HACERLO CON LA BBDD

		/*ControladorFicherosJson c=new ControladorFicherosJson();
		listaPacientes=c.deserializarJsonPacientesAArray();

		int position = 1;
    	for(int nVectorPacientes=0;nVectorPacientes<=listaPacientes.size()-1;nVectorPacientes++){
    		if(listaPacientes.elementAt(nVectorPacientes).getCredencial().getUsuario_dni().equals(UsuarioLogueado.getUsuario_dni())) {
    			position=nVectorPacientes;
    		}   		
    	}
    	System.out.println("Identificado "+listaPacientes.elementAt(position).getCredencial().getEmail());
    	paciente=listaPacientes.elementAt(position);*/

	}

	public class MyThread extends Thread {

		public void run(){
			System.out.println("MyThread running");
			while(true) {
				try {
					Thread.sleep(1000);
					cambiarLabels();	//No funciona				
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}
}


