package control;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;
import model.Usuario;

public class ControladorCambiarContrasena {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="CodigoVerificacion"
	private JFXTextField CodigoVerificacion; // Value injected by FXMLLoader

	@FXML // fx:id="BotonAceptar"
	private JFXButton BotonAceptar; // Value injected by FXMLLoader

	@FXML // fx:id="contrasena"
	private JFXPasswordField contrasena; // Value injected by FXMLLoader

	@FXML // fx:id="contrasenaVerificar"
	private JFXPasswordField contrasenaVerificar; // Value injected by FXMLLoader

	@FXML // fx:id="CodigoContrasenaincorrecto"
	private Label CodigoContrasenaincorrecto; // Value injected by FXMLLoader
	

		
	@FXML
	void PulsarAceptar(ActionEvent event) {

		boolean acceso=false;
		int i=0;  
		//Creo un vector de cada usuario y de credencial usuario:
		Vector<Usuario> listaUsuarios = new Vector<Usuario>();
		ControladorBBDD controlador= new ControladorBBDD();
		listaUsuarios= controlador.devolverTodosUsuarios();
		
		//Paso la contrasena de String a Int para m�s tarde poder igualarla
		int codigo=Integer.parseInt(CodigoVerificacion.getText());

		//En primer lugar, el usuario mete el c�digo que se le ha mandado por email, y verificamos que sea correcto. Los igualo con == al ser int
		if (codigo==ControladorOlvidarContrasena.Codigoaleatorio) {
			
			//En caso de que ambas contrase�as coincidan:
			if (contrasena.getText().equals(contrasenaVerificar.getText())) {			
				
				while(i< listaUsuarios.size() && !acceso) {                                           //Bucle de la lista de usuarios
					
					//Busco el email de la persona que quiere cambiar su contrase�a y cuando lo encuentro entro en este if
					if (ControladorOlvidarContrasena.correo.equals(listaUsuarios.get(i).getCredencial().getEmail())){ 
						
						//Cuando lo encuentro pongo como contrase�a la puesta en el JPasswordField
						String contrasenaCodificada = contrasena.getText();
						listaUsuarios.get(i).getCredencial().setContrasena(contrasenaCodificada);    
						controlador.ModificarContrasena(listaUsuarios.get(i));
						
						//Volvemos a la p�gina del login
						try {
							Locale locale = new Locale(ControladorLogin.language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/GUI_Login.fxml"), bundle);
							ControladorLogin controladorLogin= new ControladorLogin();
							loader.setController(controladorLogin);
							Parent root= loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}						
						
					}  //Cierro el if de si el email es igual al del usuario en el que me encuento en ese momento
					i++;
				}      //Cierro el while
			}          //Cierro el if de la contrase�a

			//En caso de que las contrase�as no coincidan:
			else {
				if (ControladorLogin.language.contentEquals("es_ES")) {
					CodigoContrasenaincorrecto.setText( "Las contrase�as no coinciden. Pruebe de nuevo");
				} else {
					CodigoContrasenaincorrecto.setText( "Passwords do not match. Try again");
				}
				i=0;
			}
		}
		else {
			if (ControladorLogin.language.contentEquals("es_ES")) {
				CodigoContrasenaincorrecto.setText( "Codigo incorrecto. Pruebe de nuevo");
			} else {
				CodigoContrasenaincorrecto.setText( "Incorrect Code. Try again");
			}			
		}

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert CodigoVerificacion != null : "fx:id=\"CodigoVerificacion\" was not injected: check your FXML file 'CodigoVerificacion.fxml'.";
		assert BotonAceptar != null : "fx:id=\"BotonAceptar\" was not injected: check your FXML file 'CodigoVerificacion.fxml'.";
		assert contrasena != null : "fx:id=\"contrasena\" was not injected: check your FXML file 'CodigoVerificacion.fxml'.";
		assert contrasenaVerificar != null : "fx:id=\"contrasenaVerificar\" was not injected: check your FXML file 'CodigoVerificacion.fxml'.";
		assert CodigoContrasenaincorrecto != null : "fx:id=\"CodigoContrasenaincorrecto\" was not injected: check your FXML file 'CodigoVerificacion.fxml'.";

	}
}
