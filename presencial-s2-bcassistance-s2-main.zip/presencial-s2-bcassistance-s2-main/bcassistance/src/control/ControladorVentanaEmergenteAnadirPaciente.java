package control;

import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import com.jfoenix.controls.JFXTextField;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.*;

public class ControladorVentanaEmergenteAnadirPaciente {
	static CredencialUsuario UsuarioLogueado;

	static BorderPane panelInsertarApartado;

	@FXML
	private Button boton;

	@FXML
	private Text errorText;

	@FXML
	private JFXTextField DNITextArea;

	static String language;

	@FXML
	void botonPulsado(ActionEvent event) {
		
		//Cogemos el DNI a anadir
		String DNIPaciente = null;
		if(!DNITextArea.getText().trim().isEmpty()) {DNIPaciente= DNITextArea.getText();}
		System.out.println("Dni a anadir :"+DNIPaciente);
		
		ControladorBBDD c=new ControladorBBDD();
		//Si es cuidador
		if(c.devolverRol(UsuarioLogueado.getUsuario_dni())==1) {
			System.out.println(" -> Insertamos el paciente al cuidador");
			c.relacionarPacienteCuidador(UsuarioLogueado.getUsuario_dni(), DNIPaciente);	//Anadimos la relaci�n
		}
		//Si es m�dico
		else {
			System.out.println(" ->Insertamos el clinico al pacienter");
			c.relacionarPacienteClinico(UsuarioLogueado.getUsuario_dni(), DNIPaciente);
		}
		
		recargarVentana(event);//Recargamos la ventana para que aparezca el usuario a�adido y cerramos la ventana emergente
		
		
	}
	
	//FUNCI�N ORIGINAL JSON
	/*
	@FXML
	void botonPulsado(ActionEvent event) {
		//Cogemos el DNI
		String DNI = null;
		if(!DNITextArea.getText().trim().isEmpty()) {DNI= DNITextArea.getText();}
		System.out.println(DNI);

		//Declaramos el controladorJson
		ControladorFicherosJson controladorJson=new ControladorFicherosJson();

		//Leemos el vector cl�nicos
		Vector<Clinico> listaClinicos=new Vector<Clinico>();
		listaClinicos = controladorJson.deserializarJsonClinicosAArray();

		//Leemos el vector Pacientes
		Vector<Paciente> listaPacientes=new Vector<Paciente>();
		listaPacientes = controladorJson.deserializarJsonPacientesAArray();

		//Leemos el vector de Cuidadores
		Vector<Cuidador> listaCuidadores=new Vector<Cuidador>();
		listaCuidadores = controladorJson.deserializarJsonCuidadoresAArray();

		int posicionClinico=buscarEnClinicos(listaClinicos);

		int posicionCuidador = buscarEnCuidador(listaCuidadores);

		int posicionPaciente=buscarEnPacientes(listaPacientes,DNI);


		//AQU� SE A�ADE EL DNI AL CL�NICO, TODO LO DEM�S SE PODR� BORRAR
		if(posicionPaciente!=-1 && posicionClinico!=-1 ) {	//Es un cl�nico y el paciente existe
			System.out.println("El clinico es "+listaClinicos.elementAt(posicionClinico).getNombre());
			if(!listaPacientes.get(posicionPaciente).getCredencial().isAlta()) {
				System.out.println("Paciente dado de baja");
				if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("Paciente dado de baja");}
				else {errorText.setText("This patient is discharged");}
			}			
			else if(comprobarClinicoAsociadoDNIPaciente(listaClinicos.elementAt(posicionClinico), DNI)) {
				System.out.println("Este clinico ya tiene asociado ese paciente");
				if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("Usted ya tiene anadido ese paciente");}
				else {errorText.setText("You already have added this patient");}
			} 
			else if(!comprobarClinicosdelPaciente(listaPacientes.get(posicionPaciente))) {
				System.out.println("Este paciente ya tiene un cl�nico asociado");
				if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("Este paciente ya tiene cl�nico asociado");}
				else {errorText.setText("This patient already has a clinic associated");}
			}
			else { 
				listaClinicos.elementAt(posicionClinico).addPaciente(DNI);   	//A�adimos el paciente
				controladorJson.serializarArrayClinicosAJson(listaClinicos); 	//Guardamos el json

				listaPacientes.elementAt(posicionPaciente).setClinico(UsuarioLogueado.getUsuario_dni());
				controladorJson.serializarArrayPacientesAJson(listaPacientes); 	//Guardamos el json
				recargarVentana(event);
			}

		}
		else if (posicionPaciente!=-1 && posicionCuidador!=-1) {	//Es un cuidador y el paciente existe
			if(!listaPacientes.get(posicionPaciente).getCredencial().isAlta()) {
				System.out.println("Paciente dado de baja");
				if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("Paciente dado de baja");}
				else {errorText.setText("This patient is discharged");}
			}
			else if(comprobarCuidadorAsociadoDNIPaciente(listaCuidadores.elementAt(posicionCuidador), DNI)) {
				System.out.println("Este cuidador ya tiene asociado ese paciente");
				if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("Usted ya tiene anadido ese paciente");}
				else {errorText.setText("You already have added this patient");}
			}
			else {
				listaCuidadores.elementAt(posicionCuidador).addPaciente(DNI);   	//A�adimos el paciente
				controladorJson.serializarArrayCuidadoresAJson(listaCuidadores); 	//Guardamos el json

				listaPacientes.elementAt(posicionPaciente).getCuidadores().add(UsuarioLogueado.getUsuario_dni());
				controladorJson.serializarArrayPacientesAJson(listaPacientes); 	//Guardamos el json

				recargarVentana(event);
			}

		}
		else {
			System.out.println("ERROR");
			if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("El DNI que ha introducido no ha arrojado ningun resultado");}
			else {errorText.setText("The DNI you have introduced has not thrown any results");}
		}

		//TODO LO DE AQU� ABAJO SIRVE PARA A�ADIR EL PACIENTE COMPLETO, PERO AHORA YA NO LO USAREMOS


		/*

    	//Significa que es un cl�nico
    	if(posicionPaciente!=-1 && posicionClinico!=-1) {
    		//PRIMERO COMPROBAMOS QUE LO TENGA
    		if(comprobarClinicoAsociadoPaciente(listaClinicos.elementAt(posicionClinico), DNI)) {
    			System.out.println("Este clinico ya tiene asociado ese paciente");
    			if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("Usted ya tiene a�adido ese paciente");}
    	    	else {errorText.setText("You already have added this patient");}

    		}
    		else {
    		listaClinicos.elementAt(posicionClinico).addPaciente(listaPacientes.elementAt(posicionPaciente));
    		//Ahora actualizamos el JSON
    		controladorJson.serializarArrayClinicosAJson(listaClinicos);
    		System.out.println("JSON cl�nicos actualizada");
    		}

    	}
    	//Significa que es un cuidador
    	else if (posicionPaciente!=-1 && posicionCuidador!=-1) {
    		//PRIMERO COMPROBAMOS QUE LO TENGA 
    		if(comprobarCuidadorAsociadoPaciente(listaCuidadores.elementAt(posicionClinico), DNI)) {
    			System.out.println("Este cuidador ya tiene asociado ese paciente");
    			if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("Usted ya tiene a�adido ese paciente");}
    	    	else {errorText.setText("You already have added this patient");}
    		}
    		listaCuidadores.elementAt(posicionCuidador).addPaciente(listaPacientes.elementAt(posicionPaciente));
    		//Ahora actualizamos el JSON
    		controladorJson.serializarArrayCuidadoresAJson(listaCuidadores);
    		System.out.println("JSON cuidadores actualizada");
    	}
    	//ERROR
    	else {
    		System.out.println("ERROR");
    		if (ControladorLogin.language.contentEquals("es_ES")) {errorText.setText("El DNI que ha introducido no ha arrojado ning�n resultado");}
	    	else {errorText.setText("The DNI you have introduced has not thrown any results");}

    	}
		 
		System.out.println("Si hemos llegado a aqui es que todo va bien");

	}*/

	//FUNCIONES

	void recargarVentana(ActionEvent event) {
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaListadoPacientes.fxml"), bundle);
		ControladorVentanaListadoPacientes c = new ControladorVentanaListadoPacientes();
		ControladorVentanaListadoPacientes.UsuarioLogueado=UsuarioLogueado;
		ControladorVentanaListadoPacientes.language=language;
		ControladorVentanaListadoPacientes.panelInsertarApartado= panelInsertarApartado;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			//panelactual = "Pacientes";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Cerramos esta ventana emergente
		//Obtenemos la ventana sin dependencias y la cerramos
		Node n= (Node) event.getSource();
		Stage stage = (Stage) n.getScene().getWindow();
		stage.close();
	}
	
	//Buscamos en el vector de cl�nicos la posici�n
	int buscarEnClinicos(Vector<Clinico> listaClinicos) {
		int position = -1;
		for(int nVectorClinicos=0; nVectorClinicos<=listaClinicos.size()-1;nVectorClinicos++) {
			if(listaClinicos.elementAt(nVectorClinicos).getCredencial().getUsuario_dni().equals(UsuarioLogueado.getUsuario_dni())) {
				System.out.println("Posicion "+nVectorClinicos);
				position=nVectorClinicos;
			}
		}

		if(position!=-1) System.out.println("El clinico tiene DNI: "+ listaClinicos.elementAt(position).getCredencial().getUsuario_dni());

		//Si no se ecuentra la posici�n devuelve -1
		return position;
	}

	//Buscamos en el vector de Pacientes la posici�n
	int buscarEnCuidador(Vector<Cuidador> listaCuidadores) {
		int position = -1;
		for(int nVectorCuidadores=0;nVectorCuidadores<=listaCuidadores.size()-1; nVectorCuidadores++) {
			if(listaCuidadores.elementAt(nVectorCuidadores).getCredencial().getUsuario_dni().equals(UsuarioLogueado.getUsuario_dni())) {
				position=nVectorCuidadores;
			}
		}
		if(position!=-1) System.out.println("El Cuidador tiene DNI: "+ listaCuidadores.elementAt(position).getCredencial().getUsuario_dni());
		else System.out.println("No se trata de un cuidador");
		//Si no se ecuentra la posici�n devuelve -1
		return position;
	}

	//Buscamos en el vector de Pacientes la posici�n
	int buscarEnPacientes(Vector<Paciente> listaPacientes, String DNI) {
		int position = -1;
		for(int nVectorPacientes=0;nVectorPacientes<=listaPacientes.size()-1;nVectorPacientes++){
			if(listaPacientes.elementAt(nVectorPacientes).getCredencial().getUsuario_dni().equals(DNI)) {
				position=nVectorPacientes;
			}   		
		}
		if(position!=-1)System.out.println("El paciente tiene DNI: "+ listaPacientes.elementAt(position).getCredencial().getUsuario_dni());
		//Si no se ecuentra la posici�n devuelve -1
		return position;
	}

	//Esta funcion nos devuelve si el clinico tiene asociado ya ese paciente
	boolean comprobarClinicoAsociadoDNIPaciente(Clinico clinico,String DNI) {
		System.out.println(clinico.getPacientes_id().size());
		for(int i=0;i<=clinico.getPacientes_id().size()-1;i++) {
			if(clinico.getPacientes_id().elementAt(i).equals(DNI)) {
				return true;	//Si el DNI coincide con uno que ya tiene el clinico, entonces ya est� escrito
			}
		}
		return false;
	}


	boolean comprobarClinicosdelPaciente(Paciente paciente) {
		if(paciente.getClinico().isEmpty()) {
			return true;	//Si el paciente no tiene ning�n cl�nico
		}
		return false;
	}

	boolean comprobarCuidadorAsociadoDNIPaciente(Cuidador cuidador,String DNI) {
		for(int i=0;i<=cuidador.getPacientes_id().size()-1;i++) {
			if(cuidador.getPacientes_id().elementAt(i).equals(DNI)) {
				return true;	//Si el DNI coincide con uno que ya tiene el clinico, entonces ya est� escrito
			}
		}
		return false;
	}

}
