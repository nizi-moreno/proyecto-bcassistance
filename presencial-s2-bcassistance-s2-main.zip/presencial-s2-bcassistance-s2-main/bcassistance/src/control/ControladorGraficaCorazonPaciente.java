package control;


import java.util.Arrays;
import java.util.Vector;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.XYChart;

public class ControladorGraficaCorazonPaciente {

    @FXML
    private BarChart<String, Integer> barChart;

    @FXML
    private CategoryAxis xAxis;
    
    private ObservableList<String> diasSemana = FXCollections.observableArrayList();
    
    @FXML
    private void initialize() {
        // Get an array with the English month names.
        String[] dias = {"Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado","Domingo"};
        // Convert it to a list and add it to our ObservableList of months.
        diasSemana.addAll(Arrays.asList(dias));
        
        // Assign the month names as categories for the horizontal axis.
        xAxis.setCategories(diasSemana);
        
            	Vector<Integer> miVector=new Vector<Integer>();
    	int a=1;
    	miVector.add(a);
    	// Count the number of people having their birthday in a specific month.
    	int[] monthCounter = new int[7];


    	        XYChart.Series<String, Integer> series = new XYChart.Series<>();
    	        
    	        // Create a XYChart.Data object for each month. Add it to the series.
    	        for (int i = 0; i < monthCounter.length-1; i++) {
    	        	monthCounter[i]=i+2;
    	        	series.getData().add(new XYChart.Data<>(dias[i],monthCounter[i]));
    	        }
    	        
    	        barChart.getData().add(series);    	   
    }
    void rellenarColumnas(){
    	 		
 
    }
}
