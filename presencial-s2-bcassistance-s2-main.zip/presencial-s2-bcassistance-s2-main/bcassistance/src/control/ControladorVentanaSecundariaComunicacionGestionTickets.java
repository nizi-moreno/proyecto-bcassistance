package control;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import model.Clinico;
import model.Mensaje;
import model.Paciente;
import model.Ticket;
import model.Usuario;

public class ControladorVentanaSecundariaComunicacionGestionTickets {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private JFXButton botonNuevo;

	@FXML
	private GridPane gridPaneInsertarUsuarios;

	@FXML
	private Label labelTickets;

	@FXML
	private Label labelAsunto;

	@FXML
	private GridPane gridPaneInsertarMensajes;

	@FXML
	private JFXTextArea textAreaMensaje;

	@FXML
	private JFXButton botonEnviar;

	@FXML
	private Label labelTituloGestorTickets;

	@FXML
	private Label labelAvisoEnviarMensaje;

	static BorderPane panelInsertarApartado;

	static Usuario usuarioLogueado;

	static String language;

	static boolean isTicketSelected=false;

	static Ticket ticketSeleccionado;

	@FXML
	void handleBotonEnviar(ActionEvent event) {

		//Borramos los avisos anteriores
		labelAvisoEnviarMensaje.setText("");

		//Verificamos que el usuario haya seleccionado un ticket
		if(isTicketSelected) {
			//Comprobamos la longitud del mensaje
			if(!comprobarLongitudMensaje().equals("")) {
				//Creamos el mensaje y los guardamos en los usuarios correspondientes

				Date date = new Date();
				Mensaje mensaje = new Mensaje(comprobarLongitudMensaje(), date, usuarioLogueado.getCredencial().getUsuario_dni());
				ticketSeleccionado.aniadirMensaje(mensaje);
				System.out.println("--Num de mensajes: "+ticketSeleccionado.getListaMensajes().size());

				//Subimos el mensaje a la bbdd
				ControladorBBDD cBBDD = new ControladorBBDD();
				String dniDestinatario ="";
				if(ticketSeleccionado.getCredencialA().equals(usuarioLogueado.getCredencial().getUsuario_dni())) {
					dniDestinatario=ticketSeleccionado.getCredencialB();
				}else {
					dniDestinatario=ticketSeleccionado.getCredencialA();
				}
				//int idTicket = cBBDD.obtenerIDTicketAPartirAsunto(ticketSeleccionado.getAsunto());

				cBBDD.insertarMensaje(mensaje, ticketSeleccionado.getId_ticket(), dniDestinatario);


				//Hacemos que el jtextfield este vacio de nuevo
				textAreaMensaje.setText("");

				//Hacemos que se a�ada el mensaje al gridPane
				//Obtenemos primero la fila en la que se colocaria este nuevo mensaje
				int filaAInsertarMensaje = ticketSeleccionado.getListaMensajes().size()-1;
				System.out.println("--La fila a insertar el mensaje es "+filaAInsertarMensaje);

				//Insertamos el mensaje en el gridpane, que sera de tipo MensajeSaliente
				//idioma
				Locale locale = new Locale(language);
				ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
				//Creamos un objeto FXMLLoader para cargar la pantalla
				FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaRepresentacionMensajeSaliente.fxml"), bundle);
				ControladorVentanaRepresentacionMensajeSaliente.language=language;
				ControladorVentanaRepresentacionMensajeSaliente.usuarioLogueado=usuarioLogueado;
				ControladorVentanaRepresentacionMensajeSaliente c = new ControladorVentanaRepresentacionMensajeSaliente();
				//Le pasamos al controlador el paciente a representar
				c.setMensajeRepresentado(mensaje);
				loader.setController(c);
				Parent root;
				try {
					root = loader.load();
					gridPaneInsertarMensajes.add(root, 0, filaAInsertarMensaje);//Aniadimos el ticket al gridPane
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}else {
			//Avisamos al usuario
			if (language.equals("es_ES")) {
				labelAvisoEnviarMensaje.setText("AVISO: no se ha seleccionado ningun ticket.");
			} else {
				labelAvisoEnviarMensaje.setText("WARNING: no ticket has been selected.");
			}

		}

	}

	public String comprobarLongitudMensaje() {
		String apto="";
		if(!textAreaMensaje.getText().trim().isEmpty()) {
			if(textAreaMensaje.getText().length()<=200) {
				apto=textAreaMensaje.getText();
			}else {
				if (language.equals("es_ES")) {
					labelAvisoEnviarMensaje.setText("AVISO: el mensaje introducido excede el numero de caracteres permitidos.");
				} else {
					labelAvisoEnviarMensaje.setText("WARNING: The message submitted exceeds the character number allowed.");
				}
			}
		}else {
			if (language.equals("es_ES")) {
				labelAvisoEnviarMensaje.setText("AVISO: el mensaje esta vacio, por lo que no se puede enviar.");
			} else {
				labelAvisoEnviarMensaje.setText("WARNING: The message is empty, so it can not be sent.");
			}
		}
		return apto;
	}

	@FXML
	void handleBotonNuevoTicket(ActionEvent event) {
		//Mostramos la ventana de comunicacion de Crear Ticket
		//Conectamos esta ventana con la VentanaSecundariaComunicacionGestionTickets
		System.out.println("Mostrando la ventana de crear nuevo ticket");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaSecundariaComunicacionCrearTicket.fxml"), bundle);
		ControladorVentanaSecundariaComunicacionCrearTicket c = new ControladorVentanaSecundariaComunicacionCrearTicket();
		ControladorVentanaSecundariaComunicacionCrearTicket.usuarioLogueado=usuarioLogueado;
		ControladorVentanaSecundariaComunicacionCrearTicket.language=language;
		ControladorVentanaSecundariaComunicacionCrearTicket.panelInsertarApartado=panelInsertarApartado;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	void limpiarMensajes() {
		//Limpiamos los mensajes del gridPane (en caso de seleccionar de nuevo otro ticket)
		gridPaneInsertarMensajes.getChildren().clear();
	}

	void cargarTickets() {

		//Obtenemos de la base de datos los tickets
		ControladorBBDD cBBDD= new ControladorBBDD();
		usuarioLogueado.setListaTickets(comprobarIndicadorLecturaTickets(cBBDD.consultarTickets(usuarioLogueado.getCredencial().getUsuario_dni())));

		//Si el usuario dispone de tickets...
		if(usuarioLogueado.getListaTickets()!=null) {

			//Guardamos en una lista los tickets a representar
			Vector<Ticket> listaTickets = usuarioLogueado.getListaTickets();

			//Ahora que ya tenemos nuestra lista de tickets, vamos a mostrarlo en el gridPane correspondiente
			//Siempre vamos a tener 1 columna y empezaremos en la fila 1, ya que en la posicion (0,0) tenemos el titulo de la lista
			//En cada celda del gridPane meteremos la representacion de un Ticket

			int celdasNecesarias =listaTickets.size();//Las celdas que necesitamos = cantidad tickets
			System.out.println("CeldasNecesarias para los Tickets= "+celdasNecesarias);

			if(celdasNecesarias!=0) {

				//Configuramos el gridpane con un bucle, hasta haber colocado a todos los tickets
				int x=1;//Empezamos en la fila 1, ya que en la 0 esta el titulo "tickets"

				for(int j=0; j<celdasNecesarias; j++) {
					//Representamos cada ticket en una celda
					//idioma
					Locale locale = new Locale(language);
					ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);

					//Creamos un objeto FXMLLoader para cargar la pantalla
					FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaRepresentacionTicket.fxml"), bundle);
					ControladorVentanaRepresentacionTicket.language=language;
					ControladorVentanaRepresentacionTicket.usuarioLogueado=usuarioLogueado;
					ControladorVentanaRepresentacionTicket.gridPaneInsertarMensajes=gridPaneInsertarMensajes;
					ControladorVentanaRepresentacionTicket.tituloAsuntoTicket=labelAsunto;
					ControladorVentanaRepresentacionTicket controlador = new ControladorVentanaRepresentacionTicket();
					controlador.setControladorTickets(this);
					//Le pasamos al controlador el ticket a representar
					controlador.setTicketRepresentado(listaTickets.get(j));
					loader.setController(controlador);
					Parent root;
					try {
						root = loader.load();
						gridPaneInsertarUsuarios.add(root, 0, x);//Aniadimos el ticket al gridPane

					} catch (IOException e) {
						e.printStackTrace();
					}

					//Incrementamos la x (num fila)
					x++;
				}
			}
			System.out.println("Se han cargado todos los tickets");
		}

	}

	public Vector<Ticket> comprobarIndicadorLecturaTickets(Vector<Ticket> listaTickets) {

		//A la hora de cargar los tickets, debermos determinar si hay q mostrar el indicador de no leido
		//Para ello vamos a recorrer todos los tickets y comparar el remitente con el usuario logueado, para saber si ha leido ya ese mensaje o no

		for(int i=0; i<listaTickets.size(); i++) {
			boolean lectura =true;
			//Recorremos ahora los mensajes de ese ticket
			for(int j=0; j<listaTickets.get(i).getListaMensajes().size(); j++) {
				if(!listaTickets.get(i).getListaMensajes().get(j).isLectura()) {
					//Si ese mensaje consta como no leido, comprobamos que el usuario logueado no es el remitente
					if(!listaTickets.get(i).getListaMensajes().get(j).getAutor().equals(usuarioLogueado.getCredencial().getUsuario_dni())) {
						//Quiere decir que el usuario logueado no escribio ese mensaje, por lo que aun no lo ha leido
						lectura=false;
					}
				}
			}

			listaTickets.get(i).setIndicadorLectura(lectura);
		}

		return listaTickets;
	}


	@FXML
	void initialize() {
		assert botonNuevo != null : "fx:id=\"botonNuevo\" was not injected: check your FXML file 'VentanaSecundariaComunicacionGestionTickets.fxml'.";
		assert gridPaneInsertarUsuarios != null : "fx:id=\"gridPaneInsertarUsuarios\" was not injected: check your FXML file 'VentanaSecundariaComunicacionGestionTickets.fxml'.";
		assert labelTickets != null : "fx:id=\"labelTickets\" was not injected: check your FXML file 'VentanaSecundariaComunicacionGestionTickets.fxml'.";
		assert labelAsunto != null : "fx:id=\"labelAsunto\" was not injected: check your FXML file 'VentanaSecundariaComunicacionGestionTickets.fxml'.";
		assert gridPaneInsertarMensajes != null : "fx:id=\"gridPaneInsertarMensajes\" was not injected: check your FXML file 'VentanaSecundariaComunicacionGestionTickets.fxml'.";
		assert textAreaMensaje != null : "fx:id=\"textAreaMensaje\" was not injected: check your FXML file 'VentanaSecundariaComunicacionGestionTickets.fxml'.";
		assert botonEnviar != null : "fx:id=\"botonEnviar\" was not injected: check your FXML file 'VentanaSecundariaComunicacionGestionTickets.fxml'.";
		assert labelTituloGestorTickets != null : "fx:id=\"labelTituloGestorTickets\" was not injected: check your FXML file 'VentanaSecundariaComunicacionGestionTickets.fxml'.";

		//Cargamos los tickets del usuario
		cargarTickets();
	}
}
