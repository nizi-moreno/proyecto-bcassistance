package control;

import com.jfoenix.controls.JFXTextArea;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.Mensaje;
import model.Usuario;

public class ControladorVentanaRepresentacionMensajeSaliente {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Label labelFechaMensaje;

	@FXML
	private ImageView imagenUsuario;

	@FXML
	private JFXTextArea textFieldMensaje;

	static String language;

	static Label tituloAsuntoTicket;

	private Mensaje mensajeRepresentado;

	static Usuario usuarioLogueado;

	public Mensaje getMensajeRepresentado() {
		return mensajeRepresentado;
	}

	public void setMensajeRepresentado(Mensaje mensajeRepresentado) {
		this.mensajeRepresentado = mensajeRepresentado;
	}

	void rellenarMensaje() {
		System.out.println("PRUEBA - " + mensajeRepresentado.getAutor());
		//Pondriamos la imagen del usuario
		String credencial = mensajeRepresentado.getAutor();
		//Cargamos la imagen de perfil (si tiene una)
		try{
			ControladorBBDD cBBDD = new ControladorBBDD();
			Image imagen = cBBDD.getFotoPerfil(credencial);
			if(imagen!=null) {
				imagenUsuario.setImage(imagen);
			}
		}catch (Exception e) {
			//No tiene imagen de perfil
		}
		//Mostramos el mensaje
		textFieldMensaje.setText(mensajeRepresentado.getContenido());
		//Mostramos la fecha del mensaje
		labelFechaMensaje.setText(mensajeRepresentado.convertirFechaAString());

		System.out.println("Se ha rellenado el mensaje con exito!");
	}

	@FXML
	void initialize() {
		assert labelFechaMensaje != null : "fx:id=\"labelFechaMensaje\" was not injected: check your FXML file 'VentanaRepresentacionMensajeSaliente.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenUsuario\" was not injected: check your FXML file 'VentanaRepresentacionMensajeSaliente.fxml'.";
		assert textFieldMensaje != null : "fx:id=\"textFieldMensaje\" was not injected: check your FXML file 'VentanaRepresentacionMensajeSaliente.fxml'.";
		rellenarMensaje();
	}
}