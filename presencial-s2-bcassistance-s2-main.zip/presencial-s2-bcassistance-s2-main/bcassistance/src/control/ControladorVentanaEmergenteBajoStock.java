package control;

import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.Paciente;
import model.Receta;

public class ControladorVentanaEmergenteBajoStock {

	static String language = "es_ES";
	static Vector<Receta> medicamentosBajoStock = new Vector<Receta>();
	static Paciente paciente = null;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView image;

    @FXML
    private Label LabelBajoStock;

    @FXML
    private Label LabelMedicamentos;

    @FXML
    private Button ButtonMedicamentos;
    
    private BorderPane panelInsertarApartado;
	
   	public BorderPane getPanelInsertarApartado() {
   		return panelInsertarApartado;
   	}

   	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
   		this.panelInsertarApartado = panelInsertarApartado;
   	}

   	@FXML
   	void VerMedicamentos(ActionEvent event) {
   		//Cargamos la pantalla de medicamentos cuando se presiona el boton "Medicamentos"
   		//idioma
   		Locale locale = new Locale(language);
   		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
   		//Creamos un objeto FXMLLoader para cargar la pantalla
   		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaControlMedicamentosPaciente.fxml"), bundle);
   		ControladorVentanaControlMedicamentosPaciente c = new ControladorVentanaControlMedicamentosPaciente();
   		ControladorVentanaControlMedicamentosPaciente.language=language;
		c.setPanelInsertarApartado(panelInsertarApartado);
   		c.setPaciente(paciente);
   		loader.setController(c);
   		Parent root;
   		try {
   			root = loader.load();
   			panelInsertarApartado.setCenter(root);
   			
   			//Cerrar la ventana emergente al mostrar el apartado medicamentos
   			Stage stage = (Stage) ButtonMedicamentos.getScene().getWindow();
	        stage.close(); 
	        
   		} catch (IOException e) {
   			e.printStackTrace();
   		}

   		//Cerramos la ventana
   		Stage stage = (Stage) ButtonMedicamentos.getScene().getWindow();
   		stage.close();

   	}
    
    void LabelMedicamentos() {
    	
    	String medicamentostext = "";
    	Iterator<Receta> itr = medicamentosBajoStock.iterator();
    	Receta recetaactual = null;
    	while (itr.hasNext()) {
    		recetaactual = itr.next();
    		medicamentostext+= recetaactual.getNombre() + ": " + recetaactual.getStock_disponible() + " "
    		+ recetaactual.getTipoDosis() + "\n";
    	}
    	
    	LabelMedicamentos.setText(medicamentostext);
    }
    
    void LabelBajoStock() {
    	if (language.equals("es_ES")) {
    		LabelBajoStock.setText("Se ha detectado la falta de los siguientes medicamentos: ");
    	} else {
    		LabelBajoStock.setText("It has been detected de lack of the following medicine: ");
    	}
    }

    @FXML
    void initialize() {
        assert image != null : "fx:id=\"image\" was not injected: check your FXML file 'VentanaEmergenteBajoStock.fxml'.";
        assert LabelBajoStock != null : "fx:id=\"LabelBajoStock\" was not injected: check your FXML file 'VentanaEmergenteBajoStock.fxml'.";
        assert LabelMedicamentos != null : "fx:id=\"LabelMedicamentos\" was not injected: check your FXML file 'VentanaEmergenteBajoStock.fxml'.";
        assert ButtonMedicamentos != null : "fx:id=\"ButtonMedicamentos\" was not injected: check your FXML file 'VentanaEmergenteBajoStock.fxml'.";
        LabelBajoStock();
        LabelMedicamentos();
    }
}














