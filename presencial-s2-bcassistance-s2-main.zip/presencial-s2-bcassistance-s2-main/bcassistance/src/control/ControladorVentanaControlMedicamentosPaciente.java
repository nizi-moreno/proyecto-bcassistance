package control;


import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.AgendaMedicamento;
import model.Paciente;
import model.Receta;

public class ControladorVentanaControlMedicamentosPaciente {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<Receta> tablaListadoMedicamentos;

    @FXML
    private TableColumn<Receta, String> columnaMedicamentos;
    
    @FXML
    private TableColumn<Receta, Integer> ColumnaCantidadDisponible;

    @FXML
    private TableColumn<Receta, ImageView> ColumnaModificar;
    
    @FXML
    private TableView<AgendaMedicamento> TablaAgendaMedicamentos;
    
    @FXML
    private TableColumn<AgendaMedicamento, String> ColumnaAgenda;

    @FXML
    private TableColumn<AgendaMedicamento, String> ColumnaL;

    @FXML
    private TableColumn<AgendaMedicamento, String> ColumnaM;

    @FXML
    private TableColumn<AgendaMedicamento, String> ColumnaX;

    @FXML
    private TableColumn<AgendaMedicamento, String> ColumnaJ;

    @FXML
    private TableColumn<AgendaMedicamento, String> ColumnaV;

    @FXML
    private TableColumn<AgendaMedicamento, String> ColumnaS;

    @FXML
    private TableColumn<AgendaMedicamento, String> ColumnaD;


    private Paciente paciente;
    static String language;
    
    private BorderPane panelInsertarApartado;
	
	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}
    
    @FXML
    void handleBotonVolver(ActionEvent event) {
    	//Se vuelve a la ficha del paciente
    	
    }
    
    void rellenarListadoMedicamentos() {
    	/*
       	//Creo un paciente
    	Paciente miPaciente=new Paciente();
    	//Creo recetas
    	Receta miReceta1=new Receta();
    	miReceta1.setNombre("NombreMedicina1");
    	miReceta1.setStock_disponible(10);
    	//Creo recetas
    	Receta miReceta2=new Receta();
    	miReceta2.setNombre("NombreMedicina2");
    	miReceta2.setStock_disponible(20);
    	//A�ado las recetas al paciente
    	miPaciente.addMedicina(miReceta1);
    	miPaciente.addMedicina(miReceta2);
    	
    	//Ahora el paciente tiene a�adidas dos recetas
    	paciente=miPaciente;
    	*/
    	//Tenemos que recorrer el listado de medicamentos del paciente y, en cada fila, a�adir el nombre del medicamento y el stock disponible
    	//Creamos un array donde guardaremos todos los elementos
    	ObservableList<Receta> listadoRecetas =paciente.devolverListadoMedicamentosCuidador();   	
    	//Asignamos valores a nuestra columna de medicamentos
    	columnaMedicamentos.setCellValueFactory(new PropertyValueFactory<Receta, String>("nombre"));
    	//Ahora a la columna de stock disponible
    	ColumnaCantidadDisponible.setCellValueFactory(new PropertyValueFactory<Receta, Integer>("stock_disponible"));
    	//Ahora las imagenes de la columna Modificar
    			ColumnaModificar.setPrefWidth(30);
    			ColumnaModificar.setCellFactory(tc -> {
    				//Set up the ImageView
    				final ImageView imageview = new ImageView();
    				imageview.setFitHeight(30);
    				imageview.setFitWidth(30);
    				imageview.setImage(new Image("/Imagenes/add.png"));

    				//Set up the Table
    				TableCell<Receta, ImageView> cell = new TableCell<Receta, ImageView>(); 

    				cell.setGraphic(imageview);
    				cell.setOnMouseClicked(e -> {
    					if (! cell.isEmpty()) {
    						System.out.println("Click en agregar");
    						System.out.println("Medicamento numero " + (cell.getTableRow().getIndex()+1));
    						//ABRIR LA VENTANA DE MODIFICAR la receta y 
    						//sacar la info de la receta con el index del listadoRecetas
    						mostrarAnadirStock(cell.getTableRow().getIndex());
    					}
    				});
    				return cell ;
    			});

    	//Cargamos la informacion en nuestra tabla
    	tablaListadoMedicamentos.setItems(listadoRecetas);
    	
    	if (language.equals("es_ES")) {
			tablaListadoMedicamentos.setPlaceholder(new Label("No dispone de ninguna receta."));
		} else {
			TablaAgendaMedicamentos.setPlaceholder(new Label("Does not have any prescription."));
		}
    }
    
    void rellenarAgendaMedicamentos() {
    	//Accedemos a su lista de medicamentos completo
    	//Guardamos en un array especial los elementos
    	ObservableList<AgendaMedicamento> agendaCompleta = paciente.devolverAgendaMedicamentos();
    	//Asignamos valores a nuestras columnas
    	ColumnaAgenda.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("hora"));
    	ColumnaL.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("L"));
    	ColumnaM.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("M"));
    	ColumnaX.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("X"));
    	ColumnaJ.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("J"));
    	ColumnaV.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("V"));
    	ColumnaS.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("S"));
    	ColumnaD.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("D"));
    	//Cargamos la informacion en nuestra tabla
    	TablaAgendaMedicamentos.setItems(agendaCompleta);
    	if (language.equals("es_ES")) {
			TablaAgendaMedicamentos.setPlaceholder(new Label("No dispone de agenda de medicamentos."));
		} else {TablaAgendaMedicamentos.setPlaceholder(new Label("Does not have a medication schedule."));}
    }
    void rellenarColumnaBotones() {
    	while(true) {
    		int i =1;
    		//Si la celda i no est� vac�a
    		if(!columnaMedicamentos.getCellObservableValue(i).getValue().isEmpty()) {
    			//ColumnaModificar.cell
    		}
    	}
    }
	public static Date sumarDiasAFecha(Timestamp fecha, int dias){
		if (dias==0) return fecha;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fecha); 
		calendar.add(Calendar.DAY_OF_YEAR, dias);  
		return calendar.getTime(); 
	} 
	public void EliminarReceta(){
		

		//HAY QUE HACERLO CON LA BBDD
		
		
		/*ControladorFicherosJson controlador= new ControladorFicherosJson();
		/*Vector pacientes: Vector<Paciente> listaPacientes = new Vector<Paciente>();
		listaPacientes= controlador.deserializarJsonPacientesAArray();
		String DNIPaciente= paciente.getCredencial().getUsuario_dni();
		int posicionPaciente=buscarPaciente(listaPacientes, DNIPaciente);
		Vector<Receta> medicamentos= listaPacientes.get(posicionPaciente).getMedicamentos();
		for(int i=0; i<medicamentos.size(); i++) {
			System.out.println(medicamentos.get(i).getNombre());
			Receta medicamento = medicamentos.get(i);
			Timestamp dia= new Timestamp(new Date().getTime());
			if(dia.equals(sumarDiasAFecha(medicamento.getFecha(),medicamento.getFrecuencia()))|| dia.after(sumarDiasAFecha(medicamento.getFecha(),medicamento.getFrecuencia()))) {
				System.out.println("El medicamento a borrar es: " + medicamentos.get(i).getNombre());
				medicamentos.remove(i);	
				listaPacientes.get(posicionPaciente).refrescarMedicamentoAAgenda();
			}
		}
		controlador.serializarArrayPacientesAJson(listaPacientes);*/
	}
    
    void mostrarAnadirStock(int indexmedicamento) {
    	try {

			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Cargo la ruta del fxml del GUI:
			FXMLLoader loader2= new FXMLLoader (getClass().getResource("/view/VentanaEmergenteAnadirStockMedicamentos.fxml"), bundle);
			ControladorVentanaEmergenteAnadirStockMedicamentos controlador2= new ControladorVentanaEmergenteAnadirStockMedicamentos();
			ControladorVentanaEmergenteAnadirStockMedicamentos.index= indexmedicamento;
			ControladorVentanaEmergenteAnadirStockMedicamentos.language= language;
			ControladorVentanaEmergenteAnadirStockMedicamentos.paciente=paciente;
			controlador2.setPanelInsertarApartado(panelInsertarApartado);
			loader2.setController(controlador2);
			Parent root= loader2.load();
			//Le asignamos al window su scene
			Stage miStage = new Stage();
			miStage.setScene(new Scene(root));
			miStage.setResizable(true);
			miStage.setTitle("Anadir Stock de Medicamento");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(tablaListadoMedicamentos.getScene().getWindow());
			miStage.show();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @FXML
    void initialize() {
        assert TablaAgendaMedicamentos != null : "fx:id=\"TablaAgendaMedicamentos\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        assert ColumnaAgenda != null : "fx:id=\"ColumnaAgenda\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        assert ColumnaL != null : "fx:id=\"ColumnaL\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        assert ColumnaM != null : "fx:id=\"ColumnaM\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        assert ColumnaX != null : "fx:id=\"ColumnaX\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        assert ColumnaJ != null : "fx:id=\"ColumnaJ\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        assert ColumnaV != null : "fx:id=\"ColumnaV\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        assert ColumnaS != null : "fx:id=\"ColumnaS\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        assert ColumnaD != null : "fx:id=\"ColumnaD\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
        EliminarReceta();
        rellenarListadoMedicamentos();
        rellenarAgendaMedicamentos();

    }

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}
}