package control;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class ControladorVentanaEmergenteConfirmacionBaja {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView image;

    @FXML
    private Button botonAceptar;

    @FXML
    private Label mensajeConfirmacionBaja;

    static String language;
    
    private ControladorBLClinico blClinico;
    
    private ControladorBLCuidador blCuidador;
    
    private ControladorBLPaciente blPaciente;
    
    @FXML
    void handleBotonAceptar(ActionEvent event) {
    	//CERRAMOS LA VENTANA DE CONFIRMACION
    	//Obtenemos la ventana sin dependencias y la cerramos
		Node n= (Node) event.getSource();
		Stage stage = (Stage) n.getScene().getWindow();
		stage.close();
		
    	//CERRAMOS LA SESION DEL USUARIO - Volver al login y cerrar hilos de emergencias
		if(blClinico!=null) {
			blClinico.handleButtonCerrarSesion(event);
		}else if(blCuidador!=null) {
			blCuidador.handleBotonCerrarSesion(event);
		}else if(blPaciente!=null){
			blPaciente.handleButtonCerrarSesion(event);
		}
		
    }

    @FXML
    void initialize() {
        assert image != null : "fx:id=\"image\" was not injected: check your FXML file 'VentanaEmergenteConfirmacionBaja.fxml'.";
        assert botonAceptar != null : "fx:id=\"botonAceptar\" was not injected: check your FXML file 'VentanaEmergenteConfirmacionBaja.fxml'.";
        assert mensajeConfirmacionBaja != null : "fx:id=\"mensajeConfirmacionBaja\" was not injected: check your FXML file 'VentanaEmergenteConfirmacionBaja.fxml'.";

    }

	public ControladorBLCuidador getBlCuidador() {
		return blCuidador;
	}

	public void setBlCuidador(ControladorBLCuidador blCuidador) {
		this.blCuidador = blCuidador;
	}

	public ControladorBLPaciente getBlPaciente() {
		return blPaciente;
	}

	public void setBlPaciente(ControladorBLPaciente blPaciente) {
		this.blPaciente = blPaciente;
	}

	public ControladorBLClinico getBlClinico() {
		return blClinico;
	}

	public void setBlClinico(ControladorBLClinico blClinico) {
		this.blClinico = blClinico;
	}
}
