
package control;
import javafx.concurrent.Task;

public class CheckPastilleroTask extends Task<Boolean> {

	private String DNIpaciente;
	private String valorEsperado;

	//Le paso un paciente para revisar su medicacion
	public CheckPastilleroTask(String DNIpaciente, String valorEsperado) {
		this.DNIpaciente=DNIpaciente;
		this.valorEsperado= valorEsperado;
	}

	@Override
	protected void succeeded() {
		super.succeeded();
		System.out.println("Se ha terminado de revisar el pastillero");
	}

	@Override
	protected void running() {
		super.running();
		System.out.println("Revisando el pastillero...");
		// e.g. change mouse courser
	}

	@Override
	protected void failed() {
		super.failed();
		System.out.println("Ha pasado un error en el task del pastillero");// do stuff if call threw an excpetion

	}

	@Override
	protected Boolean call () throws Exception {

		boolean abierto=false;

		try{  
			//Verificamos cada 1s si se ha abierto alguna caja del pastillero
			ControladorBBDD cBBDD = new ControladorBBDD();
			
			//Hacemos una consulta en la BBDD y la comparamos con el valor esperado
			String nuevo_valor=cBBDD.devolverLecturaPastillero(DNIpaciente);
			System.out.println("NUEVO VALOR "+nuevo_valor);
			if(!nuevo_valor.equals("")) {
				if(nuevo_valor.equals(valorEsperado)) {
					abierto = true;

				}else {
					System.out.println("HA ABIERTO PASTILLERO INCORRECTO");
				}
			}

		} catch(Exception e) {
			e.printStackTrace();
		}

		return abierto;
	}


}
