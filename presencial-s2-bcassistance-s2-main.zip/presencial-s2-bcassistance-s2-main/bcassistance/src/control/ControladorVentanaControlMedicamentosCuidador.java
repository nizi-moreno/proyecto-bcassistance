package control;

import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import model.AgendaMedicamento;
import model.CredencialUsuario;
import model.Paciente;
import model.Receta;

public class ControladorVentanaControlMedicamentosCuidador {

	@FXML
	private ResourceBundle resources;
	static CredencialUsuario UsuarioLogueado;

	@FXML
	private URL location;

	@FXML
	private JFXButton botonVolver;

	@FXML
	private TableView<Receta> tablaListadoMedicamentos;

	@FXML
	private TableColumn<Receta, String> columnaMedicamentos;

	@FXML
	private TableColumn<Receta, Integer> ColumnaCantidadDisponible;

	@FXML
	private TableView<AgendaMedicamento> TablaAgendaMedicamentos;

	@FXML
	private TableColumn<AgendaMedicamento, String> ColumnaAgenda;

	@FXML
	private TableColumn<AgendaMedicamento, String> ColumnaL;

	@FXML
	private TableColumn<AgendaMedicamento, String> ColumnaM;

	@FXML
	private TableColumn<AgendaMedicamento, String> ColumnaX;

	@FXML
	private TableColumn<AgendaMedicamento, String> ColumnaJ;

	@FXML
	private TableColumn<AgendaMedicamento, String> ColumnaV;

	@FXML
	private TableColumn<AgendaMedicamento, String> ColumnaS;

	@FXML
	private TableColumn<AgendaMedicamento, String> ColumnaD;

	static Paciente paciente;
	static String language;

	private BorderPane panelInsertarApartado;

	//Getters y setters del panel
	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}

	@FXML
	void handleBotonVolver(ActionEvent event) {
		//Volvemos a la p�gina del login
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/VentanaFichaPaciente.fxml"), bundle);
			ControladorVentanaFichaPaciente control2= new ControladorVentanaFichaPaciente();
			control2.setPanelInsertarApartado(panelInsertarApartado);
			ControladorVentanaFichaPaciente.paciente=paciente;
			ControladorVentanaFichaPaciente.UsuarioLogueado= UsuarioLogueado;
			ControladorVentanaFichaPaciente.language = language;
			loader.setController(control2);				//Al loader (FXML) le asignamoos su controlador			
			Parent root = loader.load();				//Asignamos como root el fxml

			panelInsertarApartado.setCenter(root);
			//panelactual = "Pacientes";

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	void rellenarListadoMedicamentos() {
		//Tenemos que recorrer el listado de medicamentos del paciente y, en cada fila, a�adir el nombre del medicamento y el stock disponible
		//Creamos un array donde guardaremos todos los elementos
		ObservableList<Receta> listadoRecetas =paciente.devolverListadoMedicamentosCuidador();   	
		//Asignamos valores a nuestra columna de medicamentos
		columnaMedicamentos.setCellValueFactory(new PropertyValueFactory<Receta, String>("nombre"));
		//Ahora a la columna de stock disponible
		ColumnaCantidadDisponible.setCellValueFactory(new PropertyValueFactory<Receta, Integer>("stock_disponible"));
		//Cargamos la informacion en nuestra tabla
		tablaListadoMedicamentos.setItems(listadoRecetas);
		if (language.contentEquals("es_ES")) {
			tablaListadoMedicamentos.setPlaceholder(new Label("No dispone de ninguna receta."));
		} else {
			TablaAgendaMedicamentos.setPlaceholder(new Label("Does not have any prescription."));
		}
	}
	public static Date sumarDiasAFecha(Timestamp fecha, int dias){
		if (dias==0) return fecha;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fecha); 
		calendar.add(Calendar.DAY_OF_YEAR, dias);  
		return calendar.getTime(); 
	}
	
	public void EliminarReceta(){
		

		//HAY QUE HACERLO CON LA BBDD
		
		
		/*
		ControladorFicherosJson controlador= new ControladorFicherosJson();
		/*Vector pacientes: Vector<Paciente> listaPacientes = new Vector<Paciente>();
		listaPacientes= controlador.deserializarJsonPacientesAArray();
		String DNIPaciente= paciente.getCredencial().getUsuario_dni();
		int posicionPaciente=buscarPaciente(listaPacientes, DNIPaciente);
		Vector<Receta> medicamentos= listaPacientes.get(posicionPaciente).getMedicamentos();
		for(int i=0; i<medicamentos.size(); i++) {
			System.out.println(medicamentos.get(i).getNombre());
			Receta medicamento = medicamentos.get(i);
			Timestamp dia= new Timestamp(new Date().getTime());
			if(dia.equals(sumarDiasAFecha(medicamento.getFecha(),medicamento.getFrecuencia()))|| dia.after(sumarDiasAFecha(medicamento.getFecha(),medicamento.getFrecuencia()))) {
				System.out.println("El medicamento a borrar es: " + medicamentos.get(i).getNombre());
				medicamentos.remove(i);	
				listaPacientes.get(posicionPaciente).refrescarMedicamentoAAgenda();
			}
		}
		controlador.serializarArrayPacientesAJson(listaPacientes);*/
	}
	

	void rellenarAgendaMedicamentos() {
		//Accedemos a su lista de medicamentos completo
		//Guardamos en un array especial los elementos
		ObservableList<AgendaMedicamento> agendaCompleta = paciente.devolverAgendaMedicamentos();
		//Asignamos valores a nuestras columnas
		ColumnaAgenda.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("hora"));
		ColumnaL.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("L"));
		ColumnaM.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("M"));
		ColumnaX.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("X"));
		ColumnaJ.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("J"));
		ColumnaV.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("V"));
		ColumnaS.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("S"));
		ColumnaD.setCellValueFactory(new PropertyValueFactory<AgendaMedicamento, String>("D"));
		//Cargamos la informacion en nuestra tabla
		TablaAgendaMedicamentos.setItems(agendaCompleta);
		if (language.contentEquals("es_ES")) {
			TablaAgendaMedicamentos.setPlaceholder(new Label("No dispone de agenda de medicamentos."));
		} else {TablaAgendaMedicamentos.setPlaceholder(new Label("Does not have a medication schedule."));}
	}

	@FXML
	void initialize() {
		assert botonVolver != null : "fx:id=\"botonVolver\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert TablaAgendaMedicamentos != null : "fx:id=\"TablaAgendaMedicamentos\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert ColumnaAgenda != null : "fx:id=\"ColumnaAgenda\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert ColumnaL != null : "fx:id=\"ColumnaL\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert ColumnaM != null : "fx:id=\"ColumnaM\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert ColumnaX != null : "fx:id=\"ColumnaX\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert ColumnaJ != null : "fx:id=\"ColumnaJ\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert ColumnaV != null : "fx:id=\"ColumnaV\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert ColumnaS != null : "fx:id=\"ColumnaS\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		assert ColumnaD != null : "fx:id=\"ColumnaD\" was not injected: check your FXML file 'VentanaControlMedicamentosCuidador.fxml'.";
		EliminarReceta();
		rellenarListadoMedicamentos();
		rellenarAgendaMedicamentos();

	}

}