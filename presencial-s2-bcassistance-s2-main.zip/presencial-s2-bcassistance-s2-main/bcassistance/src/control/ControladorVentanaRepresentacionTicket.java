package control;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;
import model.Callcenter;
import model.Clinico;
import model.Cuidador;
import model.Mensaje;
import model.Paciente;
import model.Ticket;
import model.Usuario;

public class ControladorVentanaRepresentacionTicket {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private AnchorPane anchorPaneRepresentacionTicket;

	@FXML
	private ImageView imagenUsuario;

	@FXML
	private Circle indicadorMensajesSinLeer;

	@FXML
	private Label labelUsuario;

	@FXML
	private Label labelAsuntoTicket;

	@FXML
	private Label labelRolUsuario;

	static Usuario usuarioLogueado;

	private Ticket ticketRepresentado;

	static String language;

	static GridPane gridPaneInsertarMensajes;

	static Label tituloAsuntoTicket;


	public Ticket getTicketRepresentado() {
		return ticketRepresentado;
	}

	public void setTicketRepresentado(Ticket ticketRepresentado) {
		this.ticketRepresentado = ticketRepresentado;
	}

	private ControladorVentanaSecundariaComunicacionGestionTickets controladorTickets;

	private ControladorVentanaComunicacionEmergencias controladorEmergencias;

	public ControladorVentanaSecundariaComunicacionGestionTickets getControladorTickets() {
		return controladorTickets;
	}

	public void setControladorTickets(ControladorVentanaSecundariaComunicacionGestionTickets controladorTickets) {
		this.controladorTickets = controladorTickets;
	}

	public ControladorVentanaComunicacionEmergencias getControladorEmergencias() {
		return controladorEmergencias;
	}

	public void setControladorEmergencias(ControladorVentanaComunicacionEmergencias controladorEmergencias) {
		this.controladorEmergencias = controladorEmergencias;
	}

	@FXML
	void handleTicketSeleccionado(MouseEvent event) {

		//Cuando se selecciona un ticket, limpiamos el gridPane de mensajes, para que no se combinen mensajes de distintos tickets
		if(controladorTickets!=null) {
			controladorTickets.limpiarMensajes();
		}

		if(controladorEmergencias!=null) {
			controladorEmergencias.limpiarMensajes();
		}

		ControladorBBDD cBBDD = new ControladorBBDD();
		System.out.println("Se ha seleccionado el ticket con asunto: "+ticketRepresentado.getAsunto());

		//Lo primero que tenemos que hacer es apagar el indicador de lectura
		indicadorMensajesSinLeer.setVisible(false);
		
		//Actualizamos en la BBDD los indicadores de lectura de los mensajes que se han leido
		updateLecturasMensajes();

		//Diferenciamos entre un ticket normal y un ticket de emergencias
		if(ticketRepresentado.getEmergenciaChat()==null) {//TicketNormal

			if(!ticketRepresentado.getListaMensajes().isEmpty()) {
				//Le pasamos a la ventana de gestion de tickets el ticket y el boolean de leido
				ControladorVentanaSecundariaComunicacionGestionTickets.isTicketSelected=true;
				ControladorVentanaSecundariaComunicacionGestionTickets.ticketSeleccionado=ticketRepresentado;


				//FALTA MANEJAS EL INDICADOR DE LECTURA
				if(usuarioLogueado.getCredencial().getRol()==0) {//Paciente
					

				}else if(usuarioLogueado.getCredencial().getRol()==2) {//Clinico
					
				}

				//Hacemos que se muestre el asunto del mensaje en la parte derecha
				tituloAsuntoTicket.setText(ticketRepresentado.getAsunto());

				//Hacemos que se muestren los mensajes en la parte derecha, en el gridPaneInsertarMensajes
				//Debemos tener en cuenta al AUTOR del mensaje para mostrarlo de una forma u otra
				//Guardamos en un vector la lista de mensajes a mostrar
				Vector<Mensaje> listaMensajes = ticketRepresentado.getListaMensajes();
				int celdasNecesarias =listaMensajes.size();//Las celdas que necesitamos = cantidad mensajes
				System.out.println("celdasNecesariasMensaje = "+celdasNecesarias);


				//Configuramos el gridpane con un bucle, hasta haber colocado a todos los mensajes
				int x=0;//fila

				for(int j=0; j<celdasNecesarias;j++) {
					//Para cada mensaje, creamos la representacion, segun sea emisor o receptor
					//Averiguamos quien es el receptor y el emisor en la comunicacion
					if(usuarioLogueado.getCredencial().getUsuario_dni().equals(listaMensajes.get(j).getAutor())) {
						//Si el usuario logueado, es el autor de ese mensaje, utilizaremos la representacion del MensajeSaliente (lo ha escrito el/ella)
						//idioma
						Locale locale = new Locale(language);
						ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
						//Creamos un objeto FXMLLoader para cargar la pantalla
						FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaRepresentacionMensajeSaliente.fxml"), bundle);
						ControladorVentanaRepresentacionMensajeSaliente.language=language;
						ControladorVentanaRepresentacionMensajeSaliente.usuarioLogueado=usuarioLogueado;
						ControladorVentanaRepresentacionMensajeSaliente c = new ControladorVentanaRepresentacionMensajeSaliente();
						//Le pasamos al controlador el paciente a representar
						c.setMensajeRepresentado(listaMensajes.get(j));
						loader.setController(c);
						Parent root;
						try {
							root = loader.load();
							gridPaneInsertarMensajes.add(root, 0, x);//Aniadimos el ticket al gridPane
						} catch (IOException e) {
							e.printStackTrace();
						}
					}else {//Se trata de un mensaje del receptor, utilizaremos MensajeEntrante
						//idioma
						Locale locale = new Locale(language);
						ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
						//Creamos un objeto FXMLLoader para cargar la pantalla
						FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaRepresentacionMensajeEntrante.fxml"), bundle);
						ControladorVentanaRepresentacionMensajeEntrante.language=language;
						ControladorVentanaRepresentacionMensajeEntrante.usuarioLogueado=usuarioLogueado;
						ControladorVentanaRepresentacionMensajeEntrante c = new ControladorVentanaRepresentacionMensajeEntrante();
						//Le pasamos al controlador el paciente a representar
						c.setMensajeRepresentado(listaMensajes.get(j));
						loader.setController(c);
						Parent root;
						try {
							root = loader.load();
							gridPaneInsertarMensajes.add(root, 0, x);//Aniadimos el ticket al gridPane
						} catch (IOException e) {
							e.printStackTrace();
						}
					}

					//Incrementamos la x (fila)
					x++;
				}

			}

		}else {//Ticket de emergencia

			//SE TENDRA QUE COMPLETAR CUANDO TENGAMOS LOS SENSORES CONECTADOS
			if(!ticketRepresentado.getListaMensajes().isEmpty()) {
				//Le pasamos a la ventana de gestion de tickets el ticket y el boolean de leido
				ControladorVentanaComunicacionEmergencias.isTicketSelected=true;
				ControladorVentanaComunicacionEmergencias.ticketSeleccionado=ticketRepresentado;


				//FALTA MANEJAS EL INDICADOR DE LECTURA
				if(usuarioLogueado.getCredencial().getRol()==1) {//Cuidador
					

				}else if(usuarioLogueado.getCredencial().getRol()==3) {//CallCenter
					
				}

				//Hacemos que se muestre el asunto del mensaje en la parte derecha
				tituloAsuntoTicket.setText(ticketRepresentado.getAsunto());

				//Colocamos la emergenciaChat
				Locale locale1 = new Locale(language);
				ResourceBundle bundle1 = ResourceBundle.getBundle("recursos.lang", locale1);
				//Creamos un objeto FXMLLoader para cargar la pantalla
				FXMLLoader loader1 = new FXMLLoader (getClass().getResource("/view/VentanaEmergenciaChat.fxml"), bundle1);
				ControladorVentanaEmergenciaChat.language=language;
				ControladorVentanaEmergenciaChat c1 = new ControladorVentanaEmergenciaChat();
				//Le pasamos al controlador el paciente a representar
				c1.setEmergenciaARepresentar(ticketRepresentado.getEmergenciaChat());
				loader1.setController(c1);
				Parent root1;
				try {
					root1 = loader1.load();
					gridPaneInsertarMensajes.add(root1, 0, 0);//Aniadimos el ticket al gridPane
				} catch (IOException e) {
					e.printStackTrace();
				}

				//Hacemos que se muestren los mensajes en la parte derecha, en el gridPaneInsertarMensajes
				//Debemos tener en cuenta al AUTOR del mensaje para mostrarlo de una forma u otra
				//Guardamos en un vector la lista de mensajes a mostrar
				Vector<Mensaje> listaMensajes = ticketRepresentado.getListaMensajes();
				int celdasNecesarias =listaMensajes.size();//Las celdas que necesitamos = cantidad mensajes
				//System.out.println("celdasNecesariasMensaje = "+celdasNecesarias);

				//Configuramos el gridpane con un bucle, hasta haber colocado a todos los mensajes
				int x=1;//fila

				for(int j=1; j<celdasNecesarias;j++) {
					//Para cada mensaje, creamos la representacion, segun sea emisor o receptor
					//Averiguamos quien es el receptor y el emisor en la comunicacion
					if(usuarioLogueado.getCredencial().getUsuario_dni().equals(listaMensajes.get(j).getAutor())) {
						//Si el usuario logueado, es el autor de ese mensaje, utilizaremos la representacion del MensajeSaliente (lo ha escrito el/ella)
						//idioma
						Locale locale = new Locale(language);
						ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
						//Creamos un objeto FXMLLoader para cargar la pantalla
						FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaRepresentacionMensajeSaliente.fxml"), bundle);
						ControladorVentanaRepresentacionMensajeSaliente.language=language;
						ControladorVentanaRepresentacionMensajeSaliente.usuarioLogueado=usuarioLogueado;
						ControladorVentanaRepresentacionMensajeSaliente c = new ControladorVentanaRepresentacionMensajeSaliente();
						//Le pasamos al controlador el paciente a representar
						c.setMensajeRepresentado(listaMensajes.get(j));
						loader.setController(c);
						Parent root;
						try {
							root = loader.load();
							gridPaneInsertarMensajes.add(root, 0, x);//Aniadimos el ticket al gridPane
						} catch (IOException e) {
							e.printStackTrace();
						}
					}else {//Se trata de un mensaje del receptor, utilizaremos MensajeEntrante
						//idioma
						Locale locale = new Locale(language);
						ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
						//Creamos un objeto FXMLLoader para cargar la pantalla
						FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaRepresentacionMensajeEntrante.fxml"), bundle);
						ControladorVentanaRepresentacionMensajeEntrante.language=language;
						ControladorVentanaRepresentacionMensajeEntrante.usuarioLogueado=usuarioLogueado;
						ControladorVentanaRepresentacionMensajeEntrante c = new ControladorVentanaRepresentacionMensajeEntrante();
						//Le pasamos al controlador el paciente a representar
						c.setMensajeRepresentado(listaMensajes.get(j));
						loader.setController(c);
						Parent root;
						try {
							root = loader.load();
							gridPaneInsertarMensajes.add(root, 0, x);//Aniadimos el ticket al gridPane
						} catch (IOException e) {
							e.printStackTrace();
						}
					}

					//Incrementamos la x (fila)
					x++;
				}
			}

		}

		System.out.println("Se han cargado todos los mensajes del ticket seleccionado");

	}


	void updateLecturasMensajes() {
		//Vamos a trabajar con los mensajes del ticket seleccionado para hacer Updates de los indicadores de lectura
		ControladorBBDD cBBDD = new ControladorBBDD();
		
		//Recorremos la lista de mensajes
		for(int i=0; i<ticketRepresentado.getListaMensajes().size();i++) {
			if(!ticketRepresentado.getListaMensajes().get(i).getAutor().equals(usuarioLogueado.getCredencial().getUsuario_dni())) {
				//Quiere decir que acaba de leer el mensaje por primera vez, asi que modificamos el dato en la base de datos y en el objeto
				ticketRepresentado.getListaMensajes().get(i).setLectura(true);
				cBBDD.modificarIndicadorLecturaMensaje(ticketRepresentado.getListaMensajes().get(i).getId_mensaje());
			}
		}
		
	}
	
	
	void rellenarTicket() {

		ControladorBBDD cBBDD = new ControladorBBDD();

		//Diferenciamos entre un ticket normal y un ticket de emergencias
		if(ticketRepresentado.getEmergenciaChat()==null) {//TicketNormal

			//Encontramos el usuario que debemos representar en el ticket
			if(ticketRepresentado.getCredencialA().equals(usuarioLogueado.getCredencial().getUsuario_dni())) {
				//Usaremos la credencial B para representar al usuario del ticket
				//Sabremos el rol del usuario a partir del rol del usuario logueado

				if(usuarioLogueado.getCredencial().getRol()==0) {//es decir, es un paciente
					//Entonces el la otra credencial, la credencial B se corresponde a un clinico

					Clinico clinico = cBBDD.BuscarClinico(ticketRepresentado.getCredencialB());
					
					//Si existe el clinico
					if(clinico!=null) {
						//Buscamos su imagen de perfil en su carpeta y la mostramos
						//Cargamos la imagen de perfil (si tiene una)
						try{
							if(clinico.getImagenPerfil()!=null) {
								imagenUsuario.setImage(clinico.getImagenPerfil());
							}
						}catch (Exception e) {
							//No tiene imagen de perfil
						}

						//Representamos su nombre
						labelUsuario.setText(clinico.getNombreYApellidos());

						//Representamos su rol
						labelRolUsuario.setText("Clinico");

						//Mostramos el indicador de mensajes sin leer
						indicadorMensajesSinLeer.setVisible(!ticketRepresentado.isIndicadorLectura());

						//Mostramos el asunto del ticket
						labelAsuntoTicket.setText(ticketRepresentado.getAsunto());
					}

				}else if(usuarioLogueado.getCredencial().getRol()==2) {//es un clinico
					//Entonces la credencial B se corresponde a un paciente
					Paciente paciente = cBBDD.BuscarPaciente(ticketRepresentado.getCredencialB());

					//Si existe el paciente...
					if(paciente!=null) {
						//Buscamos su imagen de perfil en su carpeta y la mostramos
						try{
							if(paciente.getImagenPerfil()!=null) {
								imagenUsuario.setImage(paciente.getImagenPerfil());
							}
							
						}catch (Exception e) {
							//No tiene imagen de perfil
						}
						//Representamos su nombre
						labelUsuario.setText(paciente.getNombreYApellidos());

						//Representamos su rol
						labelRolUsuario.setText("Paciente");

						//Mostramos el indicador de mensajes sin leer
						indicadorMensajesSinLeer.setVisible(!ticketRepresentado.isIndicadorLectura());

						//Mostramos el asunto del ticket
						labelAsuntoTicket.setText(ticketRepresentado.getAsunto());
					}
				}
			}else {
				//Usaremos la credencial A para representar 
				if(usuarioLogueado.getCredencial().getRol()==0) {//es decir, es un paciente
					//Entonces el la otra credencial, la credencial A se corresponde a un clinico

					Clinico clinico = cBBDD.BuscarClinico(ticketRepresentado.getCredencialA());

					if(clinico!=null) {
						//Buscamos su imagen de perfil en su carpeta y la mostramos
						try{
							if(clinico.getImagenPerfil()!=null) {
								imagenUsuario.setImage(clinico.getImagenPerfil());
							}
						}catch (Exception e) {
							//No tiene imagen de perfil
						}

						//Representamos su nombre
						labelUsuario.setText(clinico.getNombreYApellidos());

						//Representamos su rol
						labelRolUsuario.setText("Clinico");

						//Mostramos el indicador de mensajes sin leer
						indicadorMensajesSinLeer.setVisible(!ticketRepresentado.isIndicadorLectura());

						//Mostramos el asunto del ticket
						labelAsuntoTicket.setText(ticketRepresentado.getAsunto());
					}

				}else if(usuarioLogueado.getCredencial().getRol()==2) {//es un clinico
					//Entonces la credencial A se corresponde a un paciente
					Paciente paciente = cBBDD.BuscarPaciente(ticketRepresentado.getCredencialA());

					if(paciente!=null) {
						//Buscamos su imagen de perfil en su carpeta y la mostramos
						try{
							if(paciente.getImagenPerfil()!=null) {
								imagenUsuario.setImage(paciente.getImagenPerfil());
							}
						}catch (Exception e) {
							//No tiene imagen de perfil
						}

						//Representamos su nombre
						labelUsuario.setText(paciente.getNombreYApellidos());

						//Representamos su rol
						labelRolUsuario.setText("Paciente");

						//Mostramos el indicador de mensajes sin leer
						indicadorMensajesSinLeer.setVisible(!ticketRepresentado.isIndicadorLectura());

						//Mostramos el asunto del ticket
						labelAsuntoTicket.setText(ticketRepresentado.getAsunto());
					}
				}
			}

		}else {//Ticket de EMERGENCIA

			//HABRA QUE RELLENAR ESTA PARTE CUANDO TENGAMOS LOS SENSORES
			//Encontramos el usuario que debemos representar en el ticket
			if(ticketRepresentado.getCredencialA().equals(usuarioLogueado.getCredencial().getUsuario_dni())) {
				//Usaremos la credencial B para representar al usuario del ticket
				//Sabremos el rol del usuario a partir del rol del usuario logueado

				if(usuarioLogueado.getCredencial().getRol()==1) {//es decir, es un cuidador
					//Entonces el la otra credencial, la credencial B se corresponde a un callcenter

					Callcenter callcenter = cBBDD.BuscarCallcenter(ticketRepresentado.getCredencialB());
					
					//Si existe el callcenter
					if(callcenter!=null) {
						//Buscamos su imagen de perfil en su carpeta y la mostramos
						//Cargamos la imagen de perfil (si tiene una)
						try{
							if(callcenter.getImagenPerfil()!=null) {
								imagenUsuario.setImage(callcenter.getImagenPerfil());
							}
						}catch (Exception e) {
							//No tiene imagen de perfil
						}

						//Representamos su nombre
						labelUsuario.setText(callcenter.getNombreYApellidos());

						//Representamos su rol
						labelRolUsuario.setText("Call Center");

						//Mostramos el indicador de mensajes sin leer
						indicadorMensajesSinLeer.setVisible(!ticketRepresentado.isIndicadorLectura());

						//Mostramos el asunto del ticket
						labelAsuntoTicket.setText(ticketRepresentado.getAsunto());
					}

				}else if(usuarioLogueado.getCredencial().getRol()==3) {//es un call center
					//Entonces la credencial B se corresponde a un cuidador
					Cuidador cuidador = cBBDD.BuscarCuidador(ticketRepresentado.getCredencialB());

					//Si existe el cuidador...
					if(cuidador!=null) {
						//Buscamos su imagen de perfil en su carpeta y la mostramos
						try{
							if(cuidador.getImagenPerfil()!=null) {
								imagenUsuario.setImage(cuidador.getImagenPerfil());
							}
						}catch (Exception e) {
							//No tiene imagen de perfil
						}
						//Representamos su nombre
						labelUsuario.setText(cuidador.getNombreYApellidos());

						//Representamos su rol
						labelRolUsuario.setText("Cuidador");

						//Mostramos el indicador de mensajes sin leer
						indicadorMensajesSinLeer.setVisible(!ticketRepresentado.isIndicadorLectura());

						//Mostramos el asunto del ticket
						labelAsuntoTicket.setText(ticketRepresentado.getAsunto());
					}
				}
			}else {
				//Usaremos la credencial A para representar 
				if(usuarioLogueado.getCredencial().getRol()==1) {//es decir, es un cuidador
					//Entonces el la otra credencial, la credencial A se corresponde a un callcenter

					Callcenter callcenter = cBBDD.BuscarCallcenter(ticketRepresentado.getCredencialA());

					if(callcenter!=null) {
						//Buscamos su imagen de perfil en su carpeta y la mostramos
						try{
							if(callcenter.getImagenPerfil()!=null) {
								imagenUsuario.setImage(callcenter.getImagenPerfil());
							}
						}catch (Exception e) {
							//No tiene imagen de perfil
						}

						//Representamos su nombre
						labelUsuario.setText(callcenter.getNombreYApellidos());

						//Representamos su rol
						labelRolUsuario.setText("Call Center");

						//Mostramos el indicador de mensajes sin leer
						indicadorMensajesSinLeer.setVisible(!ticketRepresentado.isIndicadorLectura());

						//Mostramos el asunto del ticket
						labelAsuntoTicket.setText(ticketRepresentado.getAsunto());
					}

				}else if(usuarioLogueado.getCredencial().getRol()==3) {//es un callcenter
					//Entonces la credencial A se corresponde a un cuidador
					Cuidador cuidador = cBBDD.BuscarCuidador(ticketRepresentado.getCredencialA());

					if(cuidador!=null) {
						//Buscamos su imagen de perfil en su carpeta y la mostramos
						try{
							if(cuidador.getImagenPerfil()!=null) {
								imagenUsuario.setImage(cuidador.getImagenPerfil());
							}
						}catch (Exception e) {
							//No tiene imagen de perfil
						}

						//Representamos su nombre
						labelUsuario.setText(cuidador.getNombreYApellidos());

						//Representamos su rol
						labelRolUsuario.setText("Cuidador");

						//Mostramos el indicador de mensajes sin leer
						indicadorMensajesSinLeer.setVisible(!ticketRepresentado.isIndicadorLectura());

						//Mostramos el asunto del ticket
						labelAsuntoTicket.setText(ticketRepresentado.getAsunto());
					}
				}
			}
			
		}
	}


	@FXML
	void initialize() {
		assert anchorPaneRepresentacionTicket != null : "fx:id=\"anchorPaneRepresentacionTicket\" was not injected: check your FXML file 'VentanaRepresentacionTicket.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenUsuario\" was not injected: check your FXML file 'VentanaRepresentacionTicket.fxml'.";
		assert indicadorMensajesSinLeer != null : "fx:id=\"indicadorMensajesSinLeer\" was not injected: check your FXML file 'VentanaRepresentacionTicket.fxml'.";
		assert labelUsuario != null : "fx:id=\"labelUsuario\" was not injected: check your FXML file 'VentanaRepresentacionTicket.fxml'.";
		assert labelAsuntoTicket != null : "fx:id=\"labelAsuntoTicket\" was not injected: check your FXML file 'VentanaRepresentacionTicket.fxml'.";
		assert labelRolUsuario != null : "fx:id=\"labelRolUsuario\" was not injected: check your FXML file 'VentanaRepresentacionTicket.fxml'.";
		rellenarTicket();
	}
}