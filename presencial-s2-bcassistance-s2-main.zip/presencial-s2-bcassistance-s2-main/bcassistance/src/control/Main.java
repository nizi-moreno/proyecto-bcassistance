package control;


import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.CredencialUsuario;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;

public class Main extends Application {

	public static final String GOOGLE_API_KEY = "AIzaSyDYISgaDEPjmh1yX4YT_pGSi63BazAfGCE";//Clave para la api
	
	//Creamos un 05334530Wstage que ser� la ventana en que la que se mostrar� cada scene que queramos (scene es lo que cambia)
	static Stage window;

	/*
	 Usuarios pacientes contrasenas:
	 Sol: 55388495X Contrasena: contrasena
	 Eva: 41605208W Contrasena: 1234	 
	 Olga: 53991100A Contrasena: 1234hola
	 David: 42190950A Contrasena:28691
	 Esther: 57842094S Contrasena: alubias
	 Jesus: 16445440A Contrasena: tengohambre
	 Amanda: 32501371W Contrasena: amanda
	 Santiago: 26561410K Contrasena: panbimbo
	 Pablo: 71965910Z Contasena: eclipse
	 Carlos: 80300060E Contrasena: tortilla

	 Usuarios clinicos contrasenas: 
	 Diego: 05334530W Contrasena: 601351273
	 Fernando:19161570V Contrasena: palorosa 
	 Lucia: 96721515Y Contrasena: lucia

	 Usuarios cuidadores contrasenas:
	 Niza: 53991010A Contrasena: 683561806
	 Javier: 72728756L Contrasena: 987654321
	 Matilde: 42853864B Contrasena: matilde18
	 Sebastian: 40774082G Contrasena: 123456
	 Juan: 95980416J Contrasena: 123456
	 Cayetana: 60761362P Contrasena: 123456
	 Pepe: 06936831P Contrasena:123456

	 Usuarios call center contrasena:
	 George: 55388495W Contrasena:1234hola
	 Monica: 12312312W Contrasena:1234hola

	 */	

	@Override
	public void start(Stage primaryStage) {

		//De esta manera nos podemos referir a window como la ventana principal que contendria todos nuestros scenes
		window=primaryStage;
		//Para controlar el cierre de la ventana
		window.setOnCloseRequest(e -> {
			e.consume();
			closeProgram();
		});
		//Codigo para el login

		try {

			Locale locale = new Locale("es_ES");
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);

			//Cargo la ruta del fxml de la p�gina de login:
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/GUI_Login.fxml"), bundle);
			ControladorLogin controlador1= new ControladorLogin();
			controlador1.setWindow(window);
			loader.setController(controlador1);
			Parent root= loader.load();
			//Le asignamos al window su scene
			window.setScene(new Scene(root));
			window.setTitle("BCAssistance");
			window.show();
			Image icono=new Image("./Imagenes/logonegro.png");
			window.getIcons().add(icono);

		} catch(Exception e) {
			e.printStackTrace();
		}

	}

	//Para controlar el cierre de la aplicaci�n
	public void closeProgram() {

		Alert alert = new Alert(AlertType.CONFIRMATION);
		if (ControladorLogin.language.equals("es_ES")) {
			alert.setTitle("Aviso cierre");
			alert.setHeaderText("Cierre de BCAssistance");
			alert.setContentText("�Esta seguro de que quiere cerrar la aplicacion?");
		} else {
			alert.setTitle("Closing warning ");
			alert.setHeaderText("BCAssistance closing");
			alert.setContentText("Are you sure you want to close the application?");
		}
		alert.initModality(Modality.APPLICATION_MODAL);

		//Para ponerle icono a la alerta
		// Get the Stage.
		Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
		// Add a custom icon.
		stage.getIcons().add(new Image("./Imagenes/logonegro.png"));

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK){
			//Se ha seleccionado cerrar la aplicacion
			System.out.println("Se ha decidido cerrar la aplicacion");
			window.close();//Cerramos la ventana
			System.exit(0);//Para cerrar la consola en caso de que se quede abierta
		} else if(result.get()==ButtonType.CANCEL){
			//Se ha seleccionado NO cerrar la aplicacion
			System.out.println("Se ha cancelado el cierre de la aplicacion");
			alert.close();
		}

	}

	public static void main(String[] args) {

		/*
		 * Esto de aqu� debajo es para anadir del tiron
		 * todos los pacientes a la tabla pero no puedo probarlo hasta
		 * haber insertado los clinicos en la de usuarios 
		 */

		launch(args);

		
		//String ruta = "ficheros/CarpetasUsuarios/55388495W/55388495W.png";;
		//cBBDD.aniadirFotoPerfil("80300060E");
		//cBBDD.aniadirFotoPerfil("12312312W");
		
		//cBBDD.BorrarReceta("53991100A", receta);
		/*String password="601351273";
		String usuario="05334530W";
		cBBDD.loginOptimizado(password, usuario);
		//cBBDD.anadirStock("53991100A", "Naproxeno", 10);
		/*

		Vector<Receta> recetas = cBBDD.getRecetas("53991100A");

		/*
		String dniPaciente="53991100A";
		String dniClinico= "05334530W";
		Timestamp fecha=new Timestamp(new Date().getTime());

		//Inserto todas las recetas en la base de datos
		Iterator<Paciente> itr = ficheros.deserializarJsonPacientesAArray().iterator();
		while (itr.hasNext()) {				
			Paciente actual = itr.next();
			bbdd.insertarPaciente(actual);
		} */
	}

	public void mostrarEmergenteAnadirPaciente(CredencialUsuario UsuarioLogueado, String language) {
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/VentanaEmergenteAnadirPaciente.fxml"), bundle);	//Importamos el fxml de la segunda ventana
			ControladorVentanaEmergenteAnadirPaciente control2 = new ControladorVentanaEmergenteAnadirPaciente();	//Creamos el controlador DE LA SEGUNDA VENTANA
			ControladorVentanaEmergenteAnadirPaciente.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaEmergenteAnadirPaciente.language = language;
			loader2.setController(control2);				//Al loader (FXML) le asignamoos su controlador			
			Parent root = loader2.load();				//Asignamos como root el fxml
			Stage miStage = new Stage();
			miStage.setScene(new Scene(root));		//El root pasa a ser una escena y la escena pasa a ser primaryStage
			miStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}


	}





}