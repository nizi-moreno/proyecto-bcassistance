package control;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;

public class ControladorEliminarPaciente {

	//En primer lugar, paso la credencial del usuario logeado.
	static CredencialUsuario UsuarioLogueado;

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="DNIncorrecto"
	private Label DNIncorrecto; // Value injected by FXMLLoader

	@FXML // fx:id="DNI"
	private JFXTextField DNI; // Value injected by FXMLLoader

	@FXML // fx:id="BotonEliminar"
	private JFXButton BotonEliminar; // Value injected by FXMLLoader
	static String language;
	@FXML
	static BorderPane panelInsertarApartado;

	private String panelactual = "Inicio";
	
	@FXML
	void PulsarEliminar(ActionEvent event) {
		ControladorBBDD BBDD=new ControladorBBDD();
		//Recogemos el rol del usuario logeado
		int rol = BBDD.devolverRol(UsuarioLogueado.getUsuario_dni());
		String DNIBorrar=DNI.getText();
		
		if(DNIBorrar!=null) {
		//Si es clinico
			if(rol==2) {	//Estamos borrando el clinico de un paciente
				BBDD.borrarClinicoDePaciente(DNIBorrar);
			}
		
		
		//Si es cuidador
			if(rol==1) {	//Estamos borrando de la tabla tiene
				BBDD.borrarRelacionPacienteCuidador(UsuarioLogueado.getUsuario_dni(), DNIBorrar);
			}
		}

		//Cerramos esta ventana emergente
		//Obtenemos la ventana sin dependencias y la cerramos
		Node n= (Node) event.getSource();
		Stage stage = (Stage) n.getScene().getWindow();
		stage.close();
		//Una vez se elimine le llevo a la p�gina del listado de pacientes del cl�nico:

		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/VentanaListadoPacientes.fxml"), bundle);
			ControladorVentanaListadoPacientes controlador1= new ControladorVentanaListadoPacientes();
			ControladorVentanaListadoPacientes.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaListadoPacientes.language=language;
			loader.setController(controlador1);
			Parent root;
			root = loader.load();
			panelInsertarApartado.setCenter(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
/* M�TODO ANTIGUO CON JSON
	@FXML
	void PulsarEliminar(ActionEvent event) {

		//En primer lugar creo el controlador de ficheros y los vectores de cl�nico, cuidador y pacientes
		ControladorFicherosJson controlador= new ControladorFicherosJson();

		/*Vector clinicos: Vector<Clinico> listaClinicos = new Vector<Clinico>();
		/*Vector cuidadores: Vector<Cuidador> listaCuidadores = new Vector<Cuidador>();
		/*Vector paicentes: Vector<Paciente> listaPacientes = new Vector<Paciente>();
/*
		//Deserializo todos los vectores para ver sus datos: 
		listaClinicos=controlador.deserializarJsonClinicosAArray();
		listaCuidadores=controlador.deserializarJsonCuidadoresAArray();
		listaPacientes= controlador.deserializarJsonPacientesAArray();

		//Hago la variable DNI
		String DNIPaciente= DNI.getText();

		//Encuentro las posiciones del cl�nico, cuidador y paciente
		int posicionClinico=buscarClinico(listaClinicos);
		int posicionCuidador=buscarCuidador(listaCuidadores);
		int posicionPaciente=buscarPaciente(listaPacientes, DNIPaciente);


		//Puede ser que sea un cl�nico o que sea un cuidador. En las b�squedas de posici�n hemos puesto que nos devuelva -1 en caso de no ser
		//o cl�nico o cuidador. Si nos devuelve -1 en paciente es porque el DNI no se ha encontrado en la lista de pacientes.
		if (posicionClinico!=-1 && posicionPaciente!=-1) {

			//Compruebo que ese paciente est� asociado a mi cl�nico
			if (comprobarClinicoAsociadoPaciente(listaClinicos.get(posicionClinico), DNIPaciente)) {
				//Busco la posici�n del paciente en la lista de pacientes del cl�nico: 
				int posicionPacienteClinico= buscarPacienteClinico(listaClinicos.get(posicionClinico).getPacientes_id(), DNIPaciente);

				System.out.println("Posici�n del cl�nico: "+ posicionClinico + "\nPosici�n del paciente: "+posicionPaciente + " " + DNIPaciente + 
						"\nPosici�n del paciente en la lista de pacientes del cl�nico: " + posicionPacienteClinico);

				//Eliminamos esa posicion de la lista
				listaClinicos.get(posicionClinico).getPacientes_id().remove(posicionPacienteClinico);
				System.out.println("Se ha eliminado el paciente correctamente");


				controlador.serializarArrayClinicosAJson(listaClinicos);

				//Desasociamos el clinico del paciente
				//En la posicion del paciente, le desasignamos el clinico
				listaPacientes.get(posicionPaciente).setClinico(null);
				System.out.println("Se ha desasociado el clinico del paciente");

				//Actualizamos el fichero de pacientes
				controlador.serializarArrayPacientesAJson(listaPacientes);

				//Cerramos esta ventana emergente
				//Obtenemos la ventana sin dependencias y la cerramos
				Node n= (Node) event.getSource();
				Stage stage = (Stage) n.getScene().getWindow();
				stage.close();
				//Una vez se elimine le llevo a la p�gina del listado de pacientes del cl�nico:

				try {
					Locale locale = new Locale(language);
					ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
					FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/VentanaListadoPacientes.fxml"), bundle);
					ControladorVentanaListadoPacientes controlador1= new ControladorVentanaListadoPacientes();
					ControladorVentanaListadoPacientes.UsuarioLogueado=UsuarioLogueado;
					ControladorVentanaListadoPacientes.language=language;
					loader.setController(controlador1);
					Parent root;
					root = loader.load();
					panelInsertarApartado.setCenter(root);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}  //Cierro el if de comprobar si el cl�nico esta asociado al paciente
			else {
				if (ControladorLogin.language.contentEquals("es_ES")) {
					DNIncorrecto.setText("Este DNI no corresponde a ning�n paciente");
				}
				else DNIncorrecto.setText("This IDN does not correspond to any patient");
			}

		}      //Cierro el if de en caso de ser clinico


		else if (posicionCuidador!=-1 && posicionPaciente!=-1) {

			//Compruebo que ese paciente est� asociado a mi cuidador
			if(comprobarCuidadorAsociadoPaciente(listaCuidadores.get(posicionCuidador), DNIPaciente)) {

				//Busco la posici�n del paciente en la lista de pacientes del cuidador:
				int posicionPacienteCuidador= buscarPacienteCuidador(listaCuidadores.get(posicionCuidador).getPacientes_id(), DNIPaciente);

				//Imprimo todo por pantalla para comprobar que funciona.
				System.out.println("Posici�n del cuidador: "+posicionCuidador + "\nPosici�n del paciente: "+posicionPaciente + " " + DNIPaciente + 
						"\nPosici�n del paciente en la lista de pacientes del cuidador: " + posicionPacienteCuidador);

				//Elimino el paciente de la lista de pacientes del cuidador
				listaCuidadores.get(posicionCuidador).remove(posicionPacienteCuidador);
				controlador.serializarArrayCuidadoresAJson(listaCuidadores);
				System.out.println("Se ha eliminado el paciente correctamente");

				//Cerramos esta ventana emergente
				//Obtenemos la ventana sin dependencias y la cerramos
				Node n= (Node) event.getSource();
				Stage stage = (Stage) n.getScene().getWindow();
				stage.close();
				//Una vez se elimine le llevo a la p�gina del listado de pacientes del cl�nico:

				try {
					Locale locale = new Locale(language);
					ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
					FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/VentanaListadoPacientes.fxml"), bundle);
					ControladorVentanaListadoPacientes controlador1= new ControladorVentanaListadoPacientes();
					ControladorVentanaListadoPacientes.UsuarioLogueado=UsuarioLogueado;
					ControladorVentanaListadoPacientes.language=language;
					loader.setController(controlador1);
					Parent root;
					root = loader.load();
					panelInsertarApartado.setCenter(root);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}  //Cierro el if de comprobar si el cl�nico esta asociado al paciente
			else {
				if (ControladorLogin.language.contentEquals("es_ES")) {
					DNIncorrecto.setText("Este DNI no corresponde a ning�n paciente");
				}
				else DNIncorrecto.setText("This IDN does not correspond to any patient");
			}
		}			


		else if (posicionPaciente==-1) {
			if (ControladorLogin.language.contentEquals("es_ES")) {
				DNIncorrecto.setText("Este DNI no corresponde a ning�n paciente");
			}
			else DNIncorrecto.setText("This IDN does not correspond to any patient");
		}

		System.out.println("Si hemos llegado a aqui es que todo va bien");
	}
*/

	//Busco la posici�n del cl�nico:
	int buscarClinico (Vector<Clinico> listaClinicos) {
		boolean encontrado=false;
		int posicion=-1;                   //Posici�n en la que se encuentra el cl�nico. Pongo -1 para que no se confunda con la posici�n 0 del vector
		int i=0;                           //int para recorrer el vector de cl�nicos

		while(i<listaClinicos.size() && !encontrado) {
			//En caso de que el dni del cl�nico sea el mismo que el del usuario logueado:
			if (listaClinicos.get(i).getCredencial().getUsuario_dni().equals(UsuarioLogueado.getUsuario_dni())) {
				encontrado=true;
				posicion=i;                //la posici�n del cl�nico

				//Imprimo el DNI para cerciorarme de que funciona:
				System.out.println("El clinico tiene DNI: "+ listaClinicos.get(i).getCredencial().getUsuario_dni());
			}
			//En caso de que no sea el paciente el usuario logueado:
			else {
				i++;	
			}
		} //Cirro el while

		if (posicion==-1) {
			i=posicion;
			System.out.println("No se trata de un cl�nico");
		}
		return posicion;
	}

	//Busco la posici�n del cuidador:
	int buscarCuidador (Vector<Cuidador> listaCuidadores) {
		boolean encontrado=false;
		int posicion=-1;	            //Posici�n en la que se encuentra el cuidadores. Pongo -1 para que no se confunda con la posici�n 0 del vector 	
		int i=0;                        //int para recorrer el vector de cuidadores

		while(i<listaCuidadores.size() && !encontrado) {
			//En caso de que el dni del cuidador sea el mismo que el del usuario logueado:
			if (listaCuidadores.get(i).getCredencial().getUsuario_dni().equals(UsuarioLogueado.getUsuario_dni())) {
				encontrado=true;
				posicion=i;             //la posici�n del cuidador

				//Imprimo el DNI para cerciorarme de que funciona:
				System.out.println("El cuidador tiene DNI: "+ listaCuidadores.get(i).getCredencial().getUsuario_dni());
			}
			//En caso de que no sea el paciente el usuario logueado:
			else {
				i++;	
			}
		} //Cirro el while

		if (posicion==-1) {
			System.out.println("No se trata de un cuidador");
		}
		return posicion;
	}

	//Busco la posici�n del paciente en una lista
	int buscarPaciente (Vector<Paciente> listaPacientes, String DNI) {
		boolean encontrado=false;
		int posicion=-1;                  //Posicion en la que se encuentra el paciente. Pongo -1 para que no se confunda con la posici�n 0 del vector
		int i=0;                          //int para recorrer el vector de pacientes    

		while(i<listaPacientes.size() && !encontrado) {
			//En caso de que el dni del paciente sea el mismo que el del usuario que quiero eliminar:
			if (listaPacientes.get(i).getCredencial().getUsuario_dni().equals(DNI)) {
				encontrado=true;
				posicion=i;               //posici�n del paciente

				//Imprimo el DNI para cerciorarme de que funciona:
				System.out.println("El paciente tiene DNI: "+ listaPacientes.get(i).getCredencial().getUsuario_dni());
			}
			else {
				i++;
			}
		} //Cirro el while
		return posicion;
	}

	int buscarPacienteClinico(Vector<String> listaPacientesdeClinico, String DNI) {
		boolean encontrado=false;
		int posicion=-1;                  //Posicion en la que se encuentra el paciente. Pongo -1 para que no se confunda con la posici�n 0 del vector
		int i=0;                          //int para recorrer el vector de pacientes del cuidador

		while(i<listaPacientesdeClinico.size() && !encontrado) {
			//En caso de que el dni del paciente sea el mismo que el del usuario que quiero eliminar:
			if (listaPacientesdeClinico.get(i).equals(DNI)) {
				encontrado=true;
				posicion=i;               //posici�n del paciente
			}
			else {
				i++;
			}
		} //Cirro el while
		return posicion;
	}

	int buscarPacienteCuidador (Vector<String> listaPacientesdeCuidador, String DNI) {
		boolean encontrado=false;
		int posicion=-1;                  //Posicion en la que se encuentra el paciente. Pongo -1 para que no se confunda con la posici�n 0 del vector
		int i=0;                          //int para recorrer el vector de pacientes del cuidador 

		while(i<listaPacientesdeCuidador.size() && !encontrado) {
			//En caso de que el dni del paciente sea el mismo que el del usuario que quiero eliminar:

			if (listaPacientesdeCuidador.get(i).equals(DNI)) {
				encontrado=true;
				posicion=i;               //posici�n del paciente

				//Imprimo el DNI para cerciorarme de que funciona:
				System.out.println("El paciente tiene DNI: "+ listaPacientesdeCuidador.get(i));
			}
			else {
				i++;
			}
		} //Cirro el while
		return posicion;
	}



	//Esta funcion nos devuelve true si el clinico tiene asociado a ese paciente:(i
	boolean comprobarClinicoAsociadoPaciente(Clinico clinico,String DNI) {
		boolean encontrado=false;
		//Imprimo cuando mide la lista de pacientes
		System.out.println("La lista de pacientes mide:"+clinico.getPacientes_id().size());
		if (clinico.getPacientes_id().contains(DNI)) {
			encontrado=true;
		}
		return encontrado;
	}

	//Esta funcion nos devuelve true si el cuidador tiene asociado a ese paciente:
	boolean comprobarCuidadorAsociadoPaciente(Cuidador cuidador,String DNI) {
		boolean encontrado=false;

		if(cuidador.getPacientes_id().contains(DNI)) {
			encontrado=true;	//Si el DNI coincide con uno que ya tiene el clinico, entonces ya esta escrito
		}

		return encontrado;
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert DNIncorrecto != null : "fx:id=\"DNIncorrecto\" was not injected: check your FXML file 'EliminarPaciente.fxml'.";
		assert DNI != null : "fx:id=\"DNI\" was not injected: check your FXML file 'EliminarPaciente.fxml'.";
		assert BotonEliminar != null : "fx:id=\"BotonEliminar\" was not injected: check your FXML file 'EliminarPaciente.fxml'.";

	}


	public String getPanelactual() {
		return panelactual;
	}


	public void setPanelactual(String panelactual) {
		this.panelactual = panelactual;
	}
}
