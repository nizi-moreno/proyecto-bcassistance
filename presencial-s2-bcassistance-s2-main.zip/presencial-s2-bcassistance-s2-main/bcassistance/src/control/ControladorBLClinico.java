package control;
import com.jfoenix.controls.JFXButton;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.Clinico;
import model.CredencialUsuario;
import model.Paciente;
import model.Usuario;

public class ControladorBLClinico {
	static CredencialUsuario UsuarioLogueado;
	static Clinico clinico;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private AnchorPane anchorPane;

	@FXML
	private ImageView imagenUsuario;

	@FXML
	private Label LabelRol;

	@FXML
	private Label nombreUsuario;

	@FXML
	private JFXButton botonCerrarSesion;

	@FXML
	private JFXButton botonPacientes;

	@FXML
	private JFXButton BotonComunicacion;

	@FXML
	private JFXButton botonPerfil;

	@FXML
	private ImageView idiomaSpanish;

	@FXML
	private ImageView idiomaEnglish;

	@FXML
	private BorderPane panelInsertarApartado;

	private String panelactual = "Inicio";

	static String language;

	private CheckEService<Clinico> checkEmergencia;

	//Esta es la ventana donde va TODO
	private Stage window;

	//Los handler de la barra

	public Stage getWindow() {
		return window;
	}

	public void setWindow(Stage window) {
		this.window = window;
	}

	@FXML
	void handleButtonCerrarSesion(ActionEvent event) {
		try {
			checkEmergencia.cancel();	//Se cierra el hilo al cerrar sesi�n
			Locale locale = new Locale("es_ES");
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);

			//Cargo la ruta del fxml de la p�gina de login:
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/GUI_Login.fxml"), bundle);
			ControladorLogin controlador1= new ControladorLogin();
			controlador1.indicarCierreSesion();
			controlador1.setWindow(window);
			loader.setController(controlador1);
			Parent root= loader.load();
			//Le asignamos al window su scene
			window.setScene(new Scene(root));
			window.show();
			System.out.println("Se ha cerrado sesion y el hilo de comprobar pacientes se ha cerrado");
			checkEmergencia.cancel();


		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonComunicacion(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Comunicacion"
		System.out.println("Comunicacion was clicked!");
		//Convierto el clinico en usuario generico para la venta de comunicacion
		Usuario usuario = new Usuario(clinico.getNombre(), clinico.getApellido1(), clinico.getApellido2(), UsuarioLogueado, 
				clinico.getFecha_nacimiento(), clinico.getTelefono(), clinico.getSexo());
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaPrincipalComunicacion.fxml"), bundle);
		ControladorVentanaPrincipalComunicacion c = new ControladorVentanaPrincipalComunicacion();
		ControladorVentanaPrincipalComunicacion.usuarioLogueado=UsuarioLogueado;
		ControladorVentanaPrincipalComunicacion.user=usuario;
		ControladorVentanaPrincipalComunicacion.language=language;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonPacientes(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Pacientes"
		System.out.println("Pacientes was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaListadoPacientes.fxml"), bundle);
		ControladorVentanaListadoPacientes c = new ControladorVentanaListadoPacientes();
		ControladorVentanaListadoPacientes.UsuarioLogueado=UsuarioLogueado;
		ControladorVentanaListadoPacientes.language=language;
		ControladorVentanaListadoPacientes.panelInsertarApartado= panelInsertarApartado;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			setPanelactual("Pacientes");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	void handleButtonPerfil(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Pacientes"
		System.out.println("Perfil was clicked!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/PerfilClinico.fxml"), bundle);
		ControladorPerfilClinico c = new ControladorPerfilClinico();
		ControladorPerfilClinico.language=language;
		c.setControladroBL(this);
		ControladorPerfilClinico.clinico = clinico;
		ControladorPerfilClinico.UsuarioLogueado= UsuarioLogueado;
		ControladorPerfilClinico.bl=this;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			setPanelactual("Perfil");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void setLabelNombre() {
		nombreUsuario.setText(clinico.getNombre() + " " + clinico.getApellido1());
	}

	void revisarEmergencias() {
		ControladorBBDD cBBDD = new ControladorBBDD();

		//REVISAR SI HAY EMERGENCIAS
		checkEmergencia = new CheckEService<Clinico>(clinico);
		checkEmergencia.setPeriod(Duration.seconds(100));
		checkEmergencia.setOnSucceeded(e -> {
			Paciente paciente_e = (Paciente) checkEmergencia.getValue();
			if (paciente_e!=null && !paciente_e.getEmergencia().isReporte_clinico()) {
				System.out.println("Paciente es " + paciente_e.getNombre() );
				mostrarEmergenteEmergenciaC(paciente_e);
				paciente_e.getEmergencia().setReporte_clinico(true);
				//Actualiza el estado de emergencia a false si ya se report� a todos
				if (paciente_e.getEmergencia().isReportado()) {paciente_e.setEstado(false);}
				//Guardar en la BBDD que se reporto
				cBBDD.actualizarReporteEmergencia(paciente_e.getEmergencia().getID_Lectura(), clinico.getCredencial().getRol());
				//HABRIA QUE HACER ESTA PARTE EN LA BBDD
			}

		});
		checkEmergencia.setOnFailed(e -> {System.out.println("Hubo un error con el check");});
		checkEmergencia.start();

	}

	public void mostrarEmergenteEmergenciaC(Paciente paciente) {
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			//Cargo la ruta del fxml del GUI:
			FXMLLoader loader2= new FXMLLoader (getClass().getResource("/view/VentanaEmergenteEmergenciaC.fxml"), bundle);
			ControladorVentanaEmergenteEmergenciaC controlador2= new ControladorVentanaEmergenteEmergenciaC();
			ControladorVentanaEmergenteEmergenciaC.paciente= paciente;
			ControladorVentanaEmergenteEmergenciaC.language= language;
			ControladorVentanaEmergenteEmergenciaC.UsuarioLogueado=UsuarioLogueado;
			controlador2.setPanelInsertarApartado(panelInsertarApartado);
			loader2.setController(controlador2);
			Parent root= loader2.load();
			//Le asignamos al window su scene
			Stage miStage = new Stage();
			miStage.setScene(new Scene(root));
			miStage.setTitle("Emergencia Paciente");
			Image icono=new Image("./Imagenes/logonegro.png");
			miStage.getIcons().add(icono);
			//Para que no se pueda usar la ventana padre
			miStage.initModality(Modality.WINDOW_MODAL);
			miStage.initOwner(botonCerrarSesion.getScene().getWindow());
			miStage.show();
			controlador2.LabelMensaje();
			controlador2.LabelUbicacion();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	@FXML
	void initialize() {
		assert anchorPane != null : "fx:id=\"anchorPane\" was not injected: check your FXML file 'VentanaClinico.fxml'.";
		assert imagenUsuario != null : "fx:id=\"imagenUsuario\" was not injected: check your FXML file 'VentanaClinico.fxml'.";
		assert nombreUsuario != null : "fx:id=\"nombreUsuario\" was not injected: check your FXML file 'VentanaClinico.fxml'.";
		assert botonCerrarSesion != null : "fx:id=\"botonCerrarSesion\" was not injected: check your FXML file 'VentanaClinico.fxml'.";
		assert botonPacientes != null : "fx:id=\"botonPacientes\" was not injected: check your FXML file 'VentanaClinico.fxml'.";
		assert BotonComunicacion != null : "fx:id=\"BotonComunicacion\" was not injected: check your FXML file 'VentanaClinico.fxml'.";
		assert botonPerfil != null : "fx:id=\"botonPerfil\" was not injected: check your FXML file 'VentanaClinico.fxml'.";
		assert panelInsertarApartado != null : "fx:id=\"panelInsertarApartado\" was not injected: check your FXML file 'VentanaClinico.fxml'.";
		//Comprobamos si estan los pacientes dados de alta
		comprobarAltaDePacientesClinico();
		//para que se vea el nombre jeje :) -Sol
		setLabelNombre();
		revisarEmergencias();
		//Cargamos la imagen de perfil
		actualizarImagenPerfil();
		//Cargamos la pantalla de pacientes por defecto
		System.out.println("Showing Pacientes!");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaListadoPacientes.fxml"), bundle);
		ControladorVentanaListadoPacientes c = new ControladorVentanaListadoPacientes();
		ControladorVentanaListadoPacientes.UsuarioLogueado=UsuarioLogueado;
		ControladorVentanaListadoPacientes.language=language;
		ControladorVentanaListadoPacientes.panelInsertarApartado= panelInsertarApartado;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			setPanelactual("Pacientes");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void actualizarImagenPerfil() {
		//Cargamos la imagen de perfil (si tiene una)
	
		try{
			ControladorBBDD cBBDD = new ControladorBBDD();
			Image imagen = cBBDD.getFotoPerfil(clinico.getCredencial().getUsuario_dni());
			if(imagen!=null) {
				imagenUsuario.setImage(imagen);
			}
		}catch (Exception e) {
			//No tiene imagen de perfil
			
		}
	}

	public void comprobarAltaDePacientesClinico() {

		//HAY QUE HACER ESTA PARTE PERO CON LA BBDD

		/*ControladorFicherosJson c=new ControladorFicherosJson();
		//Ahora actualizamos el JSON
		Vector<Clinico> listaClinicos=new Vector<Clinico>();
		listaClinicos=c.deserializarJsonClinicosAArray();

		for(int e=0;e<listaClinicos.size();e++){
			if(listaClinicos.elementAt(e).getCredencial().getUsuario_dni().equals(clinico.getCredencial().getUsuario_dni())) {	//Si coincide el DNI del clinico (Lo hemos encontrado en la lista del fichero)
				for(int i=0;i<listaClinicos.elementAt(e).getPacientesID().size();i++) {	//Recorremos su lista de pacientes 
					if(!listaClinicos.elementAt(e).getPacientesID().elementAt(i).getCredencial().isAlta()) {	//Si est� dado de baja lo borramos
						listaClinicos.elementAt(e).getPacientesID().remove(i);	//Lo borramos
						clinico.getPacientesID().remove(i);	//Lo borramos tambi�n del objeto de la clase
					}

				}
			}
		}
		//Una vez recorridos todos, vamos a actualizar el json
		c.serializarArrayClinicosAJson(listaClinicos);*/
	}

	public String getPanelactual() {
		return panelactual;
	}

	public void setPanelactual(String panelactual) {
		this.panelactual = panelactual;
	}

	public void actualizarDatosUsuario() {
		actualizarImagenPerfil();
		setLabelNombre();
	}



}

