package control;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
//import java.awt.Label;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.text.Text;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.Callcenter;
import model.Clinico;
import model.CredencialUsuario;
import model.Cuidador;
import model.Paciente;
import model.Usuario;

public class ControladorLogin {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="Password"
	private JFXPasswordField Password; // Value injected by FXMLLoader

	@FXML // fx:id="Usuario"
	private JFXTextField Usuario; // Value injected by FXMLLoader

	@FXML // fx:id="Iniciar_sesion"
	private JFXButton Iniciar_sesion; // Value injected by FXMLLoader

	@FXML // fx:id="Errorcredenciales"
	private Text Errorcredenciales; // Value injected by FXMLLoader

	@FXML // fx:id="Olvidar_Contrasena"
	private Hyperlink Olvidar_Contrasena; // Value injected by FXMLLoader

	@FXML // fx:id="Registrarse"
	private JFXButton Registrarse; // Value injected by FXMLLoader

	@FXML // fx:id="labelb"
	private Label labelb; // Value injected by FXMLLoader

	@FXML // fx:id="labeld"
	private Label labeld; // Value injected by FXMLLoader

	@FXML // fx:id="labelb"
	private Label labelLogin; // Value injected by FXMLLoader

	static String language="es_ES";

	private boolean cierreSesion=false;	//Si es true, quiere decir que acabamos de cerrar sesi�n. Este atributo se actualiza SOLO cuando se llama a la ventana tras cerrar sesi�n.

	//Esta es la ventana donde va TODO
	private Stage window;


	//Getters y setters
	public Stage getWindow() {
		return window;
	}

	public void setWindow(Stage window) {
		this.window = window;
	}

	public boolean isCierreSesion() {
		return cierreSesion;
	}

	public void setCierreSesion(boolean cierreSesion) {
		this.cierreSesion = cierreSesion;
	}

	//Indicar cierre de sesi�n
	public void indicarCierreSesion() {
		this.cierreSesion = true;
	}

	//Para los idiomas
	public void click_en() {
		language="en_US";
		loadLang(language);
	}

	public void click_es() {
		language="es_ES";
		loadLang(language);
	}

	private void loadLang(String lang) {
		Locale location = new Locale(lang);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", location);

		Password.setPromptText(bundle.getString("contrasena"));
		Usuario.setPromptText(bundle.getString("usuario"));
		Iniciar_sesion.setText(bundle.getString("login"));
		Olvidar_Contrasena.setText(bundle.getString("recuperar"));
		Registrarse.setText(bundle.getString("registrarse"));
		labelb.setText(bundle.getString("bienvenido"));
		labeld.setText(bundle.getString("descripcion"));
		labelLogin.setText(bundle.getString("login"));

	}

	@FXML
	void BotonIniciarSesion(ActionEvent event) {
		System.out.println("INICIO CON LOGIN OPTIMIZADO");

		//Deserializo los usuarios y los meto en un vector usuario	
		ControladorBBDD cBBDD = new ControladorBBDD();
		String passwordNoEncriptada = Password.getText();
		String dni= Usuario.getText();
		
		//Recogemos el rol
		//Si nos devuelve null es xq no existe
		Usuario usuarioLogeando = cBBDD.loginOptimizado2(dni, passwordNoEncriptada);
		CredencialUsuario CredencialLogueada=null;
		if(usuarioLogeando!=null) {
			CredencialLogueada=usuarioLogeando.getCredencial(); 
		}

		
		
			//Si el usuario existe y esta dado de alta lo logeamos
			if(usuarioLogeando!=null && usuarioLogeando.getCredencial().isAlta()==true) {
				
				if(CredencialLogueada.isAlta()==true) {
					//Abrimos el menu del usuario
					//0: paciente, 1:cuidador, 2:clinico, 3:callcenter
					if(CredencialLogueada.getRol()==2) {
						//Te lleva a la interfaz grafica del clinico
						try {

							Clinico clinico = cBBDD.BuscarClinico(CredencialLogueada.getUsuario_dni());

							Locale locale = new Locale(language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/BarraLateralClinico.fxml"), bundle);
							ControladorBLClinico.language=language;
							ControladorBLClinico controlador1= new ControladorBLClinico();
							controlador1.setWindow(window);	//Pasamos la ventana donde va todo
							ControladorBLClinico.UsuarioLogueado=CredencialLogueada;
							ControladorBLClinico.clinico = clinico;
							loader.setController(controlador1);
							Parent root;
							root = loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);


						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
					else if(CredencialLogueada.getRol()==1) {

						//Te lleva a la interfaz grafica del Cuidador
						try {

							Cuidador cuidador = cBBDD.BuscarCuidador(CredencialLogueada.getUsuario_dni());

							//Cargar la interfaz
							Locale locale = new Locale(language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/BarraLateralCuidador.fxml"), bundle);
							ControladorBLCuidador controlador1= new ControladorBLCuidador();
							loader.setController(controlador1);
							controlador1.setWindow(window);
							ControladorBLCuidador.UsuarioLogueado=CredencialLogueada;
							ControladorBLCuidador.cuidador=cuidador;
							ControladorBLCuidador.language=language;
							Parent root;
							root = loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);

						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else if(CredencialLogueada.getRol()==0) {
						//Te lleva a la interfaz grafica del Paciente	
						try {
							//Hacemos una solicitud a la base de datos para que nos devuelva la info del paciente

							Paciente paciente = cBBDD.BuscarPaciente(CredencialLogueada.getUsuario_dni());

							//Cargamos su barra lateral	
							Locale locale = new Locale(language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/BarraLateralPaciente.fxml"), bundle);
							ControladorBLPaciente controlador1= new ControladorBLPaciente();
							loader.setController(controlador1);
							controlador1.setWindow(window);	//Pasamos la ventana donde va todo
							ControladorBLPaciente.UsuarioLogueado=CredencialLogueada;
							ControladorBLPaciente.language=language;
							ControladorBLPaciente.paciente=paciente;
							Parent root;
							root = loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else if (CredencialLogueada.getRol()==3){
						//Te lleva a la interfaz grafica del call center
						try {

							Callcenter callcenter = cBBDD.BuscarCallcenter(CredencialLogueada.getUsuario_dni());

							//Cargamos su barra lateral

							Locale locale = new Locale(language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/BarraLateralCallCenter.fxml"), bundle);
							ControladorBLCallCenter controlador1= new ControladorBLCallCenter();
							controlador1.setWindow(window);	//Pasamos la ventana donde va todo
							ControladorBLCallCenter.UsuarioLogueado=callcenter;
							ControladorBLCallCenter.language=language;
							loader.setController(controlador1);
							Parent root;
							root = loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				else {
					if (language.contentEquals("es_ES")) {Errorcredenciales.setText("Error: Usuario dado de baja");}
					else {Errorcredenciales.setText("Error: Unsubscribed user");}

				}
			}

		
			//Si es null entonces es incorrecto
		if(usuarioLogeando==null) {
			if (language.contentEquals("es_ES")) {Errorcredenciales.setText( "Error: credenciales incorrectas");}
			else {Errorcredenciales.setText( "Error: Incorrect credentials");}
		}

	}
	/*
	@FXML
	void BotonIniciarSesionAntiguo(ActionEvent event) {

		//Con un bucle buscamos la contrase�a y usuario
		boolean acceso=false;
		int i=0;

		//Deserializo los usuarios y los meto en un vector usuario	
		ControladorBBDD cBBDD = new ControladorBBDD();
		Vector<Usuario> listaUsuarios = cBBDD.devolverTodosUsuarios();
		String password = Password.getText();
		String usuario= Usuario.getText();

		while(i< listaUsuarios.size() && !acceso) {

			if(usuario.equals(listaUsuarios.get(i).getCredencial().getUsuario_dni()) &&
					password.equals(listaUsuarios.get(i).getCredencial().getContrasena())) {

				acceso=true;
				//Cuando contrase�a y DNI coinciden, almacenamos la credencial que se va a logear
				CredencialUsuario CredencialLogueada=listaUsuarios.get(i).getCredencial(); 

				if(CredencialLogueada.isAlta()==true) {
					//Abrimos el menu del usuario
					//0: paciente, 1:cuidador, 2:clinico, 3:callcenter
					if(listaUsuarios.get(i).getCredencial().getRol()==2) {
						//Te lleva a la interfaz grafica del clinico
						try {

							Clinico clinico = cBBDD.BuscarClinico(CredencialLogueada.getUsuario_dni());

							Locale locale = new Locale(language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/BarraLateralClinico.fxml"), bundle);
							ControladorBLClinico.language=language;
							ControladorBLClinico controlador1= new ControladorBLClinico();
							controlador1.setWindow(window);	//Pasamos la ventana donde va todo
							ControladorBLClinico.UsuarioLogueado=CredencialLogueada;
							ControladorBLClinico.clinico = clinico;
							loader.setController(controlador1);
							Parent root;
							root = loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);


						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
					else if(listaUsuarios.get(i).getCredencial().getRol()==1) {

						//Te lleva a la interfaz grafica del Cuidador
						try {

							Cuidador cuidador = cBBDD.BuscarCuidador(CredencialLogueada.getUsuario_dni());

							//Cargar la interfaz
							Locale locale = new Locale(language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/BarraLateralCuidador.fxml"), bundle);
							ControladorBLCuidador controlador1= new ControladorBLCuidador();
							loader.setController(controlador1);
							controlador1.setWindow(window);
							ControladorBLCuidador.UsuarioLogueado=CredencialLogueada;
							ControladorBLCuidador.cuidador=cuidador;
							ControladorBLCuidador.language=language;
							Parent root;
							root = loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);

						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else if(listaUsuarios.get(i).getCredencial().getRol()==0) {
						//Te lleva a la interfaz grafica del Paciente	
						try {
							//Hacemos una solicitud a la base de datos para que nos devuelva la info del paciente

							Paciente paciente = cBBDD.BuscarPaciente(CredencialLogueada.getUsuario_dni());

							//Cargamos su barra lateral	
							Locale locale = new Locale(language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/BarraLateralPaciente.fxml"), bundle);
							ControladorBLPaciente controlador1= new ControladorBLPaciente();
							loader.setController(controlador1);
							controlador1.setWindow(window);	//Pasamos la ventana donde va todo
							ControladorBLPaciente.UsuarioLogueado=CredencialLogueada;
							ControladorBLPaciente.language=language;
							ControladorBLPaciente.paciente=paciente;
							Parent root;
							root = loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else if (listaUsuarios.get(i).getCredencial().getRol()==3){
						//Te lleva a la interfaz grafica del call center
						try {

							Callcenter callcenter = cBBDD.BuscarCallcenter(CredencialLogueada.getUsuario_dni());

							//Cargamos su barra lateral

							Locale locale = new Locale(language);
							ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
							FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/BarraLateralCallCenter.fxml"), bundle);
							ControladorBLCallCenter controlador1= new ControladorBLCallCenter();
							controlador1.setWindow(window);	//Pasamos la ventana donde va todo
							ControladorBLCallCenter.UsuarioLogueado=callcenter;
							ControladorBLCallCenter.language=language;
							loader.setController(controlador1);
							Parent root;
							root = loader.load();
							Scene scene1 = new Scene(root);
							Main.window.setScene(scene1);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				else {
					if (language.contentEquals("es_ES")) {Errorcredenciales.setText("Error: Usuario dado de baja");}
					else {Errorcredenciales.setText("Error: Unsubscribed user");}

				}
			}
			i++;
		} //CIERRE WHILE

		if(acceso==false && i== listaUsuarios.size()) {
			if (language.contentEquals("es_ES")) {Errorcredenciales.setText( "Error: credenciales incorrectas");}
			else {Errorcredenciales.setText( "Error: Incorrect credentials");}

			i=0;
		}

	}
	*/
	
	@FXML
	void ContrasenaOlvidada(ActionEvent event) {

		//Cargo la ruta del fxml del GUI:
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader= new FXMLLoader(getClass().getResource("/view/RecuperarContrasena.fxml"), bundle);
			ControladorOlvidarContrasena controladorContrasena= new ControladorOlvidarContrasena();

			loader.setController(controladorContrasena);
			Parent root= loader.load();
			Scene scene1 = new Scene(root);
			Main.window.setScene(scene1);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void PaginaResgistro(ActionEvent event) {

		//Cargo la ruta del fxml del GUI:
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/Registro.fxml"), bundle);
			ControladorRegistro controladorRegistro= new ControladorRegistro();
			loader.setController(controladorRegistro);

			Parent root= loader.load();
			Scene scene1 = new Scene(root);
			Main.window.setScene(scene1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert Password != null : "fx:id=\"Password\" was not injected: check your FXML file 'GUI_Login.fxml'.";
		assert Usuario != null : "fx:id=\"Usuario\" was not injected: check your FXML file 'GUI_Login.fxml'.";
		assert Iniciar_sesion != null : "fx:id=\"Iniciar_sesion\" was not injected: check your FXML file 'GUI_Login.fxml'.";
		assert Olvidar_Contrasena != null : "fx:id=\"Olvidar_Contrasena\" was not injected: check your FXML file 'GUI_Login.fxml'.";
		assert Registrarse != null : "fx:id=\"Registrarse\" was not injected: check your FXML file 'GUI_Login.fxml'.";

		try {
			if(cierreSesion && !language.contentEquals("es_ES")) Errorcredenciales.setText("Your session is now closed ");
			else if(cierreSesion && language.contentEquals("es_ES")) Errorcredenciales.setText("Se ha abandonado la sesion");
		}catch(Exception e) {
			System.out.println("No se leer tildes en el Text del login :(");
		}

	}




}