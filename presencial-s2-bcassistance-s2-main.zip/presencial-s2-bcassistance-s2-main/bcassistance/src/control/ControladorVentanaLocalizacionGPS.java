package control;

import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import com.jfoenix.controls.JFXButton;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import model.CredencialUsuario;
import model.Location;
import model.Paciente;

public class ControladorVentanaLocalizacionGPS {

	@FXML
	private Label tituloLocalizacion;

	@FXML
	private Label DescripcionApartado;

	@FXML
	private BorderPane borderPaneInsertarApartado;

	@FXML
	private TableView<Location> tableViewRegistro;

	@FXML
	private TableColumn<Location, String> tableColumnRegistros;

	@FXML
	private JFXButton botonMostrar;

	@FXML
	private Label labelDireccion;

	@FXML
	private JFXButton botonVolver;

	@FXML
	private Label labelErrores;

	static String language;

	static CredencialUsuario usuarioLogueado;

	static Paciente paciente;

	static BorderPane panelBL;
	
	@FXML
	void handleBotonMostrar(ActionEvent event) {
		//Comprobariamos si se ha seleccionado un registro y mostrariamos el correspondiente mapa
		if(checkSelection()) {
			Location selected = tableViewRegistro.getSelectionModel().getSelectedItem();
			mostrarMapa(selected);
		}
	}

	@FXML
	void handleBotonVolver(ActionEvent event) {
		//Volvemos a la ficha de paciente
		try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader= new FXMLLoader (getClass().getResource("/view/VentanaFichaPaciente.fxml"), bundle);
			ControladorVentanaFichaPaciente control2= new ControladorVentanaFichaPaciente();
			control2.setPanelInsertarApartado(panelBL);
			ControladorVentanaFichaPaciente.paciente=paciente;	
			ControladorVentanaFichaPaciente.UsuarioLogueado= usuarioLogueado;
			ControladorVentanaFichaPaciente.language = language;
			loader.setController(control2);				//Al loader (FXML) le asignamoos su controlador			
			Parent root = loader.load();				//Asignamos como root el fxml
			panelBL.setCenter(root);
			//panelactual = "Pacientes";

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	/*
	@FXML
	void handleObtenerUbicacionActual(ActionEvent event) {
		//Obtendriamos la ubicacion del sensor y mostrariamos el correspondiente mapa

		//De momento, creo este vector con  distintas coordenadas y con un numero aleatorio, sacamos una de ellas
		Vector<Location> localizaciones = new Vector<>();

		Date fecha = new Date();

		localizaciones.add(new Location(40.4165, -3.70256, fecha));
		localizaciones.add(new Location(40.38897, -3.74569, fecha));
		localizaciones.add(new Location(40.39354, -3.662, fecha));
		localizaciones.add(new Location(40.3571, -3.90059, fecha));
		localizaciones.add(new Location(40.5474600, -3.6419700, fecha));

		int numRandom =(int) (Math.random() * 4) + 0;

		double latitud=localizaciones.get(numRandom).getLatitud();
		double longitud=localizaciones.get(numRandom).getLongitud();

		//Creamos la nueva localizacion
		Location location= new Location(latitud,longitud,fecha);

		//La aniadimos al registro del paciente
		
		//Guardamos los datos en el fichero
		

		//HAY QUE HACERLO CON LA BBDD

		//Actualizamos los datos del paciente que usamos en esta ventana
		paciente.addLocation(location);

		//Actualizamos el listado de registros (listView)
		rellenarLista();

		//Mostramos esta ubicacion en el mapa
		mostrarMapa(location);

	}*/


	public void mostrarMapa(Location location) {

		double latitud = location.getLatitud();
		double longitud = location.getLongitud();


		WebView myWebView = new WebView();
		
		WebEngine engine = myWebView.getEngine();
		
		String url = "https://maps.googleapis.com/maps/api/staticmap?center="+latitud+","+longitud+"&zoom=18&scale=1&size=740x400&maptype=roadmap&key="+Main.GOOGLE_API_KEY+"&format=png&visual_refresh=true&markers=size:mid%7Ccolor:0xff0000%7Clabel:L%7C"+latitud+","+longitud;
		engine.load(url);
		
		//Aniadimos el browserView en el bordePaneInsertarApartado
		borderPaneInsertarApartado.setCenter(myWebView);

		//Le mostramos la direccion de la ubicacion y la fecha
		labelDireccion.setText(location.getFechaEscrita()+" - "+"Direcci�n: "+location.getDireccion());

	}

	void mostrarUltimaLocalizacion() {

		//Comprobamos que tenga algun registro...
		if(!paciente.getRegistroLocalizaciones().isEmpty()) {
			Location ultLocation = paciente.getRegistroLocalizaciones().get(paciente.getRegistroLocalizaciones().size()-1);
			mostrarMapa(ultLocation);
		}

	}

	public boolean checkSelection() {
		boolean apto = false;
		//Si se ha seleccionado un item
		if(!tableViewRegistro.getSelectionModel().getSelectedItems().isEmpty()) {
			apto=true;
		}else {
			//Le decimos al usuario que hace falta que seleccione el destinatario
			if (language.equals("es_ES")) {
				labelErrores.setText("ERROR: debe seleccionar un registro de la lista.");
			} else {
				labelErrores.setText("ERROR: You must select a register from the list.");
			}
		}
		return apto;
	}
	
	//Antiguo con JSON
	void rellenarLista() {
		ControladorBBDD cBBDD=new ControladorBBDD();
		paciente.getRegistroLocalizaciones().clear();
		cBBDD.actualizarLocalizacion(paciente);
		//Accedemos a su lista de registro de localizaciones
		//Guardamos en un array especial los elementos
		ObservableList<Location> registroLocalizaciones = paciente.devolverRegistroLocalizaciones();
		
		//Asignamos valores a nuestras columnas
		tableColumnRegistros.setCellValueFactory(new PropertyValueFactory<Location, String>("fechaEscrita"));
		//Cargamos la informacion en nuestra tabla
		tableViewRegistro.setItems(registroLocalizaciones);
		if (language.contentEquals("es_ES")) {
			tableViewRegistro.setPlaceholder(new Label("No dispone de agenda de registros."));
		} else {tableViewRegistro.setPlaceholder(new Label("Does not have a schedule of locations."));}

	}

	@FXML
	void initialize() {
		assert tituloLocalizacion != null : "fx:id=\"tituloLocalizacion\" was not injected: check your FXML file 'VentanaLocalizacionGPS.fxml'.";
		assert DescripcionApartado != null : "fx:id=\"DescripcionApartado\" was not injected: check your FXML file 'VentanaLocalizacionGPS.fxml'.";
		assert borderPaneInsertarApartado != null : "fx:id=\"borderPaneInsertarApartado\" was not injected: check your FXML file 'VentanaLocalizacionGPS.fxml'.";
		assert tableViewRegistro != null : "fx:id=\"tableViewRegistro\" was not injected: check your FXML file 'VentanaLocalizacionGPS.fxml'.";
		assert tableColumnRegistros != null : "fx:id=\"tableColumnRegistros\" was not injected: check your FXML file 'VentanaLocalizacionGPS.fxml'.";
		assert botonMostrar != null : "fx:id=\"botonMostrar\" was not injected: check your FXML file 'VentanaLocalizacionGPS.fxml'.";
		assert botonVolver != null : "fx:id=\"botonVolver\" was not injected: check your FXML file 'VentanaLocalizacionGPS.fxml'.";

		
		//Rellenamos la lista del registros
		rellenarLista();

		//Por defecto mostraremos la ultima localizacion disponible
		mostrarUltimaLocalizacion();

		//Deshabilitamos el boton de atras si el usuario logueado es un paciente
		if(usuarioLogueado.getRol()==0) {
			botonVolver.setVisible(false);
		}


	}
}
