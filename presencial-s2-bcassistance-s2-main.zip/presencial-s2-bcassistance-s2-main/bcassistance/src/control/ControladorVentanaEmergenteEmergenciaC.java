package control;

import java.util.Locale;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.CredencialUsuario;
import model.Paciente;


public class ControladorVentanaEmergenteEmergenciaC {

	static Paciente paciente = new Paciente("", "", "", null, null, 0, false); 
	static CredencialUsuario UsuarioLogueado;
	
    @FXML
    private ImageView image;

    @FXML
    private Label labelemergencia;

    @FXML
    private Label labelmensaje;
    
    @FXML
    private Label labelUbicacion;

    @FXML
    private Button botonok;

    @FXML
    private Button botonverp;
    
    static String language = "es_ES";

    private BorderPane panelInsertarApartado;
	
	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}

	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}
    
    @FXML
    void Cerrar(ActionEvent event) {
        Stage stage = (Stage) botonok.getScene().getWindow();
        stage.close();
    }

    @FXML
    void VerPaciente(ActionEvent event) {
    	try {
			Locale locale = new Locale(language);
			ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
			FXMLLoader loader3 = new FXMLLoader(getClass().getResource("/view/VentanaFichaPaciente.fxml"), bundle);	//Importamos el fxml de la segunda ventana
			ControladorVentanaFichaPaciente control2 = new ControladorVentanaFichaPaciente();	//Creamos el controlador DE LA SEGUNDA VENTANA
			control2.setPanelInsertarApartado(panelInsertarApartado);
			ControladorVentanaFichaPaciente.paciente=paciente;
			ControladorVentanaFichaPaciente.UsuarioLogueado=UsuarioLogueado;
			ControladorVentanaFichaPaciente.language = language;
			loader3.setController(control2);				//Al loader (FXML) le asignamoos su controlador			
			Parent root = loader3.load();				//Asignamos como root el fxml

			panelInsertarApartado.setCenter(root);
			//panelactual = "Pacientes";
			
			Stage stage = (Stage) botonok.getScene().getWindow();
	        stage.close();

		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    
    void LabelMensaje() {
    	if (language.equals("es_ES")) {
    		labelmensaje.setText("Se ha detectado que el paciente "+ paciente.getNombre() + " " + paciente.getApellido1() 
    		+ " " + paciente.getApellido2() + " ha sufrido una emergencia.");
    	} else {
    		labelmensaje.setText("It has been detected that the pacient "+ paciente.getNombre() + " " + paciente.getApellido1() 
    		+ " " + paciente.getApellido2() + " has suffered an accident.");
    	}
    				
    }
    
    void LabelUbicacion() {
    	if (language.equals("es_ES")) {
    		labelUbicacion.setText("UBICACION: "+ paciente.getEmergencia().getLongitud() + ", " + paciente.getEmergencia().getLatitud() );
    	} else {
    		labelUbicacion.setText("LOCATION: "+ paciente.getEmergencia().getLongitud() + ", " + paciente.getEmergencia().getLatitud() );
    	}
    }

}