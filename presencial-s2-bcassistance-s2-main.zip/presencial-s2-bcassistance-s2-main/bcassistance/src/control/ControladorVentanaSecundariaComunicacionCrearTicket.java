package control;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import model.Clinico;
import model.Mensaje;
import model.Paciente;
import model.Ticket;
import model.Usuario;

public class ControladorVentanaSecundariaComunicacionCrearTicket {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Label labelTituloAbrirNuevoTicket;

	@FXML
	private JFXButton botonCancelar;

	@FXML
	private JFXButton botonAceptar;

	@FXML
	private TableView<Usuario> tableListadoUsuarios;

	@FXML
	private TableColumn<Usuario, String> columnaListadoDeUsuarios;

	@FXML
	private Label labelAsunto;

	@FXML
	private JFXTextField textFieldAsunto;

	@FXML
	private Label labelMensajeInicial;

	@FXML
	private JFXTextArea textAreaMensajeInicial;

	@FXML
	private Label labelAvisoLongitudAsunto;

	@FXML
	private Label labelAvisoTableView;

	@FXML
	private Label labelAvisoLongitudMensaje;

	static BorderPane panelInsertarApartado;

	static Usuario usuarioLogueado;

	static String language;

	static Vector<String> listadoUsuarios;

	@FXML
	void handleBotonCancelar(ActionEvent event) {
		//Volvemos al panel de Gestion de Tickets
		volverPantallaGestionTickets();
	}

	void volverPantallaGestionTickets() {
		//Hacemos que se pueda volver de Crear ticket a gestion de tickets
		//Conectamos esta ventana con la VentanaSecundariaComunicacionGestionTickets
		System.out.println("Mostrando la ventana de gestion de tickets");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaSecundariaComunicacionGestionTickets.fxml"), bundle);
		ControladorVentanaSecundariaComunicacionGestionTickets c = new ControladorVentanaSecundariaComunicacionGestionTickets();
		ControladorVentanaSecundariaComunicacionGestionTickets.usuarioLogueado=usuarioLogueado;
		ControladorVentanaSecundariaComunicacionGestionTickets.language=language;
		ControladorVentanaSecundariaComunicacionGestionTickets.panelInsertarApartado=panelInsertarApartado;
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void handleBotonCrearTicket(ActionEvent event) {
		//Limpiamos los avisos anteriores
		limpiarAvisos();
		//Verificamos que todos los campos son correctos
		if(verificarCamposCrearTicket()) {

			//Creamos el mensaje
			String DNIemisor=usuarioLogueado.getCredencial().getUsuario_dni();
			Mensaje mensaje = new Mensaje(textAreaMensajeInicial.getText(), null, DNIemisor);

			//Creamos el ticket con el mensaje 
			String DNIreceptor= tableListadoUsuarios.getSelectionModel().getSelectedItem().getCredencial().getUsuario_dni();
			Ticket ticket = new Ticket(textFieldAsunto.getText(), mensaje, null, usuarioLogueado.getCredencial().getUsuario_dni(), DNIreceptor);

			//Subimos el ticket a la base de datos
			ControladorBBDD cBBDD= new ControladorBBDD();
			cBBDD.insertarTicket(ticket);
			
			//Finalmente, volvemos a la ventana de gestion de tickets
			volverPantallaGestionTickets();
			System.out.println("El ticket se ha creado con exito!");
		}
	}

	public void limpiarAvisos() {
		labelAvisoLongitudAsunto.setText("");
		labelAvisoLongitudMensaje.setText("");
		labelAvisoTableView.setText("");
	}

	public boolean verificarCamposCrearTicket() {
		boolean correcto= false;
		//Si algun campo es erroneo, modificaremos los labels de la ventana, para avisar al usuario (ya se hace en los metodos que llamamos)
		//Verificamos si se ha seleccionado a un usuario del tableView
		ckeckSelection();
		comprobarLongitudMensaje();
		comprobarLongitudAsunto();
		if(ckeckSelection() && comprobarLongitudMensaje() && comprobarLongitudAsunto()) {
			correcto=true;
		}
		return correcto;
	}

	public boolean ckeckSelection() {
		boolean apto = false;
		//Si se ha seleccionado un item
		if(!tableListadoUsuarios.getSelectionModel().getSelectedItems().isEmpty()) {
			apto=true;
		}else {
			//Le decimos al usuario que hace falta que seleccione el destinatario
			if (language.equals("es_ES")) {
				labelAvisoTableView.setText("ERROR: debe seleccionar un usuario de la lista.");
			} else {
				labelAvisoTableView.setText("ERROR: You must select an user from the list.");
			}
		}
		return apto;
	}

	public boolean comprobarLongitudMensaje() {
		String mensaje = textAreaMensajeInicial.getText();
		boolean apto=false;
		if(mensaje.length()<=200 && !mensaje.isEmpty()) {
			apto=true;
		}else {
			//Avisamos al usuario de que no es correcto
			if(mensaje.length()>200) {
				if (language.equals("es_ES")) {
					labelAvisoLongitudMensaje.setText("ERROR: el mensaje introducido es demasiado largo.");
				} else {
					labelAvisoTableView.setText("ERROR: The message submitted is too long.");
				}
			}else {
				if (language.equals("es_ES")) {
					labelAvisoLongitudMensaje.setText("ERROR: el mensaje esta vacio.");
				} else {
					labelAvisoTableView.setText("ERROR: The message is empty.");
				}
			}
		}
		return apto;
	}

	public boolean comprobarLongitudAsunto() {
		boolean apto=false;
		String asunto = textFieldAsunto.getText();
		if(asunto.length()<=30 && !asunto.isEmpty()) {
			apto=true;
		}else {
			//Avisamos al usuario de que no es correcto
			if(asunto.length()>30) {
				if (language.equals("es_ES")) {
					labelAvisoLongitudAsunto.setText("ERROR: el asunto introducido es demasiado largo.");
				} else {
					labelAvisoLongitudAsunto.setText("ERROR: The subject submitted is too long.");
				}
			}else {
				if (language.equals("es_ES")) {
					labelAvisoLongitudAsunto.setText("ERROR: el asunto esta vacio.");
				} else {
					labelAvisoLongitudAsunto.setText("ERROR: The subject is empty.");
				}
			}
		}
		
		//Verificamos que no exista ningun otro ticket con el mismo asunto
		ControladorBBDD cBBDD = new ControladorBBDD();
		if(cBBDD.comprobarNoExisteAsuntoIgualTicket(asunto)) {
			if (language.equals("es_ES")) {
				labelAvisoLongitudAsunto.setText("ERROR: el asunto que ha introducido debe ser unico.");
			} else {
				labelAvisoLongitudAsunto.setText("ERROR: The subject that you entered should be unique.");
			}
			apto=false;
		}
		return apto;
	}

	//Metodo para rellenar la columna con el listado de Usuarios
	void rellenarTable() {

		ControladorBBDD cBBDD = new ControladorBBDD();

		//Creamos el observableList para mostrar los datos en la tabla
		ObservableList<Usuario> listadoCompletoUsuarios = FXCollections.observableArrayList();

		if(usuarioLogueado.getCredencial().getRol()==0) {//Paciente

			//Si se trata de un paciente buscamos su clinico asociado en la bbdd
			String dniClinico = cBBDD.devolverClinicoAsociadoAPaciente(usuarioLogueado.getCredencial().getUsuario_dni());

			if(!dniClinico.equals("")) {//Si tiene un clinico asociado...
				listadoCompletoUsuarios.add(cBBDD.BuscarClinico(dniClinico));
			}

		}else if(usuarioLogueado.getCredencial().getRol()==2) {//Clinico
			//En la tabla del clinico deben aparecer sus pacientes
			Clinico clinico = cBBDD.BuscarClinico(usuarioLogueado.getCredencial().getUsuario_dni());
			//A�adimos los pacientes del clinico en el observable list
			for(int i=0; i<clinico.getPacientes_id().size(); i++) {
				listadoCompletoUsuarios.add(cBBDD.BuscarPaciente(clinico.getPacientes_id().get(i)));
			}
		}

		//Asignamos valores a nuestras columnas
		columnaListadoDeUsuarios.setCellValueFactory(new PropertyValueFactory<Usuario, String>("nombreYApellidos"));

		//Cargamos la informacion en nuestra tabla
		tableListadoUsuarios.setItems(listadoCompletoUsuarios);

		//En caso de que el usuarioLogueado no tenga ningun usuario asociado mostramos este mensaje en la tabla
		if (language.contentEquals("es_ES")) {
			tableListadoUsuarios.setPlaceholder(new Label("No dispone de ning�n usuario asociado para crear un ticket."));
		} else {
			tableListadoUsuarios.setPlaceholder(new Label("You do not have any associated user to create a ticket."));
		}
		
	}

	@FXML
	void initialize() {
		assert labelTituloAbrirNuevoTicket != null : "fx:id=\"labelTituloAbrirNuevoTicket\" was not injected: check your FXML file 'VentanaSecundariaComunicacionCrearTicket.fxml'.";
		assert botonCancelar != null : "fx:id=\"botonCancelar\" was not injected: check your FXML file 'VentanaSecundariaComunicacionCrearTicket.fxml'.";
		assert botonAceptar != null : "fx:id=\"botonAceptar\" was not injected: check your FXML file 'VentanaSecundariaComunicacionCrearTicket.fxml'.";
		assert tableListadoUsuarios != null : "fx:id=\"tableListadoUsuarios\" was not injected: check your FXML file 'VentanaSecundariaComunicacionCrearTicket.fxml'.";
		assert labelAsunto != null : "fx:id=\"labelAsunto\" was not injected: check your FXML file 'VentanaSecundariaComunicacionCrearTicket.fxml'.";
		assert textFieldAsunto != null : "fx:id=\"textFieldAsunto\" was not injected: check your FXML file 'VentanaSecundariaComunicacionCrearTicket.fxml'.";
		assert labelMensajeInicial != null : "fx:id=\"labelMensajeInicial\" was not injected: check your FXML file 'VentanaSecundariaComunicacionCrearTicket.fxml'.";
		assert textAreaMensajeInicial != null : "fx:id=\"textAreaMensajeInicial\" was not injected: check your FXML file 'VentanaSecundariaComunicacionCrearTicket.fxml'.";
		//Insertamos las funciones que completan la parte visual
		rellenarTable();
	}
}