package control;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import model.Paciente;

public class ControladorVentanaVisualizarECG {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private CategoryAxis CategoryAxis=new CategoryAxis();

    @FXML
    private NumberAxis NumberAxis=new NumberAxis();
    
    @FXML
    private LineChart<String, Number> LineChart=new LineChart<String, Number>(CategoryAxis, NumberAxis);


    @FXML
    private Button botonMas;

    @FXML
    private Button BotonMenos;
    
    @FXML
    private Button botonAtras;
    
    //recursos
    public static String language;
    int DefaultWidth=10000; //Hay que reducir a la mitad con nuevo tama�o
    private BorderPane panelInsertarApartado;
    private Paciente paciente;
    private String fecha;	//Lo usamos para recoger el ECG en tipo blob y mostrarlo
    private int id;	//Para saber el id del fichero a cargar
    private String title="ECG";	
    
    //GETTERS Y SETTERS
    
    
	public Paciente getPaciente() {
	return paciente;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setPaciente(Paciente paciente) {
	this.paciente = paciente;
	}
	public BorderPane getPanelInsertarApartado() {
		return panelInsertarApartado;
	}
	public void setPanelInsertarApartado(BorderPane panelInsertarApartado) {
		this.panelInsertarApartado = panelInsertarApartado;
	}
        public static String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		ControladorVentanaVisualizarECG.language = language;
	}

    
    @FXML
    void initialize() {
        assert LineChart != null : "fx:id=\"LineChart\" was not injected: check your FXML file 'VentanaCorazonECG.fxml'.";
        assert CategoryAxis != null : "fx:id=\"CategoryAxis\" was not injected: check your FXML file 'VentanaCorazonECG.fxml'.";
        assert NumberAxis != null : "fx:id=\"NumberAxis\" was not injected: check your FXML file 'VentanaCorazonECG.fxml'.";
        LineChart.setMinWidth(DefaultWidth);
        LineChart.setCreateSymbols(false); //hide dots
        LineChart.setTitle(title);
        CategoryAxis.setLabel("Estado");
        
        arrayToLineChar();
        //ListToLineChar();
    }
    

	void arrayToLineChar() {
		XYChart.Series<String, Number> series = new XYChart.Series<>();
		
		ControladorBBDD cBBDD = new ControladorBBDD();
		// Se devuelve el ECG separado por ; desde el cBBDD
		String[] ECG = cBBDD.devolverECG(id);
		// Recorremos el ECG cargandolo en la gr�fica
		int valor=0;
		try {
			for (int i = 0; i < ECG.length; i++) {
				valor = Integer.parseInt(ECG[i]);
				String iString = String.valueOf(i);
				series.getData().add(new XYChart.Data<>(iString, valor));
				
			}
			LineChart.getData().add(series);
			ECG=null;	//liberamos memoria
			
		} catch (Exception E) {

		}
	}
	void ListToLineChar() {
		XYChart.Series<String, Number> series = new XYChart.Series<>();
		
		ControladorBBDD cBBDD = new ControladorBBDD();
		// Se devuelve el ECG separado por ; desde el cBBDD
		List<Integer> ECG = cBBDD.devolverECGList(id);
		// Recorremos el ECG cargandolo en la gr�fica
		try {
			for (int i = 0; i <= ECG.size(); i++) {
				int valor = ECG.get(i);
				String iString = String.valueOf(i);
				series.getData().add(new XYChart.Data<>(iString, valor));
				System.out.println(valor);
			}
			LineChart.getData().add(series);
			
		} catch (Exception E) {

		}
	}
    
    @FXML
    void BotonMasPulsado(ActionEvent event) {
    	DefaultWidth=DefaultWidth+1500;
    	LineChart.setMinWidth(DefaultWidth);
    }

    @FXML
    void botonMenosPulsado(ActionEvent event) {
    	DefaultWidth=DefaultWidth-1500;
    	LineChart.setMinWidth(DefaultWidth);
    }

    @FXML
    void VolverSeleecionECG(ActionEvent event) {
		//Cargamos la pantalla de pacientes cuando se presiona el boton "Pacientes"
		System.out.println("Volviendo a selecci�n ECG");
		//idioma
		Locale locale = new Locale(language);
		ResourceBundle bundle = ResourceBundle.getBundle("recursos.lang", locale);
		//Creamos un objeto FXMLLoader para cargar la pantalla
		FXMLLoader loader = new FXMLLoader (getClass().getResource("/view/VentanaCorazonECGPaciente.fxml"), bundle);
		ControladorVentanaCorazonECGPaciente c = new ControladorVentanaCorazonECGPaciente();
		ControladorVentanaCorazonPaciente.language=language;
		c.setPaciente(paciente);
		//c.setUsuarioLogueado(UsuarioLogueado);
		c.setPanelInsertarApartado(panelInsertarApartado);
		c.setPaciente(paciente);
		loader.setController(c);
		Parent root;
		try {
			root = loader.load();
			panelInsertarApartado.setCenter(root);
			//panelactual = "Corazon";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
}
