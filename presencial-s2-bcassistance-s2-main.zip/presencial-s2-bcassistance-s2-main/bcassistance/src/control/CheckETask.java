package control;

import java.util.Iterator;
import javafx.concurrent.Task;
import model.Callcenter;
import model.Clinico;
import model.Cuidador;
import model.Emergencia;
import model.Paciente;

public class CheckETask<T> extends Task<Paciente> {
	private T supervisor;


	public CheckETask(T supervisor) {
		this.supervisor=supervisor;
	}

	@Override
	protected void succeeded() {
		super.succeeded();
		System.out.println("Se ha terminado de revisar");
		// e.g. show "copy finished" dialog
	}

	@Override
	protected void running() {
		super.running();
		System.out.println("Revisando...");
		// e.g. change mouse courser
	}

	@Override
	protected void failed() {
		super.failed();
		System.out.println("Ha pasado un error en el task");// do stuff if call threw an excpetion

	}

	@Override
	protected Paciente call () throws Exception {
		//Paciente pac_actual = null;
		ControladorBBDD cBBDD = new ControladorBBDD();

		//Si el supervisor que se la ha pasado es un Clinico, se revisa la lista de pacientes de dicho clinico
		if (supervisor instanceof Clinico) {
			try{ Clinico clinico=(Clinico) supervisor; 
			System.out.println("Se comienza a revisar el clinico " + clinico.getNombre() );

			Paciente paciente_e = cBBDD.getPacienteEmergencia(clinico.getCredencial().getUsuario_dni(), clinico.getCredencial().getRol());

			if (paciente_e!=null && !paciente_e.getEmergencia().isReporte_clinico()) {
				System.out.println("entra en el if");
				return paciente_e;

			}
			} catch(Exception e) {
				e.printStackTrace();
			}

			//Si el supervisor que se la ha pasado es un Cuidador, se revisa la lista de pacientes de dicho cuidador	
		} else if (supervisor instanceof Cuidador) {
			try{ Cuidador cuidador=(Cuidador) supervisor; 
			System.out.println("Se comienza a revisar el cuidador " + cuidador.getNombre() );

			Paciente paciente_e = cBBDD.getPacienteEmergencia(cuidador.getCredencial().getUsuario_dni(), cuidador.getCredencial().getRol());

			if (paciente_e!=null && !paciente_e.getEmergencia().isReporte_cuidador()) {
				System.out.println("entra en el if");
				return paciente_e;

			}
			} catch(Exception e) {
				e.printStackTrace();
			}

		} 
			else if (supervisor instanceof Callcenter) {

			try{ Callcenter callcenter=(Callcenter) supervisor; 
			System.out.println("Se comienza a revisar el callcenter " + callcenter.getNombre() );

			Paciente paciente_e = cBBDD.getPacienteEmergencia(callcenter.getCredencial().getUsuario_dni(), callcenter.getCredencial().getRol());

			if (paciente_e!=null && !paciente_e.getEmergencia().isReporte_callcenter()) {
				System.out.println("entra en el if");
				return paciente_e;

			}
			} catch(Exception e) {
				e.printStackTrace();
			}
		} 

		return null;
	}


}
