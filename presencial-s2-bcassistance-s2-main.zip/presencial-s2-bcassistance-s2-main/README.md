# presencial-bcassistance

#### Trello https://trello.com/b/mxBN0Nsf/proyecto-bcassistance

#### Diagrama de usuarios https://app.creately.com/diagram/Pv0E7QR7u6o/edit

#### Interfaz paciente: https://danielo844158.invisionapp.com/prototype/BCA-ckhbsp43r013w9401k8vx0e24/play/5f529df4

#### Interfaz clínico: https://danielo844158.invisionapp.com/prototype/Medico-ckhddxiw900fm3401jxy4643o/play/49da2c7c

#### Interfaz callcenter: https://danielo844158.invisionapp.com/prototype/Callcenter-ckhddqkmv00e8sg01pmlgguho/play/4367a364

#### Interfaz cuidador: https://danielo844158.invisionapp.com/prototype/BCACuidador-ckhc0xlu301g6w4010sis6lxu/play/dd3e4db6
